import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import train_test_split, cross_val_score, validation_curve
from sklearn.linear_model import LinearRegression, Ridge, RidgeCV
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.feature_selection import SelectKBest, f_regression, RFE
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan, het_white
from statsmodels.stats.stattools import durbin_watson
import warnings
import os
warnings.filterwarnings('ignore')

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10

def enhanced_multiple_linear_regression(df):
    # 因变量
    y_var = 'Y染色体浓度'
    # 基础特征集合
    base_features = [
        '孕妇BMI', '检测时怀孕天数', '年龄', '体重', '身高',
        'X染色体浓度', '18号染色体的Z值', 'Y染色体的Z值', 
        '13号染色体的Z值', '21号染色体的Z值', 'X染色体的Z值',
        'GC含量', '末次月经距检测日天数',
        'IVF妊娠_编码', '怀孕次数_编码', '胎儿健康_编码',
        'T13_异常', 'T18_异常', 'T21_异常'
    ]
    
    # 检查可用特征
    available_features = [f for f in base_features if f in df.columns]
    missing_features = [f for f in base_features if f not in df.columns]
    # 数据清洗
    model_data = df[[y_var] + available_features].dropna()
    X = model_data[available_features]
    y = model_data[y_var]
    # 因变量基本统计
    y_stats = {
        '样本数': len(y),
        '均值': y.mean(),
        '中位数': y.median(),
        '标准差': y.std(),
        '最小值': y.min(),
        '最大值': y.max(),
        '偏度': stats.skew(y),
        '峰度': stats.kurtosis(y)
    }
    for key, value in y_stats.items():
        print(f"  {key}: {value:.6f}")
    # 因变量正态性检验
    if len(y) > 5000:
        normality_stat, normality_p = stats.normaltest(y)
        normality_test = "D'Agostino-Pearson"
    else:
        normality_stat, normality_p = stats.shapiro(y)
        normality_test = "Shapiro-Wilk"
    print(f"\n因变量正态性检验 ({normality_test}):")
    print(f"  统计量: {normality_stat:.4f}")
    print(f"  p值: {normality_p:.6f}")
    print(f"  结论: {'符合正态分布' if normality_p > 0.05 else '不符合正态分布'}")
    # 2. 特征工程和增强
    X_engineered = X.copy()
    new_features = []
    # 交互特征
    interaction_pairs = [
        ('孕妇BMI', '检测时怀孕天数'),
        ('年龄', '孕妇BMI'),
        ('Y染色体的Z值', 'X染色体浓度'),
        ('身高', '体重'),
        ('18号染色体的Z值', 'Y染色体的Z值')
    ]
    for f1, f2 in interaction_pairs:
        if f1 in X.columns and f2 in X.columns:
            feature_name = f'{f1}_x_{f2}'
            X_engineered[feature_name] = X[f1] * X[f2]
            new_features.append(feature_name)
            print(f"  {feature_name}")
    # 多项式特征 (二次项)
    polynomial_vars = ['孕妇BMI', '检测时怀孕天数', '年龄', 'X染色体浓度']
    for var in polynomial_vars:
        if var in X.columns:
            feature_name = f'{var}_平方'
            X_engineered[feature_name] = X[var] ** 2
            new_features.append(feature_name)
            print(f"  {feature_name}")
    # 比率特征
    ratio_pairs = [
        ('体重', '身高', '体重身高比'),
        ('Y染色体的Z值', 'X染色体的Z值', 'Y_X_Z值比率'),
        ('末次月经距检测日天数', '检测时怀孕天数', '时间比率')
    ]
    for num_var, den_var, ratio_name in ratio_pairs:
        if num_var in X.columns and den_var in X.columns:
            X_engineered[ratio_name] = X[num_var] / (X[den_var] + 1e-8)  # 避免除零
            new_features.append(ratio_name)
            print(f"  {ratio_name} = {num_var} / {den_var}")
    # 变换特征
    transform_vars = ['孕妇BMI', 'X染色体浓度']
    for var in transform_vars:
        if var in X.columns:
            # 对数变换
            log_name = f'{var}_对数'
            X_engineered[log_name] = np.log1p(X[var])  # log(1+x)避免负值问题
            new_features.append(log_name)
            print(f"  {log_name}")
            # 平方根变换
            sqrt_name = f'{var}_平方根'
            X_engineered[sqrt_name] = np.sqrt(X[var])
            new_features.append(sqrt_name)
            print(f"  {sqrt_name}")
    print(f"\n特征工程结果:")
    print(f"  原始特征数: {len(available_features)}")
    print(f"  新增特征数: {len(new_features)}")
    print(f"  总特征数: {X_engineered.shape[1]}")
    # 3. 特征相关性分析和选择
    # 计算特征与因变量的相关性
    correlations = []
    for feature in X_engineered.columns:
        # 使用Spearman相关系数（对非正态分布更robust）
        corr, p_value = stats.spearmanr(X_engineered[feature], y)
        correlations.append({
            '特征名': feature,
            '相关系数': corr,
            'p值': p_value,
            '显著性': '***' if p_value < 0.001 else '**' if p_value < 0.01 else '*' if p_value < 0.05 else 'n.s.',
            '绝对相关系数': abs(corr)
        })
    corr_df = pd.DataFrame(correlations).sort_values('绝对相关系数', ascending=False)
    print("特征与因变量相关性分析 (Top 15):")
    top_corr = corr_df.head(15)[['特征名', '相关系数', 'p值', '显著性']]
    for _, row in top_corr.iterrows():
        print(f"  {row['特征名']}: {row['相关系数']:.4f} (p={row['p值']:.6f}) {row['显著性']}")
    # 选择显著相关的特征
    significant_features = corr_df[
        (corr_df['p值'] < 0.05) & (corr_df['绝对相关系数'] > 0.01)
    ]['特征名'].tolist()
    print(f"\n显著相关特征数: {len(significant_features)}")
    # 4. 多重共线性诊断
    # 选择前20个最相关的特征进行VIF分析
    selected_for_vif = corr_df.head(20)['特征名'].tolist()
    X_for_vif = X_engineered[selected_for_vif]
    # 标准化数据
    scaler_vif = StandardScaler()
    X_vif_scaled = scaler_vif.fit_transform(X_for_vif)
    X_vif_df = pd.DataFrame(X_vif_scaled, columns=X_for_vif.columns)
    # 计算VIF
    vif_data = pd.DataFrame()
    vif_data["特征"] = X_for_vif.columns
    vif_data["VIF"] = [variance_inflation_factor(X_vif_df.values, i) 
                       for i in range(len(X_for_vif.columns))]
    vif_data = vif_data.sort_values('VIF', ascending=False)
    print("方差膨胀因子 (VIF) 分析:")
    for _, row in vif_data.iterrows():
        if row['VIF'] > 10:
            status = "严重共线性"
        elif row['VIF'] > 5:
            status = "中等共线性"
        else:
            status = "轻微共线性"
        print(f"  {row['特征']}: {row['VIF']:.3f} ({status})")
    # 移除高VIF特征
    high_vif_features = vif_data[vif_data['VIF'] > 10]['特征'].tolist()
    if high_vif_features:
        print(f"\n移除高VIF特征: {high_vif_features}")
        final_features = [f for f in selected_for_vif if f not in high_vif_features]
    else:
        final_features = selected_for_vif[:15]  # 选择前15个特征
        print(f"\n无需移除高VIF特征，选择前15个相关特征")
    X_final = X_engineered[final_features]
    print(f"最终建模特征数: {len(final_features)}")
    # 5. 数据分割和标准化
    # 分割数据
    X_train, X_test, y_train, y_test = train_test_split(
        X_final, y, test_size=0.2, random_state=42, stratify=None
    )
    print(f"训练集大小: {X_train.shape}")
    print(f"测试集大小: {X_test.shape}")
    # 标准化特征
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    # 转换为DataFrame便于后续分析
    X_train_scaled_df = pd.DataFrame(X_train_scaled, columns=X_train.columns, index=X_train.index)
    X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X_test.columns, index=X_test.index)
    print("特征标准化完成 (均值=0, 标准差=1)")
    # 6. 模型建立和训练
    # 使用RidgeCV自动选择最优正则化参数
    alphas = np.logspace(-3, 3, 50)
    ridge_cv = RidgeCV(alphas=alphas, cv=10, scoring='r2')
    ridge_cv.fit(X_train_scaled, y_train)
    optimal_alpha = ridge_cv.alpha_
    print(f"最优正则化参数 α: {optimal_alpha:.6f}")
    # 使用最优参数的Ridge回归
    ridge_model = Ridge(alpha=optimal_alpha)
    ridge_model.fit(X_train_scaled, y_train)
    # 同时建立普通线性回归用于对比
    lr_model = LinearRegression()
    lr_model.fit(X_train_scaled, y_train)
    # 使用statsmodels进行详细统计分析
    X_train_const = sm.add_constant(X_train_scaled)
    sm_model = sm.OLS(y_train, X_train_const).fit()
    print("\\nStatsmodels回归结果:")
    print(sm_model.summary())
    # 7. 模型预测和评估
    # Ridge回归预测
    y_train_pred_ridge = ridge_model.predict(X_train_scaled)
    y_test_pred_ridge = ridge_model.predict(X_test_scaled)
    # 普通线性回归预测
    y_train_pred_lr = lr_model.predict(X_train_scaled)
    y_test_pred_lr = lr_model.predict(X_test_scaled)
    # 计算评估指标
    def calculate_metrics(y_true, y_pred, model_name):
        r2 = r2_score(y_true, y_pred)
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        mae = mean_absolute_error(y_true, y_pred)
        mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100  # 平均绝对百分比误差
        return {
            'model': model_name,
            'r2': r2,
            'rmse': rmse,
            'mae': mae,
            'mape': mape
        }
    # 评估结果
    metrics = []
    metrics.append(calculate_metrics(y_train, y_train_pred_ridge, 'Ridge训练集'))
    metrics.append(calculate_metrics(y_test, y_test_pred_ridge, 'Ridge测试集'))
    metrics.append(calculate_metrics(y_train, y_train_pred_lr, '线性回归训练集'))
    metrics.append(calculate_metrics(y_test, y_test_pred_lr, '线性回归测试集'))
    print("模型性能比较:")
    print(f"{'模型':<15} {'R²':<8} {'RMSE':<12} {'MAE':<12} {'MAPE(%)':<10}")
    for m in metrics:
        print(f"{m['model']:<15} {m['r2']:<8.4f} {m['rmse']:<12.6f} {m['mae']:<12.6f} {m['mape']:<10.2f}")
    # 交叉验证评估
    cv_scores_ridge = cross_val_score(ridge_model, X_train_scaled, y_train, cv=10, scoring='r2')
    cv_scores_lr = cross_val_score(lr_model, X_train_scaled, y_train, cv=10, scoring='r2')
    print(f"\n10折交叉验证结果:")
    print(f"Ridge回归: R² = {cv_scores_ridge.mean():.4f} ± {cv_scores_ridge.std():.4f}")
    print(f"线性回归: R² = {cv_scores_lr.mean():.4f} ± {cv_scores_lr.std():.4f}")
    # 8. 模型系数详细分析
    # 创建系数分析DataFrame
    coef_analysis = pd.DataFrame({
        '特征名': X_train.columns,
        'Ridge系数': ridge_model.coef_,
        '线性回归系数': lr_model.coef_,
        '标准化系数_Ridge': ridge_model.coef_,  # 已经是标准化的
        '标准化系数_线性': lr_model.coef_,
        '原始特征标准差': X_train.std().values,
        'Ridge重要性': np.abs(ridge_model.coef_),
        '线性回归重要性': np.abs(lr_model.coef_)
    })
    # 添加统计显著性（从statsmodels结果）
    if len(X_train.columns) <= len(sm_model.pvalues) - 1:
        coef_analysis['p值'] = sm_model.pvalues[1:len(X_train.columns)+1].values
        coef_analysis['置信区间下限'] = sm_model.conf_int()[0][1:len(X_train.columns)+1].values
        coef_analysis['置信区间上限'] = sm_model.conf_int()[1][1:len(X_train.columns)+1].values
        coef_analysis['显著性'] = coef_analysis['p值'].apply(
            lambda p: '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'n.s.'
        )
    # 按Ridge回归系数重要性排序
    coef_analysis = coef_analysis.sort_values('Ridge重要性', ascending=False)
    print("回归系数详细分析 (按Ridge重要性排序):")
    print(f"{'特征':<20} {'Ridge系数':<10} {'线性系数':<10} {'p值':<10} {'显著性':<8}")
    print("-" * 70)
    for _, row in coef_analysis.iterrows():
        p_val_str = f"{row.get('p值', np.nan):.6f}" if not pd.isna(row.get('p值', np.nan)) else "N/A"
        sig_str = row.get('显著性', 'N/A')
        print(f"{row['特征名']:<20} {row['Ridge系数']:<10.6f} {row['线性回归系数']:<10.6f} {p_val_str:<10} {sig_str:<8}")
    
    # 9. 模型诊断和假设检验
    # 使用Ridge回归的残差进行诊断
    residuals_train = y_train - y_train_pred_ridge
    residuals_test = y_test - y_test_pred_ridge
    # 1) 残差正态性检验
    if len(residuals_train) > 5000:
        res_stat, res_p = stats.normaltest(residuals_train)
        res_test_name = "D'Agostino-Pearson"
    else:
        res_stat, res_p = stats.shapiro(residuals_train)
        res_test_name = "Shapiro-Wilk"
    
    print(f"残差正态性检验 ({res_test_name}):")
    print(f"  统计量: {res_stat:.4f}")
    print(f"  p值: {res_p:.6f}")
    print(f"  结论: {'残差符合正态分布' if res_p > 0.05 else '残差不符合正态分布'}")
    
    # 2) 残差同方差性检验 (Breusch-Pagan test)
    try:
        bp_stat, bp_p, _, _ = het_breuschpagan(residuals_train, X_train_const)
        print(f"\n残差同方差性检验 (Breusch-Pagan):")
        print(f"  统计量: {bp_stat:.4f}")
        print(f"  p值: {bp_p:.6f}")
        print(f"  结论: {'残差方差齐性' if bp_p > 0.05 else '存在异方差性'}")
    except:
        print("\n无法进行Breusch-Pagan检验")
    
    # 3) 残差自相关检验 (Durbin-Watson)
    dw_stat = durbin_watson(residuals_train)
    print(f"\n残差自相关检验 (Durbin-Watson):")
    print(f"  统计量: {dw_stat:.4f}")
    if 1.5 <= dw_stat <= 2.5:
        dw_conclusion = "无明显自相关"
    elif dw_stat < 1.5:
        dw_conclusion = "可能存在正自相关"
    else:
        dw_conclusion = "可能存在负自相关"
    print(f"  结论: {dw_conclusion}")
    
    # 4) 离群值检测
    z_scores = np.abs(stats.zscore(residuals_train))
    outliers_count = np.sum(z_scores > 3)
    print(f"\n离群值检测 (|Z-score| > 3):")
    print(f"  离群值数量: {outliers_count}")
    print(f"  离群值比例: {outliers_count/len(residuals_train)*100:.2f}%")
    
    # 5) Cook距离 (影响力分析)
    try:
        influence = sm_model.get_influence()
        cook_d = influence.cooks_distance[0]
        high_influence = np.sum(cook_d > 4/len(y_train))
        print(f"\n影响力分析 (Cook距离 > 4/n):")
        print(f"  高影响力点数量: {high_influence}")
        print(f"  高影响力点比例: {high_influence/len(y_train)*100:.2f}%")
    except:
        print("\n无法计算Cook距离")
    
    # 10. 模型可视化分析
    #[8]AI协助添加过程可视化使其更具可解释性
    # 创建综合可视化
    fig = plt.figure(figsize=(20, 15))
    # 子图1: 实际值 vs 预测值
    ax1 = plt.subplot(3, 3, 1)
    plt.scatter(y_test, y_test_pred_ridge, alpha=0.6, color='blue', s=30)
    min_val = min(y_test.min(), y_test_pred_ridge.min())
    max_val = max(y_test.max(), y_test_pred_ridge.max())
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='完美预测线')
    plt.xlabel('实际值')
    plt.ylabel('预测值')
    plt.title(f'预测效果 (R² = {metrics[1]["r2"]:.3f})')
    plt.legend()
    plt.grid(True, alpha=0.3)
    # 子图2: 残差图
    ax2 = plt.subplot(3, 3, 2)
    plt.scatter(y_test_pred_ridge, residuals_test, alpha=0.6)
    plt.axhline(y=0, color='red', linestyle='--')
    plt.xlabel('预测值')
    plt.ylabel('残差')
    plt.title('残差分布图')
    plt.grid(True, alpha=0.3)
    # 子图3: 残差直方图
    ax3 = plt.subplot(3, 3, 3)
    plt.hist(residuals_test, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
    plt.axvline(residuals_test.mean(), color='red', linestyle='--', label=f'均值: {residuals_test.mean():.6f}')
    plt.xlabel('残差')
    plt.ylabel('频数')
    plt.title('残差分布直方图')
    plt.legend()
    plt.grid(True, alpha=0.3)
    # 子图4: Q-Q图
    ax4 = plt.subplot(3, 3, 4)
    stats.probplot(residuals_test, dist="norm", plot=plt)
    plt.title('残差正态性Q-Q图')
    plt.grid(True, alpha=0.3)
    # 子图5: 系数重要性
    ax5 = plt.subplot(3, 3, 5)
    top_10_coef = coef_analysis.head(10)
    colors = ['red' if x < 0 else 'blue' for x in top_10_coef['Ridge系数']]
    bars = plt.barh(range(len(top_10_coef)), top_10_coef['Ridge系数'], color=colors, alpha=0.7)
    plt.yticks(range(len(top_10_coef)), top_10_coef['特征名'], fontsize=8)
    plt.xlabel('标准化系数')
    plt.title('Top 10 特征重要性')
    plt.axvline(x=0, color='black', linestyle='-', alpha=0.3)
    plt.grid(True, alpha=0.3)
    # 子图6: 特征相关性热力图
    ax6 = plt.subplot(3, 3, 6)
    top_features = coef_analysis.head(8)['特征名'].tolist()
    corr_matrix = X_train[top_features].corr()
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, square=True,
                fmt='.2f', cbar_kws={'shrink': 0.8})
    plt.title('Top 8 特征相关性矩阵')
    # 子图7: 验证曲线（正则化参数）
    ax7 = plt.subplot(3, 3, 7)
    if len(alphas) > 1:
        train_scores, val_scores = validation_curve(
            Ridge(), X_train_scaled, y_train, 
            param_name='alpha', param_range=alphas, cv=5, scoring='r2'
        )
        plt.semilogx(alphas, np.mean(train_scores, axis=1), 'b-', label='训练集R²', linewidth=2)
        plt.semilogx(alphas, np.mean(val_scores, axis=1), 'r-', label='验证集R²', linewidth=2)
        plt.axvline(x=optimal_alpha, color='green', linestyle='--', label=f'最优α={optimal_alpha:.4f}')
        plt.xlabel('正则化参数 α')
        plt.ylabel('R² 分数')
        plt.title('Ridge回归验证曲线')
        plt.legend()
        plt.grid(True, alpha=0.3)
    # 子图8: 残差vs主要特征
    if '孕妇BMI' in X_test.columns:
        ax8 = plt.subplot(3, 3, 8)
        plt.scatter(X_test['孕妇BMI'], residuals_test, alpha=0.6)
        plt.axhline(y=0, color='red', linestyle='--')
        plt.xlabel('孕妇BMI')
        plt.ylabel('残差')
        plt.title('残差 vs 孕妇BMI')
        plt.grid(True, alpha=0.3)
    # 子图9: 学习曲线（样本量vs性能）
    ax9 = plt.subplot(3, 3, 9)
    from sklearn.model_selection import learning_curve
    train_sizes, train_scores_lc, val_scores_lc = learning_curve(
        ridge_model, X_train_scaled, y_train, cv=5, 
        train_sizes=np.linspace(0.1, 1.0, 10), scoring='r2'
    )
    plt.plot(train_sizes, np.mean(train_scores_lc, axis=1), 'o-', label='训练集')
    plt.plot(train_sizes, np.mean(val_scores_lc, axis=1), 'o-', label='验证集')
    plt.xlabel('训练样本数')
    plt.ylabel('R² 分数')
    plt.title('学习曲线')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('多元线性回归详细分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
    # 11. 特征重要性深度分析
    # 特征类型分类
    def classify_feature_type(feature_name):
        if any(marker in feature_name for marker in ['_x_', '×']):
            return '交互特征'
        elif '平方' in feature_name:
            return '多项式特征'
        elif any(marker in feature_name for marker in ['比', '比率', '/']):
            return '比率特征'
        elif any(marker in feature_name for marker in ['对数', '平方根']):
            return '变换特征'
        elif feature_name in ['IVF妊娠_编码', '怀孕次数_编码', '胎儿健康_编码', 'T13_异常', 'T18_异常', 'T21_异常']:
            return '分类特征'
        else:
            return '原始特征'
    
    coef_analysis['特征类型'] = coef_analysis['特征名'].apply(classify_feature_type)
    # 按特征类型汇总
    feature_type_summary = coef_analysis.groupby('特征类型').agg({
        'Ridge重要性': ['count', 'mean', 'sum'],
        'Ridge系数': lambda x: np.sum(np.abs(x))
    }).round(4)
    print("按特征类型统计:")
    print(feature_type_summary)
    # 最重要的特征分析
    top_5_features = coef_analysis.head(5)
    print(f"\n最重要的5个特征:")
    for i, (_, row) in enumerate(top_5_features.iterrows(), 1):
        effect = "正向影响" if row['Ridge系数'] > 0 else "负向影响"
        significance = row.get('显著性', 'N/A')
        print(f"  {i}. {row['特征名']} ({row['特征类型']})")
        print(f"     系数: {row['Ridge系数']:.6f} ({effect})")
        print(f"     统计显著性: {significance}")
        print()
    # 12. 模型解释和业务洞察
    print("模型性能总结:")
    print(f"  • 模型类型: Ridge回归 (正则化参数α={optimal_alpha:.6f})")
    print(f"  • 特征数量: {len(final_features)}")
    print(f"  • 解释方差: {metrics[1]['r2']*100:.2f}%")
    print(f"  • 平均绝对误差: {metrics[1]['mae']:.6f}")
    print(f"  • 相对误差: {metrics[1]['mape']:.2f}%")
    
    print("\n关键业务洞察:")
    
    # 分析最重要的特征
    most_important = coef_analysis.iloc[0]
    print(f"  1. 最关键预测因子: {most_important['特征名']}")
    print(f"     影响程度: {abs(most_important['Ridge系数']):.6f}")
    print(f"     影响方向: {'增加' if most_important['Ridge系数'] > 0 else '降低'}Y染色体浓度")
    
    # 分析原始特征 vs 工程特征的贡献
    original_features = coef_analysis[coef_analysis['特征类型'] == '原始特征']
    engineered_features = coef_analysis[coef_analysis['特征类型'] != '原始特征']
    
    if len(original_features) > 0 and len(engineered_features) > 0:
        orig_contrib = original_features['Ridge重要性'].sum()
        eng_contrib = engineered_features['Ridge重要性'].sum()
        total_contrib = orig_contrib + eng_contrib
        
        print(f"\\n  2. 特征工程效果分析:")
        print(f"     原始特征贡献: {orig_contrib/total_contrib*100:.1f}%")
        print(f"     工程特征贡献: {eng_contrib/total_contrib*100:.1f}%")
        print(f"     特征工程{'有效' if eng_contrib > orig_contrib*0.3 else '效果有限'}")
    
    # 模型稳定性分析
    print(f"\n  3. 模型稳定性:")
    train_test_diff = abs(metrics[0]['r2'] - metrics[1]['r2'])
    if train_test_diff < 0.05:
        stability = "非常稳定"
    elif train_test_diff < 0.1:
        stability = "稳定"
    else:
        stability = "可能过拟合"
    print(f"     训练集R²: {metrics[0]['r2']:.4f}")
    print(f"     测试集R²: {metrics[1]['r2']:.4f}")
    print(f"     稳定性评估: {stability}")
    
    # 13. 模型方程和预测公式
    print("标准化回归方程 (用于理解特征相对重要性):")
    intercept_scaled = ridge_model.intercept_
    print(f"Y染色体浓度_预测 = {intercept_scaled:.6f}")
    
    for i, (feature, coef) in enumerate(zip(X_train.columns, ridge_model.coef_)):
        sign = "+" if coef >= 0 else ""
        print(f"                   {sign} {coef:.6f} × {feature}_标准化")
    
    print("\\n实际预测公式 (用于实际预测):")
    print("步骤1: 特征标准化")
    print("  标准化特征 = (原始特征 - 特征均值) / 特征标准差")
    print("步骤2: 应用回归方程")
    print("步骤3: 得到预测结果")
    
    # 14. 保存详细分析结果
    # 保存系数分析
    coef_analysis.to_csv("多元线性回归系数详细分析.csv", index=False, encoding='utf-8-sig')
    
    # 保存模型评估
    metrics_df = pd.DataFrame(metrics)
    metrics_df.to_csv("多元线性回归模型评估.csv", index=False, encoding='utf-8-sig')
    
    # 保存预测结果
    prediction_analysis = pd.DataFrame({
        '样本序号': range(len(y_test)),
        '实际值': y_test.values,
        '预测值': y_test_pred_ridge,
        '残差': residuals_test,
        '绝对误差': np.abs(residuals_test),
        '相对误差(%)': np.abs(residuals_test) / y_test.values * 100,
        '误差等级': pd.cut(np.abs(residuals_test), bins=3, labels=['小误差', '中等误差', '大误差'])
    })
    prediction_analysis.to_csv("多元线性回归预测详细分析.csv", index=False, encoding='utf-8-sig')
    
    # 保存特征相关性
    corr_df.to_csv("特征相关性详细分析.csv", index=False, encoding='utf-8-sig')
    
    # 保存诊断结果
    diagnostics = pd.DataFrame([{
        '检验项目': '残差正态性',
        '检验方法': res_test_name,
        '统计量': res_stat,
        'p值': res_p,
        '结论': '符合正态分布' if res_p > 0.05 else '不符合正态分布'
    }, {
        '检验项目': '残差自相关',
        '检验方法': 'Durbin-Watson',
        '统计量': dw_stat,
        'p值': np.nan,
        '结论': dw_conclusion
    }])
    
    try:
        diagnostics = pd.concat([diagnostics, pd.DataFrame([{
            '检验项目': '残差同方差性',
            '检验方法': 'Breusch-Pagan',
            '统计量': bp_stat,
            'p值': bp_p,
            '结论': '方差齐性' if bp_p > 0.05 else '存在异方差性'
        }])], ignore_index=True)
    except:
        pass
    
    diagnostics.to_csv("模型诊断结果.csv", index=False, encoding='utf-8-sig')
    
    print("已保存以下分析文件:")
    print("  • 多元线性回归系数详细分析.csv - 所有系数和重要性分析")
    print("  • 多元线性回归模型评估.csv - 模型性能指标")
    print("  • 多元线性回归预测详细分析.csv - 每个样本的预测详情")
    print("  • 特征相关性详细分析.csv - 特征与因变量相关性")
    print("  • 模型诊断结果.csv - 模型假设检验结果")
    print("  • 多元线性回归详细分析.png - 综合可视化图表")
    
    return {
        'ridge_model': ridge_model,
        'lr_model': lr_model,
        'sm_model': sm_model,
        'scaler': scaler,
        'coefficients': coef_analysis,
        'metrics': metrics_df,
        'predictions': prediction_analysis,
        'correlations': corr_df,
        'diagnostics': diagnostics,
        'optimal_alpha': optimal_alpha,
        'feature_names': final_features,
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test
    }
if __name__ == "__main__":
        current_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(current_dir, "男胎_预处理数据_完整版.csv")
        df = pd.read_csv(file_path)
        results = enhanced_multiple_linear_regression(df)