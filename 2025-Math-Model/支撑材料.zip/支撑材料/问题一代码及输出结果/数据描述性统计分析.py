import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import re
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import os
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10
#文件读取和修改变量
def preprocess_male_nipt_data(file_path, enable_visualization=True):
    df = pd.read_excel(file_path, sheet_name='男胎检测数据')
    processed_df = df.copy()
    #将末次月经日期+检测日期转化变量为末次月经距检测日天数
    def calculate_days_from_lmp(row):
        try:
            lmp_date = pd.to_datetime(row['末次月经'])
            detection_date_str = str(int(row['检测日期']))
            detection_date = pd.to_datetime(detection_date_str, format='%Y%m%d')
            days_diff = (detection_date - lmp_date).days
            return days_diff
        except:
            return np.nan
    processed_df['末次月经距检测日天数'] = processed_df.apply(calculate_days_from_lmp, axis=1)

    # IVF妊娠转换为分类变量，创建数值编码和标签映射
    ivf_mapping = {
        '自然受孕': 0,
        'IUI（人工授精）': 1, 
        'IVF（试管婴儿）': 2
    }
    processed_df['IVF妊娠_编码'] = processed_df['IVF妊娠'].map(ivf_mapping)
    # 改为二进制形式（1和0的数值格式）
    ivf_dummies = pd.get_dummies(processed_df['IVF妊娠'], prefix='IVF', dtype=int)
    processed_df = pd.concat([processed_df, ivf_dummies], axis=1)

    # 将检测孕周转换为检测时怀孕天数
    def parse_gestational_weeks(week_str):
        try:
            if pd.isna(week_str):
                return np.nan
            week_str = str(week_str).strip()
            if 'w' in week_str:
                if '+' in week_str:
                    weeks_part, days_part = week_str.split('+')
                    weeks = int(weeks_part.replace('w', ''))
                    days = int(days_part)
                else:
                    weeks = int(week_str.replace('w', ''))
                    days = 0
                total_days = weeks * 7 + days
                return total_days
            else:
                return np.nan
        except:
            return np.nan
    
    processed_df['检测时怀孕天数'] = processed_df['检测孕周'].apply(parse_gestational_weeks)
    
    # 将染色体非整倍体信息处理为T13、T18、T21异常标记
    def parse_chromosome_abnormality(abnormality_str):
        # 初始化结果
        result = {'T13': 0, 'T18': 0, 'T21': 0}
        if pd.isna(abnormality_str) or abnormality_str == '' or abnormality_str is None:
            return result
        abnormality_str = str(abnormality_str).strip()
        # 检查是否包含各种异常标记
        if 'T13' in abnormality_str:
            result['T13'] = 1
        if 'T18' in abnormality_str:
            result['T18'] = 1  
        if 'T21' in abnormality_str:
            result['T21'] = 1
        return result
    chromosome_results = processed_df['染色体的非整倍体'].apply(parse_chromosome_abnormality)
    processed_df['T13_异常'] = [result['T13'] for result in chromosome_results]
    processed_df['T18_异常'] = [result['T18'] for result in chromosome_results]
    processed_df['T21_异常'] = [result['T21'] for result in chromosome_results]
    
    #怀孕次数转换为分类变量，创建数值编码和二进制形式
    def categorize_pregnancy_count(count):
        if pd.isna(count):
            return np.nan
        if count == 1:
            return '初产妇'
        elif count == 2:
            return '经产妇_2次'
        else: 
            return '经产妇_多次'
    
    processed_df['怀孕次数_分类'] = processed_df['怀孕次数'].apply(categorize_pregnancy_count)
    pregnancy_mapping = {
        '初产妇': 0,
        '经产妇_2次': 1,
        '经产妇_多次': 2
    }
    processed_df['怀孕次数_编码'] = processed_df['怀孕次数_分类'].map(pregnancy_mapping)
    pregnancy_dummies = pd.get_dummies(processed_df['怀孕次数_分类'], prefix='怀孕次数', dtype=int)
    processed_df = pd.concat([processed_df, pregnancy_dummies], axis=1)
    # 胎儿健康状况转换为二分类变量，1表示健康，0表示不健康
    health_mapping = {
        '是': 1,  
        '否': 0   
    }
    processed_df['胎儿健康_编码'] = processed_df['胎儿是否健康'].map(health_mapping)
    # 检查新生成字段的缺失值情况
    new_columns = ['末次月经距检测日天数', 'IVF妊娠_编码', '检测时怀孕天数', 
                   'T13_异常', 'T18_异常', 'T21_异常', '怀孕次数_编码', '胎儿健康_编码']
    missing_info = {}
    for col in new_columns:
        if col in processed_df.columns:
            missing_count = processed_df[col].isnull().sum()
            missing_rate = missing_count / len(processed_df)
            missing_info[col] = {'缺失数量': missing_count, '缺失比例': f"{missing_rate:.3f}"}
    
    missing_df = pd.DataFrame(missing_info).T
    #[8]AI协助添加过程可视化使其更具可解释性
    if enable_visualization:
        # 1. 数据概览可视化
        create_data_overview_plots(processed_df)
        
        # 2. 分类变量分布可视化
        create_categorical_distribution_plots(processed_df)
        
        # 3. 连续变量分布可视化
        create_continuous_distribution_plots(processed_df)
        
        # 4. 数据质量分析可视化
        create_data_quality_plots(processed_df, missing_df)
        
        # 5. 相关性初步分析可视化
        create_preliminary_correlation_plots(processed_df)
    # 选择关键字段用于建模
    key_columns = [
        # 原始标识字段
        '序号', '孕妇代码', '年龄', '身高', '体重', '孕妇BMI',
        
        # 预处理后的字段  
        '末次月经距检测日天数', 'IVF妊娠_编码', '检测时怀孕天数',
        'T13_异常', 'T18_异常', 'T21_异常', 
        '怀孕次数_编码', '胎儿健康_编码',
        
        # 重要的检测指标
        'Y染色体浓度', 'Y染色体的Z值', 
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值',
        'X染色体的Z值', 'GC含量',
        
        # 哑变量
        'IVF_自然受孕', 'IVF_IUI（人工授精）', 'IVF_IVF（试管婴儿）',
        '怀孕次数_初产妇', '怀孕次数_经产妇_2次', '怀孕次数_经产妇_多次'
    ]
    
    # 只保留存在的列
    available_columns = [col for col in key_columns if col in processed_df.columns]
    final_df = processed_df[available_columns].copy()
    return final_df, processed_df
#数据概览图表
def create_data_overview_plots(df):
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('数据预处理概览', fontsize=16, fontweight='bold')
    # 1. 样本量统计
    sample_info = {
        '总样本数': len(df),
        '完整样本': len(df.dropna()),
        '有Y染色体数据': len(df.dropna(subset=['Y染色体浓度'])) if 'Y染色体浓度' in df.columns else 0
    }
    
    bars1 = axes[0, 0].bar(sample_info.keys(), sample_info.values(), 
                          color=['skyblue', 'lightgreen', 'orange'], alpha=0.8)
    axes[0, 0].set_title('样本量统计')
    axes[0, 0].set_ylabel('样本数')
    for bar, value in zip(bars1, sample_info.values()):
        axes[0, 0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 20, 
                       f'{value}', ha='center', va='bottom', fontweight='bold')
    # 2. 年龄分布
    if '年龄' in df.columns:
        age_data = df['年龄'].dropna()
        axes[0, 1].hist(age_data, bins=20, color='lightcoral', alpha=0.7, edgecolor='black')
        axes[0, 1].axvline(age_data.mean(), color='red', linestyle='--', linewidth=2, 
                          label=f'均值: {age_data.mean():.1f}岁')
        axes[0, 1].set_title('孕妇年龄分布')
        axes[0, 1].set_xlabel('年龄（岁）')
        axes[0, 1].set_ylabel('频数')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
    # 3. BMI分布
    if '孕妇BMI' in df.columns:
        bmi_data = df['孕妇BMI'].dropna()
        axes[1, 0].hist(bmi_data, bins=20, color='lightblue', alpha=0.7, edgecolor='black')
        # 添加BMI分类线
        axes[1, 0].axvline(18.5, color='blue', linestyle=':', label='偏瘦')
        axes[1, 0].axvline(24, color='green', linestyle=':', label='正常')
        axes[1, 0].axvline(28, color='orange', linestyle=':', label='超重')
        axes[1, 0].axvline(bmi_data.mean(), color='red', linestyle='--', linewidth=2,
                          label=f'均值: {bmi_data.mean():.1f}')
        axes[1, 0].set_title('孕妇BMI分布')
        axes[1, 0].set_xlabel('BMI')
        axes[1, 0].set_ylabel('频数')
        axes[1, 0].legend()
        axes[1, 0].grid(True, alpha=0.3)
    # 4. Y染色体浓度分布
    if 'Y染色体浓度' in df.columns:
        y_data = df['Y染色体浓度'].dropna()
        axes[1, 1].hist(y_data, bins=30, color='gold', alpha=0.7, edgecolor='black')
        axes[1, 1].axvline(y_data.mean(), color='red', linestyle='--', linewidth=2,
                          label=f'均值: {y_data.mean():.4f}')
        axes[1, 1].set_title('Y染色体浓度分布')
        axes[1, 1].set_xlabel('Y染色体浓度')
        axes[1, 1].set_ylabel('频数')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
    else:
        axes[1, 1].text(0.5, 0.5, 'Y染色体浓度数据\n不可用', ha='center', va='center',
                       transform=axes[1, 1].transAxes, fontsize=14)
        axes[1, 1].set_title('Y染色体浓度分布')
    plt.tight_layout()
    plt.savefig('数据预处理_概览分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
#分类变量分布图表
def create_categorical_distribution_plots(df):
    # 定义分类变量
    categorical_vars = {
        'IVF妊娠': 'IVF妊娠方式',
        '怀孕次数_分类': '怀孕次数分类',
        '胎儿是否健康': '胎儿健康状况'
    }
    # 添加染色体异常变量
    chromosome_vars = ['T13_异常', 'T18_异常', 'T21_异常']
    available_vars = {k: v for k, v in categorical_vars.items() if k in df.columns}
    available_chromosomes = [var for var in chromosome_vars if var in df.columns]
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('分类变量分布分析', fontsize=16, fontweight='bold')
    axes = axes.flatten()
    plot_idx = 0
    # 绘制常规分类变量
    for var, title in available_vars.items():
        if plot_idx >= 4:
            break
        value_counts = df[var].value_counts(dropna=False)
        # 饼图
        colors = plt.cm.Set3(np.linspace(0, 1, len(value_counts)))
        wedges, texts, autotexts = axes[plot_idx].pie(value_counts.values, 
                                                     labels=value_counts.index,
                                                     autopct='%1.1f%%',
                                                     colors=colors,
                                                     startangle=90)
        
        axes[plot_idx].set_title(title)
        # 添加数量标注
        for i, (label, count) in enumerate(value_counts.items()):
            label_str = str(label) if not pd.isna(label) else '缺失'
            axes[plot_idx].text(0.8, 0.8-i*0.1, f'{label_str}: {count}例', 
                               transform=axes[plot_idx].transAxes, fontsize=9,
                               bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
        plot_idx += 1
    # 绘制染色体异常汇总
    if available_chromosomes and plot_idx < 4:
        chromosome_data = {}
        for var in available_chromosomes:
            abnormal_count = df[var].sum() if var in df.columns else 0
            normal_count = len(df) - abnormal_count
            chromosome_name = var.replace('_异常', '')
            chromosome_data[f'{chromosome_name}异常'] = abnormal_count
            chromosome_data[f'{chromosome_name}正常'] = normal_count
        # 堆叠条形图
        chromosomes = ['T13', 'T18', 'T21']
        abnormal_counts = [chromosome_data.get(f'{chr}异常', 0) for chr in chromosomes]
        normal_counts = [chromosome_data.get(f'{chr}正常', 0) for chr in chromosomes]
        x = np.arange(len(chromosomes))
        width = 0.35
        bars1 = axes[plot_idx].bar(x, abnormal_counts, width, label='异常', color='red', alpha=0.7)
        bars2 = axes[plot_idx].bar(x, normal_counts, width, bottom=abnormal_counts, 
                                  label='正常', color='green', alpha=0.7)
        axes[plot_idx].set_title('染色体异常分布')
        axes[plot_idx].set_xlabel('染色体类型')
        axes[plot_idx].set_ylabel('样本数')
        axes[plot_idx].set_xticks(x)
        axes[plot_idx].set_xticklabels(chromosomes)
        axes[plot_idx].legend()
        # 添加数值标签
        for i, (bar1, bar2) in enumerate(zip(bars1, bars2)):
            if abnormal_counts[i] > 0:
                axes[plot_idx].text(bar1.get_x() + bar1.get_width()/2, 
                                   bar1.get_height()/2, f'{abnormal_counts[i]}',
                                   ha='center', va='center', fontweight='bold', color='white')
            axes[plot_idx].text(bar2.get_x() + bar2.get_width()/2,
                               abnormal_counts[i] + bar2.get_height()/2, f'{normal_counts[i]}',
                               ha='center', va='center', fontweight='bold', color='white')
        plot_idx += 1
    
    # 隐藏多余的子图
    for i in range(plot_idx, 4):
        axes[i].set_visible(False)
    plt.tight_layout()
    plt.savefig('数据预处理_分类变量分布.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
# 连续变量分布图表
def create_continuous_distribution_plots(df):
    # 定义连续变量
    continuous_vars = [
        '年龄', '身高', '体重', '孕妇BMI', 
        '末次月经距检测日天数', '检测时怀孕天数',
        'Y染色体浓度', 'Y染色体的Z值', 'GC含量'
    ]
    
    available_vars = [var for var in continuous_vars if var in df.columns]
    
    if not available_vars:
        print("⚠️ 未找到连续变量，跳过连续变量分布图")
        return
    
    n_vars = len(available_vars)
    n_cols = 3
    n_rows = (n_vars + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5*n_rows))
    fig.suptitle('连续变量分布分析', fontsize=16, fontweight='bold')
    
    if n_rows == 1:
        axes = axes.reshape(1, -1) if n_vars > 1 else [axes]
    axes = axes.flatten() if n_vars > 1 else [axes]
    
    for i, var in enumerate(available_vars):
        if i >= len(axes):
            break
            
        data = df[var].dropna()
        
        if len(data) == 0:
            axes[i].text(0.5, 0.5, f'{var}\n无数据', ha='center', va='center',
                        transform=axes[i].transAxes, fontsize=12)
            axes[i].set_title(var)
            continue
        
        # 直方图 + 核密度估计
        axes[i].hist(data, bins=30, density=True, alpha=0.7, color='skyblue', edgecolor='black')
        
        # 核密度估计
        try:
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(data)
            x_range = np.linspace(data.min(), data.max(), 100)
            axes[i].plot(x_range, kde(x_range), 'r-', linewidth=2, label='KDE')
        except:
            pass
        
        # 添加统计信息
        mean_val = data.mean()
        median_val = data.median()
        axes[i].axvline(mean_val, color='red', linestyle='--', linewidth=2, label=f'均值: {mean_val:.3f}')
        axes[i].axvline(median_val, color='orange', linestyle='--', linewidth=2, label=f'中位数: {median_val:.3f}')
        
        axes[i].set_title(var)
        axes[i].set_ylabel('密度')
        axes[i].legend()
        axes[i].grid(True, alpha=0.3)
    
    # 隐藏多余的子图
    for j in range(len(available_vars), len(axes)):
        axes[j].set_visible(False)
    
    plt.tight_layout()
    plt.savefig('数据预处理_连续变量分布.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
#数据质量分析图表
def create_data_quality_plots(df, missing_df):
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('数据质量分析', fontsize=16, fontweight='bold')
    # 1. 缺失值分析
    if not missing_df.empty:
        missing_counts = missing_df['缺失数量'].astype(int)
        missing_counts = missing_counts[missing_counts > 0]  # 只显示有缺失值的字段
        if len(missing_counts) > 0:
            bars = axes[0, 0].barh(range(len(missing_counts)), missing_counts.values, 
                                  color='red', alpha=0.7)
            axes[0, 0].set_yticks(range(len(missing_counts)))
            axes[0, 0].set_yticklabels(missing_counts.index)
            axes[0, 0].set_xlabel('缺失值数量')
            axes[0, 0].set_title('字段缺失值统计')
            axes[0, 0].grid(True, alpha=0.3, axis='x')
            # 添加数值标签
            for i, (bar, value) in enumerate(zip(bars, missing_counts.values)):
                axes[0, 0].text(bar.get_width() + 5, i, f'{value}', 
                               va='center', fontweight='bold')
        else:
            axes[0, 0].text(0.5, 0.5,
                           ha='center', va='center', transform=axes[0, 0].transAxes,
                           fontsize=14, fontweight='bold', color='green')
            axes[0, 0].set_title('字段缺失值统计')
    # 2. 数值变量的异常值检测
    if 'Y染色体浓度' in df.columns:
        y_data = df['Y染色体浓度'].dropna()
        if len(y_data) > 0:
            # 箱线图检测异常值
            bp = axes[0, 1].boxplot(y_data, patch_artist=True)
            bp['boxes'][0].set_facecolor('lightgreen')
            bp['boxes'][0].set_alpha(0.7)
            # 计算异常值
            Q1 = y_data.quantile(0.25)
            Q3 = y_data.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            outliers = y_data[(y_data < lower_bound) | (y_data > upper_bound)]
            axes[0, 1].set_title(f'Y染色体浓度异常值检测\n异常值: {len(outliers)} 个 ({len(outliers)/len(y_data)*100:.1f}%)')
            axes[0, 1].set_ylabel('Y染色体浓度')
            axes[0, 1].grid(True, alpha=0.3)
    else:
        axes[0, 1].text(0.5, 0.5, 'Y染色体浓度\n数据不可用', 
                       ha='center', va='center', transform=axes[0, 1].transAxes, fontsize=14)
        axes[0, 1].set_title('异常值检测')
    
    # 3. 样本完整性分析
    complete_data = df.dropna()
    total_samples = len(df)
    complete_samples = len(complete_data)
    incomplete_samples = total_samples - complete_samples
    
    sizes = [complete_samples, incomplete_samples]
    labels = [f'完整样本\n{complete_samples}例', f'不完整样本\n{incomplete_samples}例']
    colors = ['lightgreen', 'lightcoral']
    
    wedges, texts, autotexts = axes[1, 0].pie(sizes, labels=labels, autopct='%1.1f%%', 
                                             colors=colors, startangle=90)
    axes[1, 0].set_title('样本完整性分析')
    
    # 4. 关键变量可用性
    key_vars = ['年龄', '孕妇BMI', 'Y染色体浓度', '胎儿健康_编码', 'IVF妊娠_编码']
    available_vars = [var for var in key_vars if var in df.columns]
    
    if available_vars:
        availability_rates = []
        var_labels = []
        
        for var in available_vars:
            non_null_count = df[var].count()
            rate = non_null_count / len(df) * 100
            availability_rates.append(rate)
            var_labels.append(f'{var}\n({non_null_count}/{len(df)})')
        
        bars = axes[1, 1].bar(range(len(available_vars)), availability_rates, 
                             color='steelblue', alpha=0.7)
        axes[1, 1].set_xticks(range(len(available_vars)))
        axes[1, 1].set_xticklabels(var_labels, rotation=45, ha='right')
        axes[1, 1].set_ylabel('数据可用率 (%)')
        axes[1, 1].set_title('关键变量数据可用性')
        axes[1, 1].set_ylim(0, 105)
        axes[1, 1].grid(True, alpha=0.3, axis='y')
        
        # 添加百分比标签
        for bar, rate in zip(bars, availability_rates):
            axes[1, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                           f'{rate:.1f}%', ha='center', va='bottom', fontweight='bold')
    else:
        axes[1, 1].text(0.5, 0.5, '关键变量\n不可用', 
                       ha='center', va='center', transform=axes[1, 1].transAxes, fontsize=14)
        axes[1, 1].set_title('关键变量数据可用性')
    
    plt.tight_layout()
    plt.savefig('数据预处理_数据质量分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
#初步相关性分析图表
def create_preliminary_correlation_plots(df):
    # 选择数值变量进行相关性分析
    numeric_vars = [
        '年龄', '身高', '体重', '孕妇BMI', 
        '末次月经距检测日天数', '检测时怀孕天数',
        'Y染色体浓度', 'Y染色体的Z值', 'GC含量',
        'IVF妊娠_编码', '怀孕次数_编码', '胎儿健康_编码'
    ]
    available_vars = [var for var in numeric_vars if var in df.columns]
    if len(available_vars) < 3:
        print("可用数值变量不足3个，跳过相关性分析")
        return
    # 创建相关性数据
    corr_data = df[available_vars].select_dtypes(include=[np.number]).dropna()
    
    if len(corr_data) == 0:
        print("没有足够的数值数据进行相关性分析")
        return
    
    correlation_matrix = corr_data.corr()
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle('初步相关性分析', fontsize=16, fontweight='bold')
    
    # 1. 相关性热图
    mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
    sns.heatmap(correlation_matrix, mask=mask, annot=False, cmap='RdBu_r', center=0,
                square=True, fmt='.3f', cbar_kws={"shrink": .8}, ax=axes[0])
    axes[0].set_title('变量间相关性热图')
    
    # 2. 与Y染色体浓度的相关性
    if 'Y染色体浓度' in correlation_matrix.columns:
        y_correlations = correlation_matrix['Y染色体浓度'].drop('Y染色体浓度')
        y_correlations = y_correlations.sort_values(key=abs, ascending=False)
        
        colors = ['red' if x < 0 else 'blue' for x in y_correlations.values]
        bars = axes[1].barh(range(len(y_correlations)), y_correlations.values, 
                           color=colors, alpha=0.7)
        axes[1].set_yticks(range(len(y_correlations)))
        axes[1].set_yticklabels(y_correlations.index)
        axes[1].set_xlabel('相关系数')
        axes[1].set_title('与Y染色体浓度的相关性')
        axes[1].axvline(x=0, color='black', linestyle='-', linewidth=1)
        axes[1].grid(True, alpha=0.3, axis='x')
        
        # 添加相关系数标签
        for i, (bar, value) in enumerate(zip(bars, y_correlations.values)):
            x_pos = value + (0.01 if value > 0 else -0.01)
            ha_pos = 'left' if value > 0 else 'right'
            axes[1].text(x_pos, i, f'{value:.3f}', va='center', ha=ha_pos, 
                        fontweight='bold', fontsize=9)
    else:
        var_correlations = {}
        for var in correlation_matrix.columns:
            other_correlations = correlation_matrix[var].drop(var)
            avg_correlation = other_correlations.abs().mean()
            var_correlations[var] = avg_correlation
        
        sorted_vars = sorted(var_correlations.items(), key=lambda x: x[1], reverse=True)
        
        variables = [item[0] for item in sorted_vars]
        correlations = [item[1] for item in sorted_vars]
        
        bars = axes[1].barh(range(len(variables)), correlations, 
                           color='steelblue', alpha=0.7)
        axes[1].set_yticks(range(len(variables)))
        axes[1].set_yticklabels(variables)
        axes[1].set_xlabel('平均相关性强度')
        axes[1].set_title('变量相关性强度排序')
        axes[1].grid(True, alpha=0.3, axis='x')
        
        # 添加数值标签
        for i, (bar, value) in enumerate(zip(bars, correlations)):
            axes[1].text(bar.get_width() + 0.005, i, f'{value:.3f}', 
                        va='center', fontweight='bold', fontsize=9)
    
    plt.tight_layout()
    plt.savefig('数据预处理_初步相关性分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, "附件.xlsx")
        # 执行数据预处理（启用可视化）
    final_data, full_processed_data = preprocess_male_nipt_data(
            file_path, 
            enable_visualization=True  
        )
        # 保存处理后的数据
    final_data.to_csv("男胎_预处理数据_精简版.csv", 
                         index=False, encoding='utf-8-sig')
    full_processed_data.to_csv("男胎_预处理数据_完整版.csv", 
                                  index=False, encoding='utf-8-sig')
