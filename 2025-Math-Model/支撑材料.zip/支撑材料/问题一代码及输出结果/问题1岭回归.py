import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import train_test_split, cross_val_score, validation_curve
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10

def ridge_regression_detailed_analysis(df):
    # 1. 数据准备和特征工程
    # 因变量
    y_var = 'Y染色体浓度'
    # 基础特征
    base_features = [
        '孕妇BMI', '检测时怀孕天数', '年龄', '体重', '身高',
        'X染色体浓度', '18号染色体的Z值', 'Y染色体的Z值', 
        '13号染色体的Z值', '21号染色体的Z值', 'X染色体的Z值',
        'GC含量', '末次月经距检测日天数',
        'IVF妊娠_编码', '怀孕次数_编码', '胎儿健康_编码',
        'T13_异常', 'T18_异常', 'T21_异常'
    ]
    # 检查可用特征
    available_features = [f for f in base_features if f in df.columns]
    model_data = df[[y_var] + available_features].dropna()
    print(f"建模样本数: {len(model_data)} (原始: {len(df)})")
    print(f"使用特征数: {len(available_features)}")
    
    X = model_data[available_features]
    y = model_data[y_var]
    
    # 特征工程
    X_engineered = X.copy()
    
    # 添加重要的交互特征
    interaction_features = []
    if '孕妇BMI' in X.columns and '检测时怀孕天数' in X.columns:
        X_engineered['BMI_x_孕周'] = X['孕妇BMI'] * X['检测时怀孕天数']
        interaction_features.append('BMI_x_孕周')
    
    if '年龄' in X.columns and '孕妇BMI' in X.columns:
        X_engineered['年龄_x_BMI'] = X['年龄'] * X['孕妇BMI']
        interaction_features.append('年龄_x_BMI')
    
    if 'Y染色体的Z值' in X.columns and 'X染色体浓度' in X.columns:
        X_engineered['Y_Z值_x_X浓度'] = X['Y染色体的Z值'] * X['X染色体浓度']
        interaction_features.append('Y_Z值_x_X浓度')
    
    # 添加多项式特征
    polynomial_features = []
    poly_vars = ['孕妇BMI', '检测时怀孕天数', '年龄']
    for var in poly_vars:
        if var in X.columns:
            X_engineered[f'{var}_平方'] = X[var] ** 2
            polynomial_features.append(f'{var}_平方')
    
    print(f"添加交互特征: {interaction_features}")
    print(f"添加多项式特征: {polynomial_features}")
    print(f"最终特征数: {X_engineered.shape[1]}")
    
    # 2. 特征重要性预分析
    # 计算所有特征与Y染色体浓度的相关系数
    correlations = []
    for col in X_engineered.columns:
        corr, p_value = stats.spearmanr(X_engineered[col], y)
        correlations.append({
            '特征名': col,
            '相关系数': corr,
            'p值': p_value,
            '显著性': '***' if p_value < 0.001 else '**' if p_value < 0.01 else '*' if p_value < 0.05 else 'n.s.',
            '绝对相关系数': abs(corr)
        })
    
    corr_df = pd.DataFrame(correlations).sort_values('绝对相关系数', ascending=False)
    print("特征相关性排序 (Top 15):")
    print(corr_df.head(15)[['特征名', '相关系数', 'p值', '显著性']].to_string(index=False, float_format='%.4f'))
    
    # 3. 数据分割和标准化
    X_train, X_test, y_train, y_test = train_test_split(
        X_engineered, y, test_size=0.2, random_state=42
    )
    
    # 标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # 转换为DataFrame保持列名
    X_train_scaled_df = pd.DataFrame(X_train_scaled, columns=X_train.columns, index=X_train.index)
    X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X_test.columns, index=X_test.index)
    
    print(f"训练集样本数: {len(X_train)}")
    print(f"测试集样本数: {len(X_test)}")
    print("特征已标准化 (均值=0, 标准差=1)")
    
    # 4. Ridge回归超参数优化
    # 使用交叉验证选择最优alpha
    alphas = np.logspace(-3, 3, 50)  # 从0.001到1000
    ridge_cv = RidgeCV(alphas=alphas, cv=5, scoring='r2')
    ridge_cv.fit(X_train_scaled, y_train)
    
    optimal_alpha = ridge_cv.alpha_
    print(f"最优正则化参数 α = {optimal_alpha:.6f}")
    
    # 绘制validation curve
    train_scores, val_scores = validation_curve(
        Ridge(), X_train_scaled, y_train, 
        param_name='alpha', param_range=alphas, cv=5, scoring='r2'
    )
    
    plt.figure(figsize=(12, 8))
    #[8]AI协助添加过程可视化使其更具可解释性
    # 子图1: 验证曲线
    plt.subplot(2, 2, 1)
    plt.semilogx(alphas, np.mean(train_scores, axis=1), 'b-', label='训练集R²', linewidth=2)
    plt.semilogx(alphas, np.mean(val_scores, axis=1), 'r-', label='验证集R²', linewidth=2)
    plt.axvline(x=optimal_alpha, color='green', linestyle='--', label=f'最优α={optimal_alpha:.4f}')
    plt.xlabel('正则化参数 α')
    plt.ylabel('R² 分数')
    plt.title('Ridge回归超参数优化')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 5. 构建最优Ridge模型
    ridge_model = Ridge(alpha=optimal_alpha)
    ridge_model.fit(X_train_scaled, y_train)
    
    # 预测
    y_train_pred = ridge_model.predict(X_train_scaled)
    y_test_pred = ridge_model.predict(X_test_scaled)
    
    # 计算指标
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    test_mae = mean_absolute_error(y_test, y_test_pred)
    
    print(f"训练集 R² = {train_r2:.4f}")
    print(f"测试集 R² = {test_r2:.4f}")
    print(f"RMSE = {test_rmse:.6f}")
    print(f"MAE = {test_mae:.6f}")
    
    # 6. Ridge模型系数分析
    print("\n6. Ridge模型系数详细分析")
    print("-"*60)
    
    # 获取系数
    coefficients = ridge_model.coef_
    feature_names = X_train.columns
    
    # 创建系数DataFrame
    coef_df = pd.DataFrame({
        '特征名': feature_names,
        '原始系数': coefficients,
        '标准化系数': coefficients,  # 因为输入已标准化
        '系数绝对值': np.abs(coefficients)
    }).sort_values('系数绝对值', ascending=False)
    
    # 计算特征对标准差变化的影响
    coef_df['标准差影响'] = coef_df['标准化系数'] * X_train.std()
    coef_df['特征类型'] = coef_df['特征名'].apply(lambda x: 
        '交互特征' if any(inter in x for inter in ['_x_', 'x']) else
        '多项式特征' if '平方' in x else
        '分类特征' if x in ['IVF妊娠_编码', '怀孕次数_编码', '胎儿健康_编码', 'T13_异常', 'T18_异常', 'T21_异常'] else
        '连续特征'
    )
    
    print("Ridge回归系数排序 (按绝对值):")
    print(coef_df[['特征名', '标准化系数', '系数绝对值', '特征类型']].head(15).to_string(index=False, float_format='%.6f'))
    
    # 子图2: 系数重要性条形图
    plt.subplot(2, 2, 2)
    top_features = coef_df.head(12)
    colors = ['red' if x < 0 else 'blue' for x in top_features['标准化系数']]
    bars = plt.barh(range(len(top_features)), top_features['标准化系数'], color=colors, alpha=0.7)
    plt.yticks(range(len(top_features)), top_features['特征名'], fontsize=8)
    plt.xlabel('标准化系数')
    plt.title('Top 12 特征系数')
    plt.axvline(x=0, color='black', linestyle='-', alpha=0.3)
    plt.grid(True, alpha=0.3)
    
    # 添加数值标签
    for i, (bar, value) in enumerate(zip(bars, top_features['标准化系数'])):
        plt.text(value + (0.005 if value > 0 else -0.005), i, f'{value:.3f}', 
                va='center', ha='left' if value > 0 else 'right', fontsize=7)
    
    # 7. 特征类型分析
    feature_type_analysis = coef_df.groupby('特征类型').agg({
        '系数绝对值': ['count', 'mean', 'sum'],
        '标准化系数': lambda x: np.sum(np.abs(x))
    }).round(4)
    
    print("按特征类型统计:")
    print(feature_type_analysis.to_string())
    
    # 子图3: 特征类型贡献饼图
    plt.subplot(2, 2, 3)
    type_contributions = coef_df.groupby('特征类型')['系数绝对值'].sum()
    plt.pie(type_contributions.values, labels=type_contributions.index, autopct='%1.1f%%', startangle=90)
    plt.title('不同特征类型的贡献占比')
    
    # 8. 回归方程展示
    intercept = ridge_model.intercept_
    print(f"Y染色体浓度 = {intercept:.6f}")
    
    # 显示重要特征的回归方程
    important_features = coef_df.head(10)
    for _, row in important_features.iterrows():
        feature_name = row['特征名']
        coef = row['标准化系数']
        sign = "+" if coef >= 0 else ""
        print(f"           {sign} {coef:.6f} × {feature_name}_标准化")
    
    # 9. 模型预测效果可视化
    # 子图4: 预测值 vs 实际值散点图
    plt.subplot(2, 2, 4)
    plt.scatter(y_test, y_test_pred, alpha=0.6, color='blue', s=30)
    
    # 绘制完美预测线
    min_val = min(y_test.min(), y_test_pred.min())
    max_val = max(y_test.max(), y_test_pred.max())
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='完美预测线')
    
    plt.xlabel('实际值')
    plt.ylabel('预测值')
    plt.title(f'预测效果 (R² = {test_r2:.3f})')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 添加R²和RMSE标注
    plt.text(0.05, 0.95, f'R² = {test_r2:.4f}\nRMSE = {test_rmse:.6f}', 
             transform=plt.gca().transAxes, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    plt.savefig('Ridge回归详细分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
    
    # 10. 残差分析
    residuals = y_test - y_test_pred
    
    plt.figure(figsize=(15, 10))
    
    # 残差图1: 残差vs预测值
    plt.subplot(2, 3, 1)
    plt.scatter(y_test_pred, residuals, alpha=0.6)
    plt.axhline(y=0, color='red', linestyle='--')
    plt.xlabel('预测值')
    plt.ylabel('残差')
    plt.title('残差 vs 预测值')
    plt.grid(True, alpha=0.3)
    
    # 残差图2: 残差直方图
    plt.subplot(2, 3, 2)
    plt.hist(residuals, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
    plt.xlabel('残差')
    plt.ylabel('频数')
    plt.title('残差分布直方图')
    plt.axvline(residuals.mean(), color='red', linestyle='--', label=f'均值: {residuals.mean():.6f}')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 残差图3: QQ图
    plt.subplot(2, 3, 3)
    stats.probplot(residuals, dist="norm", plot=plt)
    plt.title('残差正态性QQ图')
    plt.grid(True, alpha=0.3)
    
    # 残差图4: 残差vs主要特征
    if 'X染色体浓度' in X_test.columns:
        plt.subplot(2, 3, 4)
        plt.scatter(X_test['X染色体浓度'], residuals, alpha=0.6)
        plt.axhline(y=0, color='red', linestyle='--')
        plt.xlabel('X染色体浓度')
        plt.ylabel('残差')
        plt.title('残差 vs X染色体浓度')
        plt.grid(True, alpha=0.3)
    
    # 残差图5: 残差vs另一主要特征
    if '检测时怀孕天数' in X_test.columns:
        plt.subplot(2, 3, 5)
        plt.scatter(X_test['检测时怀孕天数'], residuals, alpha=0.6)
        plt.axhline(y=0, color='red', linestyle='--')
        plt.xlabel('检测时怀孕天数')
        plt.ylabel('残差')
        plt.title('残差 vs 检测时怀孕天数')
        plt.grid(True, alpha=0.3)
    
    # 残差图6: 残差绝对值vs预测值
    plt.subplot(2, 3, 6)
    plt.scatter(y_test_pred, np.abs(residuals), alpha=0.6)
    plt.xlabel('预测值')
    plt.ylabel('残差绝对值')
    plt.title('残差绝对值 vs 预测值')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('Ridge回归残差分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
    
    # 残差统计
    shapiro_stat, shapiro_p = stats.shapiro(residuals)
    print(f"残差正态性检验 (Shapiro-Wilk): 统计量={shapiro_stat:.4f}, p值={shapiro_p:.6f}")
    print(f"残差均值: {residuals.mean():.6f}")
    print(f"残差标准差: {residuals.std():.6f}")
    print(f"残差范围: [{residuals.min():.6f}, {residuals.max():.6f}]")
    
    # 11. 特征重要性详细分析
    # 创建特征重要性热力图
    plt.figure(figsize=(12, 10))
    
    # 选择top 20特征绘制热力图
    top_20_features = coef_df.head(20)
    
    # 准备数据 - 创建系数矩阵用于热力图
    coef_matrix = top_20_features[['标准化系数']].T
    coef_matrix.columns = top_20_features['特征名']
    
    # 绘制热力图
    plt.subplot(2, 1, 1)
    sns.heatmap(coef_matrix, annot=True, cmap='RdBu_r', center=0, 
                fmt='.3f', cbar_kws={'label': '标准化系数'})
    plt.title('Top 20 特征的Ridge回归系数热力图')
    plt.xlabel('')
    plt.ylabel('')
    
    # 特征分类条形图
    plt.subplot(2, 1, 2)
    feature_types = coef_df['特征类型'].value_counts()
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
    bars = plt.bar(feature_types.index, feature_types.values, color=colors[:len(feature_types)])
    plt.title('不同类型特征的数量分布')
    plt.ylabel('特征数量')
    plt.xticks(rotation=45)
    
    # 添加数值标签
    for bar, value in zip(bars, feature_types.values):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                str(value), ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('Ridge回归特征重要性分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
    
    # 12. 模型解释总结
    print("\n12. Ridge回归模型解释总结")
    print("-"*60)
    
    # 最重要的5个正向特征
    positive_features = coef_df[coef_df['标准化系数'] > 0].head(5)
    # 最重要的5个负向特征
    negative_features = coef_df[coef_df['标准化系数'] < 0].head(5)
    
    print("最重要的正向影响因子 (增加Y染色体浓度):")
    for i, (_, row) in enumerate(positive_features.iterrows(), 1):
        print(f"  {i}. {row['特征名']}: 系数={row['标准化系数']:.4f} ({row['特征类型']})")
    
    print("\n最重要的负向影响因子 (减少Y染色体浓度):")
    for i, (_, row) in enumerate(negative_features.iterrows(), 1):
        print(f"  {i}. {row['特征名']}: 系数={row['标准化系数']:.4f} ({row['特征类型']})")
    
    print(f"\n模型性能总结:")
    print(f"  • 解释方差: {test_r2*100:.2f}%")
    print(f"  • 平均绝对误差: {test_mae:.6f}")
    print(f"  • 相对误差: {test_mae/y.mean()*100:.2f}%")
    print(f"  • 正则化参数: α = {optimal_alpha:.6f}")
    
    print(f"\n关键发现:")
    most_important = coef_df.iloc[0]
    print(f"  • 最关键因子: {most_important['特征名']} (系数={most_important['标准化系数']:.4f})")
    print(f"  • 特征工程效果: 添加了{len(interaction_features + polynomial_features)}个衍生特征")
    print(f"  • 模型复杂度: 使用{len(feature_names)}个特征，正则化防止过拟合")
    
    # 13. 保存详细结果
    # 保存系数分析
    coef_df.to_csv("Ridge回归系数详细分析.csv", index=False, encoding='utf-8-sig')
    
    # 保存预测结果
    prediction_analysis = pd.DataFrame({
        '样本序号': range(len(y_test)),
        '实际值': y_test.values,
        '预测值': y_test_pred,
        '残差': residuals,
        '绝对误差': np.abs(residuals),
        '相对误差(%)': np.abs(residuals) / y_test.values * 100,
        '误差等级': pd.cut(np.abs(residuals), bins=3, labels=['小误差', '中等误差', '大误差'])
    })
    prediction_analysis.to_csv("Ridge回归预测详细分析.csv", index=False, encoding='utf-8-sig')
    
    # 保存特征相关性分析
    corr_df.to_csv("特征相关性详细分析.csv", index=False, encoding='utf-8-sig')
    
    print("已保存以下分析文件:")
    print("  • Ridge回归系数详细分析.csv - 所有特征系数和重要性")
    print("  • Ridge回归预测详细分析.csv - 每个样本的预测详情")
    print("  • 特征相关性详细分析.csv - 特征与因变量的相关性")
    print("  • Ridge回归详细分析.png - 主要分析图表")
    print("  • Ridge回归残差分析.png - 残差诊断图表")
    print("  • Ridge回归特征重要性分析.png - 特征重要性图表")
    
    return {
        'model': ridge_model,
        'scaler': scaler,
        'coefficients': coef_df,
        'predictions': prediction_analysis,
        'correlations': corr_df,
        'optimal_alpha': optimal_alpha,
        'performance_metrics': {
            'train_r2': train_r2,
            'test_r2': test_r2,
            'rmse': test_rmse,
            'mae': test_mae
        },
        'feature_names': feature_names.tolist()
    }
if __name__ == "__main__":
        df = pd.read_csv("男胎_预处理数据_完整版.csv")
        results = ridge_regression_detailed_analysis(df)