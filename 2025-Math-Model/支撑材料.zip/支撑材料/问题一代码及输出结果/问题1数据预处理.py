import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import re
import os
from scipy import stats
from scipy.stats import normaltest, shapiro, pearsonr, spearmanr, f_oneway, kruskal
#文件读取和修改变量
#[13]AI构建了一个包含核心功能模块的初始代码框架,再自行根据实际问题要求进行修改和完善
def preprocess_male_nipt_data(file_path):
    df = pd.read_excel(file_path, sheet_name='男胎检测数据')
    processed_df = df.copy()
    #将末次月经日期+检测日期转化变量为末次月经距检测日天数
    def calculate_days_from_lmp(row):
        try:
            lmp_date = pd.to_datetime(row['末次月经'])
            detection_date_str = str(int(row['检测日期']))
            detection_date = pd.to_datetime(detection_date_str, format='%Y%m%d')
            days_diff = (detection_date - lmp_date).days
            return days_diff
        except:
            return np.nan
    processed_df['末次月经距检测日天数'] = processed_df.apply(calculate_days_from_lmp, axis=1)

    # IVF妊娠转换为分类变量，创建数值编码和标签映射
    ivf_mapping = {
        '自然受孕': 0,
        'IUI（人工授精）': 1, 
        'IVF（试管婴儿）': 2
    }
    processed_df['IVF妊娠_编码'] = processed_df['IVF妊娠'].map(ivf_mapping)
    # 改为二进制形式（1和0的数值格式）
    ivf_dummies = pd.get_dummies(processed_df['IVF妊娠'], prefix='IVF', dtype=int)
    processed_df = pd.concat([processed_df, ivf_dummies], axis=1)

    # 将检测孕周转换为检测时怀孕天数
    def parse_gestational_weeks(week_str):
        try:
            if pd.isna(week_str):
                return np.nan
            week_str = str(week_str).strip()
            if 'w' in week_str:
                if '+' in week_str:
                    weeks_part, days_part = week_str.split('+')
                    weeks = int(weeks_part.replace('w', ''))
                    days = int(days_part)
                else:
                    weeks = int(week_str.replace('w', ''))
                    days = 0
                total_days = weeks * 7 + days
                return total_days
            else:
                return np.nan
        except:
            return np.nan
    
    processed_df['检测时怀孕天数'] = processed_df['检测孕周'].apply(parse_gestational_weeks)
    
    # 将染色体非整倍体信息处理为T13、T18、T21异常标记
    def parse_chromosome_abnormality(abnormality_str):
        # 初始化结果
        result = {'T13': 0, 'T18': 0, 'T21': 0}
        if pd.isna(abnormality_str) or abnormality_str == '' or abnormality_str is None:
            return result
        abnormality_str = str(abnormality_str).strip()
        # 检查是否包含各种异常标记
        if 'T13' in abnormality_str:
            result['T13'] = 1
        if 'T18' in abnormality_str:
            result['T18'] = 1  
        if 'T21' in abnormality_str:
            result['T21'] = 1
        return result
    chromosome_results = processed_df['染色体的非整倍体'].apply(parse_chromosome_abnormality)
    processed_df['T13_异常'] = [result['T13'] for result in chromosome_results]
    processed_df['T18_异常'] = [result['T18'] for result in chromosome_results]
    processed_df['T21_异常'] = [result['T21'] for result in chromosome_results]
    
    #怀孕次数转换为分类变量，创建数值编码和二进制形式
    def categorize_pregnancy_count(count):
        if pd.isna(count):
            return np.nan
        if count == 1:
            return '初产妇'
        elif count == 2:
            return '经产妇_2次'
        else: 
            return '经产妇_多次'
    
    processed_df['怀孕次数_分类'] = processed_df['怀孕次数'].apply(categorize_pregnancy_count)
    pregnancy_mapping = {
        '初产妇': 0,
        '经产妇_2次': 1,
        '经产妇_多次': 2
    }
    processed_df['怀孕次数_编码'] = processed_df['怀孕次数_分类'].map(pregnancy_mapping)
    pregnancy_dummies = pd.get_dummies(processed_df['怀孕次数_分类'], prefix='怀孕次数', dtype=int)
    processed_df = pd.concat([processed_df, pregnancy_dummies], axis=1)
    # 胎儿健康状况转换为二分类变量，1表示健康，0表示不健康
    health_mapping = {
        '是': 1,  
        '否': 0   
    }
    processed_df['胎儿健康_编码'] = processed_df['胎儿是否健康'].map(health_mapping)
    key_columns = [
        # 原始标识字段
        '序号', '孕妇代码', '年龄', '身高', '体重', '孕妇BMI',
        # 预处理后的字段  
        '末次月经距检测日天数', 'IVF妊娠_编码', '检测时怀孕天数',
        'T13_异常', 'T18_异常', 'T21_异常', 
        '怀孕次数_编码', '胎儿健康_编码',
        # 重要的检测指标
        'Y染色体浓度', 'Y染色体的Z值', 
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值',
        'X染色体的Z值', 'GC含量',
        # 哑变量
        'IVF_自然受孕', 'IVF_IUI（人工授精）', 'IVF_IVF（试管婴儿）',
        '怀孕次数_初产妇', '怀孕次数_经产妇_2次', '怀孕次数_经产妇_多次'
    ]
    available_columns = [col for col in key_columns if col in processed_df.columns]
    final_df = processed_df[available_columns].copy()
    return final_df, processed_df
def correlation_analysis_y_chromosome_with_csv(df, output_file="Y染色体浓度相关性检验结果.csv"):
    # 因变量：Y染色体浓度
    y_var = 'Y染色体浓度'
    
    if y_var not in df.columns:
        print("错误：数据中没有找到 {} 列".format(y_var))
        return
    
    # 去除Y染色体浓度的缺失值
    df_clean = df.dropna(subset=[y_var]).copy()
    print("有效样本数: {}".format(len(df_clean)))
    
    # Y染色体浓度描述统计
    y_stats = {
        '均值': float(df_clean[y_var].mean()),
        '标准差': float(df_clean[y_var].std()),
        '中位数': float(df_clean[y_var].median()),
        '最小值': float(df_clean[y_var].min()),
        '最大值': float(df_clean[y_var].max())
    }
    
    print("Y染色体浓度描述统计:")
    for key, value in y_stats.items():
        print("  {}: {:.6f}".format(key, value))
    
    # 检验Y染色体浓度的正态性
    print("\n" + "-"*40)
    print("Y染色体浓度正态性检验:")
    print("-"*40)
    
    if len(df_clean) < 5000:
        y_shapiro_stat, y_shapiro_p = shapiro(df_clean[y_var])
        print("Shapiro-Wilk检验: 统计量={:.4f}, p值={:.6f}".format(y_shapiro_stat, y_shapiro_p))
        y_normal = y_shapiro_p > 0.05
    else:
        y_dagostino_stat, y_dagostino_p = normaltest(df_clean[y_var])
        print("D'Agostino检验: 统计量={:.4f}, p值={:.6f}".format(y_dagostino_stat, y_dagostino_p))
        y_normal = y_dagostino_p > 0.05
    
    print("  结论: Y染色体浓度{}符合正态分布".format("" if y_normal else "不"))
    
    # 定义变量类型
    continuous_vars = [
        '年龄', '身高', '体重', '孕妇BMI', 
        '末次月经距检测日天数', '检测时怀孕天数',
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值', 
        'X染色体的Z值', 'Y染色体的Z值',
        'X染色体浓度', 'GC含量'
    ]
    
    # 有序分类变量
    ordinal_vars = [
        '怀孕次数_编码'  # 0=初产妇, 1=经产妇_2次, 2=经产妇_多次
    ]
    
    # 无序分类变量
    nominal_vars = [
        'IVF妊娠_编码',  # 0=自然受孕, 1=IUI, 2=IVF
        'T13_异常', 'T18_异常', 'T21_异常',
        '胎儿健康_编码'
    ]
    
    # 存储所有结果
    all_results = []
    
    #连续变量相关性检验
    print("\n" + "-"*40)
    print("连续变量相关性检验:")
    print("-"*40)
    
    for var in continuous_vars:
        if var in df_clean.columns:
            # 去除该变量的缺失值
            temp_df = df_clean[[y_var, var]].dropna()
            
            if len(temp_df) < 3:
                print("{}: 样本量不足，跳过".format(var))
                continue
            
            # 检验当前变量的正态性
            if len(temp_df) < 5000:
                var_shapiro_stat, var_shapiro_p = shapiro(temp_df[var])
                var_normal = var_shapiro_p > 0.05
                normality_test = "Shapiro-Wilk"
                normality_stat = var_shapiro_stat
                normality_p = var_shapiro_p
            else:
                var_dagostino_stat, var_dagostino_p = normaltest(temp_df[var])
                var_normal = var_dagostino_p > 0.05
                normality_test = "D'Agostino"
                normality_stat = var_dagostino_stat
                normality_p = var_dagostino_p
            
            # 选择相关性检验方法：两个变量都正态才用皮尔逊
            if y_normal and var_normal:
                corr_coef, p_value = pearsonr(temp_df[var], temp_df[y_var])
                method = "皮尔逊相关"
            else:
                corr_coef, p_value = spearmanr(temp_df[var], temp_df[y_var])
                method = "斯皮尔曼相关"
            
            # 判断显著性
            significance = ""
            if p_value < 0.001:
                significance = "***"
            elif p_value < 0.01:
                significance = "**"
            elif p_value < 0.05:
                significance = "*"
            else:
                significance = "n.s."
            
            print("{:25s}: {}={:8.4f}, p值={:.6f} {}".format(
                var, method, corr_coef, p_value, significance))
            print("{:25s}  (变量正态性: {}, 统计量={:.4f}, p={:.6f})".format(
                "", "是" if var_normal else "否", normality_stat, normality_p))
            
            # 存储结果
            result = {
                '变量名': var,
                '变量类型': '连续变量',
                '样本量': len(temp_df),
                '检验方法': method,
                '相关系数/统计量': corr_coef,
                'p值': p_value,
                '显著性': significance,
                '变量正态性': "是" if var_normal else "否",
                '正态性检验': normality_test,
                '正态性统计量': normality_stat,
                '正态性p值': normality_p,
                '备注': ""
            }
            all_results.append(result)
    
    # ===== 2. 有序分类变量相关性检验 =====
    print("\n" + "-"*40)
    print("有序分类变量相关性检验 (斯皮尔曼):")
    print("-"*40)
    
    for var in ordinal_vars:
        if var in df_clean.columns:
            temp_df = df_clean[[y_var, var]].dropna()
            
            if len(temp_df) < 3:
                print("{}: 样本量不足，跳过".format(var))
                continue
            
            corr_coef, p_value = spearmanr(temp_df[var], temp_df[y_var])
            
            # 判断显著性
            significance = ""
            if p_value < 0.001:
                significance = "***"
            elif p_value < 0.01:
                significance = "**"
            elif p_value < 0.05:
                significance = "*"
            else:
                significance = "n.s."
            
            print("{:25s}: 斯皮尔曼相关系数={:8.4f}, p值={:.6f} {}".format(
                var, corr_coef, p_value, significance))
            
            # 显示各组的描述统计
            print("  各组统计:")
            categories = ['初产妇', '经产妇_2次', '经产妇_多次']
            unique_vals = sorted(temp_df[var].unique())
            
            group_info = []
            for i, val in enumerate(unique_vals):
                group_data = temp_df[temp_df[var] == val][y_var]
                cat_name = categories[i] if i < len(categories) else "类别{}".format(i)
                
                count_val = len(group_data)
                mean_val = float(group_data.mean()) if len(group_data) > 0 else 0.0
                median_val = float(group_data.median()) if len(group_data) > 0 else 0.0
                
                print("    {}: n={:3d}, 均值={:.6f}, 中位数={:.6f}".format(
                    cat_name, count_val, mean_val, median_val))
                group_info.append("{}(n={})".format(cat_name, count_val))
            
            # 存储结果
            result = {
                '变量名': var,
                '变量类型': '有序分类变量',
                '样本量': len(temp_df),
                '检验方法': '斯皮尔曼相关',
                '相关系数/统计量': corr_coef,
                'p值': p_value,
                '显著性': significance,
                '变量正态性': "N/A",
                '正态性检验': "N/A",
                '正态性统计量': np.nan,
                '正态性p值': np.nan,
                '备注': "; ".join(group_info)
            }
            all_results.append(result)
    #无序分类变量方差检验
    print("\n" + "-"*40)
    print("无序分类变量方差检验:")
    print("-"*40)
    
    for var in nominal_vars:
        if var in df_clean.columns:
            temp_df = df_clean[[y_var, var]].dropna()
            
            if len(temp_df) < 3:
                print("{}: 样本量不足，跳过".format(var))
                continue
            
            # 获取各组数据
            groups = []
            group_names = []
            for group_val in sorted(temp_df[var].unique()):
                group_data = temp_df[temp_df[var] == group_val][y_var]
                if len(group_data) > 0:
                    groups.append(group_data)
                    group_names.append(group_val)
            
            if len(groups) < 2:
                print("{}: 分组数量不足，跳过".format(var))
                continue
            
            # 检验方差齐性（Levene检验）
            levene_stat, levene_p = stats.levene(*groups)
            
            if levene_p > 0.05:
                # 方差齐性，使用ANOVA
                f_stat, anova_p = f_oneway(*groups)
                test_method = "ANOVA F检验"
                test_stat = f_stat
                test_p = anova_p
            else:
                # 方差不齐，使用Kruskal-Wallis检验
                h_stat, kruskal_p = kruskal(*groups)
                test_method = "Kruskal-Wallis H检验"
                test_stat = h_stat
                test_p = kruskal_p
            
            # 判断显著性
            significance = ""
            if test_p < 0.001:
                significance = "***"
            elif test_p < 0.01:
                significance = "**"
            elif test_p < 0.05:
                significance = "*"
            else:
                significance = "n.s."
            
            print("{:25s}: {}".format(var, test_method))
            print("{:25s}   统计量={:8.4f}, p值={:.6f} {}".format(
                "", test_stat, test_p, significance))
            print("{:25s}   Levene检验p值={:.6f} (方差{})".format(
                "", levene_p, '齐性' if levene_p > 0.05 else '不齐'))
            
            print("  各组统计:")
            group_info = []
            for i, (group_val, group_data) in enumerate(zip(group_names, groups)):
                # 根据变量类型给出组名
                if var == 'IVF妊娠_编码':
                    group_label = ['自然受孕', 'IUI', 'IVF'][int(group_val)] if group_val < 3 else "组{}".format(group_val)
                elif var in ['T13_异常', 'T18_异常', 'T21_异常']:
                    group_label = '异常' if group_val == 1 else '正常'
                elif var == '胎儿健康_编码':
                    group_label = '健康' if group_val == 1 else '不健康'
                else:
                    group_label = "组{}".format(group_val)
                
                mean_val = float(group_data.mean()) if pd.notna(group_data.mean()) else 0.0
                median_val = float(group_data.median()) if pd.notna(group_data.median()) else 0.0
                
                print("    {}: n={:3d}, 均值={:.6f}, 中位数={:.6f}".format(
                    group_label, len(group_data), mean_val, median_val))
                group_info.append("{}(n={})".format(group_label, len(group_data)))
            result = {
                '变量名': var,
                '变量类型': '无序分类变量',
                '样本量': len(temp_df),
                '检验方法': test_method,
                '相关系数/统计量': test_stat,
                'p值': test_p,
                '显著性': significance,
                '变量正态性': "N/A",
                '正态性检验': "N/A",
                '正态性统计量': np.nan,
                '正态性p值': np.nan,
                '备注': "Levene检验p={:.6f}; {}".format(levene_p, "; ".join(group_info))
            }
            all_results.append(result)
    
    #保存结果到CSV
    print("\n" + "-"*60)
    print("保存结果到CSV文件:")
    print("-"*60)
    
    results_df = pd.DataFrame(all_results)
    
    # 添加Y染色体浓度的基本信息
    y_info = pd.DataFrame([{
        '变量名': 'Y染色体浓度(因变量)',
        '变量类型': '连续变量',
        '样本量': len(df_clean),
        '检验方法': 'Shapiro-Wilk' if len(df_clean) < 5000 else "D'Agostino",
        '相关系数/统计量': y_shapiro_stat if len(df_clean) < 5000 else y_dagostino_stat,
        'p值': y_shapiro_p if len(df_clean) < 5000 else y_dagostino_p,
        '显著性': "正态" if y_normal else "非正态",
        '变量正态性': "是" if y_normal else "否",
        '正态性检验': 'Shapiro-Wilk' if len(df_clean) < 5000 else "D'Agostino",
        '正态性统计量': y_shapiro_stat if len(df_clean) < 5000 else y_dagostino_stat,
        '正态性p值': y_shapiro_p if len(df_clean) < 5000 else y_dagostino_p,
        '备注': "因变量基本信息: 均值={:.6f}, 标准差={:.6f}".format(y_stats['均值'], y_stats['标准差'])
    }])
    
    # 合并所有结果
    final_results = pd.concat([y_info, results_df], ignore_index=True)
    final_results.to_csv(output_file, index=False, encoding='utf-8-sig')
    print("结果已保存到: {}".format(output_file))
    return final_results

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, "附件.xlsx")
    final_data, full_processed_data = preprocess_male_nipt_data(file_path)
    final_csv_path = os.path.join(current_dir, "男胎_预处理数据_精简版.csv")
    full_csv_path = os.path.join(current_dir, "男胎_预处理数据_完整版.csv")
    final_data.to_csv(final_csv_path, index=False, encoding='utf-8-sig')
    full_processed_data.to_csv(full_csv_path, index=False, encoding='utf-8-sig')
    results = correlation_analysis_y_chromosome_with_csv(full_processed_data, "Y染色体浓度相关性检验结果.csv")