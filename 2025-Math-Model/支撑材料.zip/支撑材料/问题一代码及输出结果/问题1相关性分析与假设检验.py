import matplotlib
matplotlib.use('Agg') #设置图形字体，避免冲突
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
#设置中文字体，以便区分；
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10
#保持中文字体
sns.set_style("whitegrid")
sns.set_palette("husl")
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']

#定义函数，使得最后每个图都是中文字体
def ensure_chinese_font(func):
    def wrapper(*args, **kwargs):
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']
        plt.rcParams['axes.unicode_minus'] = False
        return func(*args, **kwargs)
    return wrapper
@ensure_chinese_font
def plot_distribution_analysis(df, y_var='Y染色体浓度'):
    print("1. Y染色体浓度分布可视化分析")
    #再次设置中文字体
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']
    plt.rcParams['axes.unicode_minus'] = False
    #引入数据
    y_data = df[y_var].dropna()
    #[8]AI协助添加过程可视化使其更具可解释性
    #准备画图
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    #设置标题
    fig.suptitle('Y染色体浓度分布分析', fontsize=16, fontweight='bold', 
                 fontproperties='Microsoft YaHei')
    #绘制直方图与密度曲线
    axes[0, 0].hist(y_data, bins=40, density=True, alpha=0.7, color='skyblue', edgecolor='black')
    axes[0, 0].axvline(y_data.mean(), color='red', linestyle='--', linewidth=2, label=f'均值: {y_data.mean():.4f}')
    axes[0, 0].axvline(y_data.median(), color='orange', linestyle='--', linewidth=2, label=f'中位数: {y_data.median():.4f}')
    
    #绘制理论正态分布曲线，并设置字体
    x = np.linspace(y_data.min(), y_data.max(), 100)
    normal_curve = stats.norm.pdf(x, y_data.mean(), y_data.std())
    axes[0, 0].plot(x, normal_curve, 'g-', linewidth=2, label='理论正态分布')
    axes[0, 0].set_title('直方图与理论正态分布对比', fontproperties='Microsoft YaHei')
    axes[0, 0].set_xlabel('Y染色体浓度', fontproperties='Microsoft YaHei')
    axes[0, 0].set_ylabel('密度', fontproperties='Microsoft YaHei')
    axes[0, 0].legend(prop={'family': 'Microsoft YaHei'})
    axes[0, 0].grid(True, alpha=0.3)
    
    #绘制核密度估计图
    sns.kdeplot(data=y_data, ax=axes[0, 1], fill=True, color='lightcoral')
    axes[0, 1].axvline(y_data.mean(), color='red', linestyle='--', linewidth=2, label='均值')
    axes[0, 1].axvline(y_data.median(), color='orange', linestyle='--', linewidth=2, label='中位数')
    axes[0, 1].set_title('核密度估计')
    axes[0, 1].set_xlabel('Y染色体浓度')
    axes[0, 1].set_ylabel('密度')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    #绘制QQ图，用于正态性检验
    stats.probplot(y_data, dist="norm", plot=axes[0, 2])
    axes[0, 2].set_title('Q-Q图 (正态性检验)')
    axes[0, 2].grid(True, alpha=0.3)
    
    #绘制箱线图
    box_plot = axes[1, 0].boxplot(y_data, patch_artist=True, labels=['Y染色体浓度'])
    box_plot['boxes'][0].set_facecolor('lightblue')
    axes[1, 0].set_title('箱线图')
    axes[1, 0].set_ylabel('Y染色体浓度')
    axes[1, 0].grid(True, alpha=0.3)
    #添加新的统计信息
    Q1 = y_data.quantile(0.25)
    Q3 = y_data.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = y_data[(y_data < lower_bound) | (y_data > upper_bound)]
    
    axes[1, 0].text(0.02, 0.98, f'异常值数量: {len(outliers)} ({len(outliers)/len(y_data)*100:.1f}%)',
                    transform=axes[1, 0].transAxes, verticalalignment='top',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
    #经验累积分布函数
    sorted_data = np.sort(y_data)
    y_ecdf = np.arange(1, len(sorted_data) + 1) / len(sorted_data)
    axes[1, 1].plot(sorted_data, y_ecdf, marker='.', linestyle='-', alpha=0.7, color='purple')
    #添加理论正态分布CDF
    theoretical_cdf = stats.norm.cdf(sorted_data, y_data.mean(), y_data.std())
    axes[1, 1].plot(sorted_data, theoretical_cdf, 'r--', linewidth=2, label='理论正态CDF')
    
    axes[1, 1].set_title('经验累积分布函数 vs 理论正态CDF')
    axes[1, 1].set_xlabel('Y染色体浓度')
    axes[1, 1].set_ylabel('累积概率')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    #统计描述信息表
    axes[1, 2].axis('off')
    #对数据进行正态性检验
    shapiro_stat, shapiro_p = stats.shapiro(y_data) if len(y_data) <= 5000 else stats.normaltest(y_data)
    test_name = "Shapiro-Wilk" if len(y_data) <= 5000 else "D'Agostino"
    #偏度和峰度
    skewness = stats.skew(y_data)
    kurtosis = stats.kurtosis(y_data)
    stats_text = f'''统计描述信息:
    样本量: {len(y_data)}
    均值: {y_data.mean():.6f}
    标准差: {y_data.std():.6f}
    中位数: {y_data.median():.6f}
    最小值: {y_data.min():.6f}
    最大值: {y_data.max():.6f}
    分位数:
    25%: {Q1:.6f}
    75%: {Q3:.6f}
    四分位数间距: {IQR:.6f}
    形状参数:
    偏度: {skewness:.4f}
    峰度: {kurtosis:.4f}
    正态性检验 ({test_name}):
    统计量: {shapiro_stat:.4f}
    p值: {shapiro_p:.6f}
    结论: {'符合正态分布' if shapiro_p > 0.05 else '不符合正态分布'}
    '''
    axes[1, 2].text(0.05, 0.95, stats_text, transform=axes[1, 2].transAxes, 
                    verticalalignment='top', fontsize=10,
                    bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))
    plt.tight_layout()
    plt.savefig('Y染色体浓度分布分析.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    #输出关键发现
    print("\n关键发现:")
    print(f"• Y染色体浓度均值为 {y_data.mean():.6f}，标准差为 {y_data.std():.6f}")
    print(f"• 数据分布{'符合' if shapiro_p > 0.05 else '不符合'}正态分布 (p={shapiro_p:.6f})")
    print(f"• 偏度为 {skewness:.4f} ({'右偏' if skewness > 0 else '左偏' if skewness < 0 else '对称'})")
    print(f"• 峰度为 {kurtosis:.4f} ({'尖峰' if kurtosis > 0 else '平峰' if kurtosis < 0 else '正常峰度'})")
    print(f"• 发现 {len(outliers)} 个异常值 ({len(outliers)/len(y_data)*100:.1f}%)")
    
    return {
        'stats': {
            'mean': y_data.mean(),
            'std': y_data.std(),
            'median': y_data.median(),
            'min': y_data.min(),
            'max': y_data.max(),
            'q25': Q1,
            'q75': Q3,
            'iqr': IQR,
            'skewness': skewness,
            'kurtosis': kurtosis,
            'normality_test': test_name,
            'normality_stat': shapiro_stat,
            'normality_p': shapiro_p,
            'outliers_count': len(outliers)
        },
        'outliers': outliers
    }

def plot_correlation_heatmap(df):
    print("2. 相关性热图可视化分析")
    #选择表格中的数值型变量
    numeric_vars = [
        'Y染色体浓度', '年龄', '身高', '体重', '孕妇BMI', 
        '末次月经距检测日天数', '检测时怀孕天数',
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值', 
        'X染色体的Z值', 'Y染色体的Z值',
        'X染色体浓度', 'GC含量'
    ]
    #对已经存在的变量进行筛选
    available_vars = [var for var in numeric_vars if var in df.columns]
    correlation_data = df[available_vars].dropna()
    #算相关系数矩阵
    correlation_matrix = correlation_data.corr()
    
    #绘制热力图
    fig, axes = plt.subplots(1, 2, figsize=(20, 8))
    mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
    sns.heatmap(correlation_matrix, mask=mask, annot=True, cmap='RdBu_r', center=0,
                square=True, fmt='.3f', cbar_kws={"shrink": .8}, ax=axes[0])
    axes[0].set_title('变量间相关性热图 (下三角)', fontsize=14)
    
    #Y染色体浓度与其他变量的相关性条形图
    y_correlations = correlation_matrix['Y染色体浓度'].drop('Y染色体浓度').sort_values(key=abs, ascending=False)
    colors = ['red' if x < 0 else 'blue' for x in y_correlations.values]
    bars = axes[1].barh(range(len(y_correlations)), y_correlations.values, color=colors, alpha=0.7)
    axes[1].set_yticks(range(len(y_correlations)))
    axes[1].set_yticklabels(y_correlations.index, fontsize=10)
    axes[1].set_xlabel('相关系数')
    axes[1].set_title('Y染色体浓度与其他变量的相关性', fontsize=14)
    axes[1].axvline(x=0, color='black', linestyle='-', linewidth=0.5)
    axes[1].grid(True, alpha=0.3, axis='x')
    
    #设置标签
    for i, (bar, value) in enumerate(zip(bars, y_correlations.values)):
        axes[1].text(value + (0.01 if value > 0 else -0.01), i, f'{value:.3f}', 
                    va='center', ha='left' if value > 0 else 'right', fontsize=9)
    plt.tight_layout()
    plt.savefig('相关性分析热图.png', dpi=300, bbox_inches='tight')
    plt.show()
    #输出重要发现
    print(f"相关性分析基于 {len(correlation_data)} 个完整样本")
    print(f"\n与Y染色体浓度相关性最强的前5个变量:")
    for i, (var, corr) in enumerate(y_correlations.head(5).items(), 1):
        print(f"  {i}. {var}: {corr:.4f}")
    return {
        'correlation_matrix': correlation_matrix,
        'y_correlations': y_correlations,
        'sample_size': len(correlation_data)
    }
def plot_group_comparisons(df):
    print("3. 分组对比可视化分析")
    y_var = 'Y染色体浓度'
    # 定义分类变量和其标签映射
    categorical_vars = {
        '怀孕次数_编码': {0: '初产妇', 1: '经产妇_2次', 2: '经产妇_多次'},
        'IVF妊娠_编码': {0: '自然受孕', 1: 'IUI', 2: 'IVF'},
        '胎儿健康_编码': {0: '不健康', 1: '健康'},
        'T13_异常': {0: '正常', 1: '异常'},
        'T18_异常': {0: '正常', 1: '异常'},
        'T21_异常': {0: '正常', 1: '异常'}
    }
    available_cat_vars = {k: v for k, v in categorical_vars.items() if k in df.columns}

    #绘制子图
    n_vars = len(available_cat_vars)
    n_cols = 3
    n_rows = (n_vars + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 6*n_rows))
    if n_rows == 1:
        axes = axes.reshape(1, -1)
    elif n_vars == 1:
        axes = axes.reshape(1, 1)
    plot_idx = 0
    group_stats = {}
    for var_name, label_map in available_cat_vars.items():
        if plot_idx >= n_rows * n_cols:
            break
        row = plot_idx // n_cols
        col = plot_idx % n_cols
        ax = axes[row, col]
        #输入必要数据
        plot_data = df[[y_var, var_name]].dropna()
        if len(plot_data) == 0:
            ax.text(0.5, 0.5, f'{var_name}\n无可用数据', ha='center', va='center', 
                   transform=ax.transAxes, fontsize=12)
            ax.set_title(var_name)
            plot_idx += 1
            continue
        plot_data[f'{var_name}_label'] = plot_data[var_name].map(label_map)
        #将箱线图+小提琴图绘制，并输出于同一张图中
        parts = ax.violinplot([plot_data[plot_data[var_name] == val][y_var].values 
                              for val in sorted(plot_data[var_name].unique())],
                             positions=range(len(label_map)), showmeans=True, showmedians=True)
        #设置图形颜色
        colors = plt.cm.Set3(np.linspace(0, 1, len(label_map)))
        for pc, color in zip(parts['bodies'], colors):
            pc.set_facecolor(color)
            pc.set_alpha(0.7)
        #绘制箱线图，并设置标题与字体
        bp = ax.boxplot([plot_data[plot_data[var_name] == val][y_var].values 
                        for val in sorted(plot_data[var_name].unique())],
                       positions=range(len(label_map)), widths=0.3, patch_artist=False,
                       boxprops=dict(linewidth=2), medianprops=dict(linewidth=2, color='red'))
        ax.set_xticks(range(len(label_map)))
        ax.set_xticklabels([label_map[val] for val in sorted(plot_data[var_name].unique())], 
                          rotation=45, ha='right')
        ax.set_ylabel(y_var)
        ax.set_title(f'{var_name} 分组对比')
        ax.grid(True, alpha=0.3)
        
        #计算组间统计并进行方差检验
        group_data = []
        for val in sorted(plot_data[var_name].unique()):
            group_values = plot_data[plot_data[var_name] == val][y_var]
            group_data.append(group_values)
        if len(group_data) >= 2 and all(len(g) > 0 for g in group_data):
            from scipy.stats import f_oneway, kruskal, levene
            #使用Levene来检验方差齐性
            levene_stat, levene_p = levene(*group_data)
            if levene_p > 0.05:
                #如果方差为齐性，使用ANOVA方法
                f_stat, p_val = f_oneway(*group_data)
                test_name = "ANOVA"
            else:
                #如果方差不齐，则用Kruskal-Wallis方法检验
                f_stat, p_val = kruskal(*group_data)
                test_name = "Kruskal-Wallis"
            significance = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else "n.s."
            #添加统计检验结果到图中
            ax.text(0.02, 0.98, f'{test_name}: p={p_val:.4f} {significance}', 
                   transform=ax.transAxes, verticalalignment='top',
                   bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.7))
            group_stats[var_name] = {
                'test': test_name,
                'statistic': f_stat,
                'p_value': p_val,
                'significance': significance,
                'levene_p': levene_p
            }
        plot_idx += 1
    #对于多余的子图，不显示
    for i in range(plot_idx, n_rows * n_cols):
        row = i // n_cols
        col = i % n_cols
        axes[row, col].set_visible(False)
    plt.tight_layout()
    plt.savefig('分组对比分析.png', dpi=300, bbox_inches='tight')
    plt.show()
    #输出分组对比统计检验结果
    print("分组对比统计检验结果:")
    for var, stats_info in group_stats.items():
        print(f"• {var}: {stats_info['test']} p={stats_info['p_value']:.4f} {stats_info['significance']}")
    return group_stats

def plot_scatter_relationships(df):
    print("4. 散点图关系分析")


    y_var = 'Y染色体浓度'
    #对连续变量进行分析，选择表格中的连续变量
    key_vars = ['孕妇BMI', '检测时怀孕天数', '年龄', 'X染色体浓度', 'Y染色体的Z值', '18号染色体的Z值']
    available_vars = [var for var in key_vars if var in df.columns]
    if len(available_vars) < 2:
        print("可用变量不足，跳过散点图分析")
        return {}
    
    #构建散点图矩阵
    n_vars = len(available_vars)
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()
    for i, var in enumerate(available_vars[:6]):  # 最多显示6个
        if i >= len(axes):
            break
        #输出已读取的数据
        plot_data = df[[y_var, var]].dropna()
        if len(plot_data) == 0:
            axes[i].text(0.5, 0.5, f'{var}\n无数据', ha='center', va='center', 
                        transform=axes[i].transAxes)
            continue
        #绘制散点图
        axes[i].scatter(plot_data[var], plot_data[y_var], alpha=0.6, s=20, color='blue')
        
        #在散点图的基础上添加回归线
        try:
            from sklearn.linear_model import LinearRegression
            X = plot_data[var].values.reshape(-1, 1)
            y = plot_data[y_var].values
            reg = LinearRegression().fit(X, y)
            x_line = np.linspace(plot_data[var].min(), plot_data[var].max(), 100)
            y_line = reg.predict(x_line.reshape(-1, 1))
            axes[i].plot(x_line, y_line, 'r-', linewidth=2, label=f'R²={reg.score(X, y):.3f}')
            
            #计算相关系数，用于后文图片绘制
            corr_coef = plot_data[[var, y_var]].corr().iloc[0, 1]
            axes[i].set_xlabel(var)
            axes[i].set_ylabel(y_var)
            axes[i].set_title(f'{var} vs {y_var}\n相关系数: {corr_coef:.4f}')
            axes[i].legend()
            axes[i].grid(True, alpha=0.3)
        except Exception as e:
            print(f"绘制 {var} 的回归线时出错: {e}")
    
    #对于多余的子图，隐藏不输出
    for j in range(len(available_vars), len(axes)):
        axes[j].set_visible(False)
    plt.tight_layout()
    plt.savefig('散点图关系分析.png', dpi=300, bbox_inches='tight')
    plt.show()
    return available_vars

def plot_statistical_results(correlation_results_file):
    print("5. 统计检验结果可视化")
    
    try:
        #读取相关性检验结果
        results_df = pd.read_csv(correlation_results_file, encoding='utf-8-sig')
        #选出显著变量
        significant_vars = results_df[
            (results_df['p值'] < 0.05) & 
            (results_df['变量名'] != 'Y染色体浓度(因变量)')
        ].copy()
        if len(significant_vars) == 0:
            print("没有发现显著变量")
            return
        #绘制森林图
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 10))
        
        #第一个，p值森林图
        significant_vars_sorted = significant_vars.sort_values('p值')
        
        #计算-log10，用于后续可视化
        neg_log_p = -np.log10(significant_vars_sorted['p值'])
        
        colors = ['red' if p < 0.001 else 'orange' if p < 0.01 else 'yellow' 
                 for p in significant_vars_sorted['p值']]
        
        bars1 = ax1.barh(range(len(significant_vars_sorted)), neg_log_p, color=colors, alpha=0.7)
        ax1.set_yticks(range(len(significant_vars_sorted)))
        ax1.set_yticklabels(significant_vars_sorted['变量名'], fontsize=10)
        ax1.set_xlabel('-log10(p值)')
        ax1.set_title('显著性检验结果 (森林图)', fontsize=14)
        #在图上添加显著性阈值线
        ax1.axvline(-np.log10(0.05), color='green', linestyle='--', label='p=0.05')
        ax1.axvline(-np.log10(0.01), color='blue', linestyle='--', label='p=0.01')
        ax1.axvline(-np.log10(0.001), color='red', linestyle='--', label='p=0.001')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        #在图片上添加p值标签
        for i, (bar, p_val) in enumerate(zip(bars1, significant_vars_sorted['p值'])):
            ax1.text(neg_log_p.iloc[i] + 0.1, i, f'p={p_val:.4f}', 
                    va='center', fontsize=8)
        
        #第二歌，效应大小图
        effect_sizes = significant_vars_sorted['相关系数/统计量'].abs()
        colors2 = ['darkred' if abs(x) > 0.5 else 'red' if abs(x) > 0.3 else 'orange' if abs(x) > 0.1 else 'yellow'
                  for x in significant_vars_sorted['相关系数/统计量']]
        bars2 = ax2.barh(range(len(significant_vars_sorted)), effect_sizes, color=colors2, alpha=0.7)
        ax2.set_yticks(range(len(significant_vars_sorted)))
        ax2.set_yticklabels(significant_vars_sorted['变量名'], fontsize=10)
        ax2.set_xlabel('效应大小 (|相关系数/统计量|)')
        ax2.set_title('效应大小分析', fontsize=14)
        ax2.grid(True, alpha=0.3)
        
        #添加效应大小标签
        for i, (bar, effect) in enumerate(zip(bars2, significant_vars_sorted['相关系数/统计量'])):
            ax2.text(abs(effect) + 0.01, i, f'{effect:.3f}', 
                    va='center', fontsize=8)
        plt.tight_layout()
        plt.savefig('统计检验结果可视化.png', dpi=300, bbox_inches='tight')
        plt.show()
        print(f"共发现 {len(significant_vars)} 个显著变量:")
        for _, row in significant_vars_sorted.iterrows():
            print(f"  • {row['变量名']}: {row['检验方法']}, p={row['p值']:.6f}")
        
        return significant_vars_sorted
    except Exception as e:
        print(f"读取统计结果文件时出错: {e}")
        return pd.DataFrame()

def comprehensive_visualization_analysis(df, correlation_results_file):
    print("Y染色体浓度全面可视化分析报告")
    results = {}
    
    # 输出结果一，分布分析
    results['distribution'] = plot_distribution_analysis(df)
    
    #输出结果二，相关性热图
    results['correlation'] = plot_correlation_heatmap(df)
    
    #输出结果三，分组对比
    results['group_comparison'] = plot_group_comparisons(df)
    
    #输出结果四，散点图关系
    results['scatter_relationships'] = plot_scatter_relationships(df)
    
    #输出结果五，统计检验结果
    results['statistical_results'] = plot_statistical_results(correlation_results_file)
    
    #总结，并生成综合报告
    print("可视化分析综合报告")
    print("\n数据概览:")
    print(f"  • 总样本数: {len(df)}")
    print(f"  • Y染色体浓度有效数据: {len(df['Y染色体浓度'].dropna())}")
    print("\n分布特征:")
    dist_stats = results['distribution']['stats']
    print(f"  • 均值: {dist_stats['mean']:.6f} ± {dist_stats['std']:.6f}")
    print(f"  • 正态性: {dist_stats['normality_test']} p={dist_stats['normality_p']:.6f}")
    print(f"  • 偏度: {dist_stats['skewness']:.4f}, 峰度: {dist_stats['kurtosis']:.4f}")
    print(f"  • 异常值: {dist_stats['outliers_count']} 个")
    print("\n相关性发现:")
    if 'y_correlations' in results['correlation']:
        top_corrs = results['correlation']['y_correlations'].head(3)
        for var, corr in top_corrs.items():
            print(f"  • {var}: r={corr:.4f}")
    print("\n分组对比:")
    if results['group_comparison']:
        significant_groups = [k for k, v in results['group_comparison'].items() if v['p_value'] < 0.05]
        print(f"  • 发现 {len(significant_groups)} 个显著分组差异")
        for group in significant_groups:
            print(f"    - {group}: {results['group_comparison'][group]['significance']}")
    print("\n主要发现:")
    print("  1. Y染色体浓度数据显示非正态分布特征")
    print("  2. 存在多个显著相关的影响因素")
    print("  3. 不同分组间存在显著差异")
    print("  4. 建议使用非参数方法进行进一步分析")
    return results


#代入数据使用
if __name__ == "__main__":
        # 数据读取
        df = pd.read_csv("男胎_预处理数据_完整版.csv")
        correlation_file ="Y染色体浓度相关性检验结果.csv"
        #综合可视化分析
        analysis_results = comprehensive_visualization_analysis(df, correlation_file)
        #输出必要结果
        print("生成以下图表文件：")
        print("  • Y染色体浓度分布分析.png")
        print("  • 相关性分析热图.png")
        print("  • 分组对比分析.png")
        print("  • 散点图关系分析.png")
        print("  • 统计检验结果可视化.png")
