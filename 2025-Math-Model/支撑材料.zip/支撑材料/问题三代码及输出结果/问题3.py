import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from scipy.optimize import minimize_scalar
from scipy.cluster.hierarchy import linkage, fcluster, dendrogram
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import seaborn as sns
from matplotlib.font_manager import FontProperties
import warnings
warnings.filterwarnings('ignore')
#设置中文字体和样式，便于后续作图和和输出展示
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
#[13]AI构建基础算法流程框架，再根据实际问题需要进行细化和完善
#[8]同时添加一些可视化过程使其更易于理解
class Problem3ComprehensiveAnalysis:
    def __init__(self, data_file):
        self.df = pd.read_csv(data_file, encoding='utf-8-sig')
        self.scaler = StandardScaler()
        print("问题三深度分析：多因素综合BMI分组与NIPT时点优化")
        #首先对数据进行预处理
        self._preprocess_data()

    def _preprocess_data(self):
        print("\n1. 数据预处理和特征工程")
        print(f"原始数据shape: {self.df.shape}")
        #遍历数据，移除有缺失关键数据的行
        required_cols = ['孕妇BMI', '孕妇代码', '年龄', '身高', '体重']
        self.df = self.df.dropna(subset=required_cols)
        print(f"清理后数据shape: {self.df.shape}")
        #以孕妇为依据，对数据进行聚合
        agg_dict = {}
        for col in self.df.columns:
            if col == '孕妇代码':
                continue
            elif col in ['Y染色体浓度', '当前检测达标']:
                agg_dict[col] = ['mean', 'std', 'count']
            else:
                agg_dict[col] = 'first'
        self.women_data = self.df.groupby('孕妇代码').agg(agg_dict).reset_index()
        #对于多级列名，进行处理
        if isinstance(self.women_data.columns, pd.MultiIndex):
            new_cols = ['孕妇代码']
            for col in self.women_data.columns[1:]:
                if isinstance(col, tuple):
                    if col[1] == 'first':
                        new_cols.append(col[0])
                    else:
                        new_cols.append(f'{col[0]}_{col[1]}')
                else:
                    new_cols.append(col)
            self.women_data.columns = new_cols
        print(f"聚合后数据shape: {self.women_data.shape}")
        #特征工程
        self._create_derived_features()
        
    def _create_derived_features(self):
        print("  创建衍生特征...")
        if '孕妇BMI' in self.women_data.columns:
            self.women_data['BMI_平方'] = self.women_data['孕妇BMI'] ** 2
        if '年龄' in self.women_data.columns:
            self.women_data['年龄_平方'] = self.women_data['年龄'] ** 2
            self.women_data['高龄产妇'] = (self.women_data['年龄'] >= 35).astype(int)
        if 'Y染色体浓度_mean' in self.women_data.columns and 'Y染色体浓度_std' in self.women_data.columns:
            self.women_data['Y浓度_变异系数'] = (
                self.women_data['Y染色体浓度_std'] / self.women_data['Y染色体浓度_mean']
            ).fillna(0)
        if '当前检测达标_mean' in self.women_data.columns:
            self.women_data['达标率'] = self.women_data['当前检测达标_mean']
        if '孕妇BMI' in self.women_data.columns and '年龄' in self.women_data.columns:
            self.women_data['BMI_年龄_乘积'] = self.women_data['孕妇BMI'] * self.women_data['年龄']
        print(f"  特征工程后shape: {self.women_data.shape}")
        
    def analyze_feature_importance(self):
        print("\n2. 特征重要性分析")
        numeric_cols = self.women_data.select_dtypes(include=[np.number]).columns.tolist()
        feature_cols = [col for col in numeric_cols if col not in ['孕妇代码', '最早达标时间_天数']]
        if '最早达标时间_天数' not in self.women_data.columns or len(feature_cols) < 2:
            print("缺少目标变量或可用特征不足，跳过特征重要性分析")
            self.feature_importance = None
            return None
        X = self.women_data[feature_cols].fillna(self.women_data[feature_cols].median())
        y = self.women_data['最早达标时间_天数'].fillna(self.women_data['最早达标时间_天数'].median())
        #增强数据的可解释性：并且显示数据准备过程
        print(f"分析特征数: {len(feature_cols)}")
        print(f"样本数: {len(X)}")
        print(f"缺失值填充策略: 中位数填充")
        rf = RandomForestRegressor(n_estimators=100, random_state=42)
        rf.fit(X, y)
        self.feature_importance = pd.DataFrame({
            '特征': feature_cols,
            '重要性': rf.feature_importances_
        }).sort_values('重要性', ascending=False)
        print("对'最早达标时间'影响最大的特征排序:")
        print(self.feature_importance.head(10).round(4))
        #绘制特征重要性图，可视化展示结果
        self._visualize_feature_importance()
        #增强代码的可解释性，用于解释关键特征
        self._explain_key_features()
        return self.feature_importance
    
    def _visualize_feature_importance(self):
        if self.feature_importance is None:
            return
        print("  生成特征重要性可视化图表...")
        #提取前10个最重要的特征
        top_features = self.feature_importance.head(10)
        #创建一个新的图表，用于后续绘图
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
        #1.绘制横向条形图
        colors = plt.cm.viridis(np.linspace(0, 1, len(top_features)))
        bars = ax1.barh(range(len(top_features)), top_features['重要性'], color=colors)
        ax1.set_yticks(range(len(top_features)))
        ax1.set_yticklabels(top_features['特征'], fontsize=10)
        ax1.set_xlabel('特征重要性')
        ax1.set_title('前10个最重要特征 (随机森林)', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        #在已绘制的条形图上，标注数据的数值
        for i, (bar, importance) in enumerate(zip(bars, top_features['重要性'])):
            width = bar.get_width()
            ax1.text(width + 0.001, bar.get_y() + bar.get_height()/2, 
                    f'{importance:.3f}', ha='left', va='center', fontsize=9)
        #2.绘制累积重要性图
        cumsum_importance = top_features['重要性'].cumsum()
        ax2.plot(range(1, len(top_features)+1), cumsum_importance, 'o-', linewidth=2, markersize=6)
        ax2.fill_between(range(1, len(top_features)+1), cumsum_importance, alpha=0.3)
        ax2.set_xlabel('特征数量')
        ax2.set_ylabel('累积重要性')
        ax2.set_title('特征重要性累积分布', fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        ax2.set_xticks(range(1, len(top_features)+1))
        #在已绘制的累积重要性图上，添加80%重要性线
        ax2.axhline(y=0.8, color='red', linestyle='--', alpha=0.7, label='80%重要性线')
        ax2.legend()
        plt.tight_layout()
        #将已绘制的图片保存在路径中
        filename = '特征重要性分析可视化.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  特征重要性图表已保存为: {filename}")
        plt.show()
    
    def _explain_key_features(self):
        if self.feature_importance is None:
            return
        print("  关键特征解释:")
        top_3_features = self.feature_importance.head(3)
        feature_explanations = {
            '孕妇BMI': 'BMI是预测检测时点的核心因素，BMI高的孕妇可能需要更长时间达标',
            'BMI_平方': 'BMI的平方项可以捕捉非线性关系，反映BMI极值对检测时点的影响',
            '年龄': '孕妇年龄影响生理状态，高龄产妇可能影响检测结果',
            '年龄_平方': '年龄的平方项反映年龄极值的非线性影响',
            '高龄产妇': '35岁以上高龄产妇标识，直接影响检测策略',
            'Y浓度_变异系数': 'Y染色体浓度变异程度，反映检测稳定性',
            'BMI_年龄_乘积': 'BMI和年龄的交互作用，复合影响因子',
            '达标率': '历史达标情况，预测未来检测成功概率',
            '身高': '孕妇身高影响BMI计算和生理特征',
            '体重': '孕妇体重直接影响BMI和检测时点'
        }
        for _, row in top_3_features.iterrows():
            feature_name = row['特征']
            importance = row['重要性']
            explanation = feature_explanations.get(feature_name, '该特征对检测时点有重要影响')
            print(f"    {feature_name} (重要性: {importance:.3f}): {explanation}")
        #提取前3个特征，并计算其累积重要性占比
        total_importance = self.feature_importance['重要性'].sum()
        top3_importance = top_3_features['重要性'].sum()
        coverage = top3_importance / total_importance
        print(f"    前3个特征累计解释了 {coverage:.1%} 的预测能力")

    def multi_factor_clustering(self):
        print("\n3. 多因素聚类分组")
        
        core_features = ['孕妇BMI', '年龄', '身高', '体重']
        clustering_features = set(core_features)
        if hasattr(self, 'feature_importance') and self.feature_importance is not None:
            additional_features = self.feature_importance.head(3)['特征'].tolist()
            print(f"根据数据驱动分析，添加补充特征: {additional_features}")
            for feature in additional_features:
                clustering_features.add(feature)
        final_clustering_features = [f for f in list(clustering_features) if f in self.women_data.columns]
        print(f"最终用于聚类的综合特征: {final_clustering_features}")
        X_cluster = self.women_data[final_clustering_features].fillna(self.women_data[final_clustering_features].median())
        X_scaled = self.scaler.fit_transform(X_cluster)
        #为了增强代码的可解释性，将在此处显示数据预处理信息
        print(f"聚类数据维度: {X_scaled.shape}")
        print(f"数据标准化: 使用StandardScaler进行Z-score标准化")
        clustering_results = {}
        print("\n  K-means聚类:")
        clustering_results['KMeans'] = self._kmeans_clustering(X_scaled)
        print("\n  层次聚类:")
        clustering_results['Hierarchical'] = self._hierarchical_clustering(X_scaled)
        print("\n  高斯混合模型(GMM):")
        clustering_results['GMM'] = self._gmm_clustering(X_scaled)
        best_method = self._select_best_clustering(clustering_results)
        self.best_clustering = clustering_results[best_method]
        self.women_data['cluster'] = self.best_clustering['labels']
        print(f"\n最佳聚类方法: {best_method}")
        #将聚类过程可视化
        self._visualize_clustering_process(X_scaled, final_clustering_features, clustering_results, best_method)
        #添加新的聚类步骤，生成并修正BMI区间
        self.fixed_bmi_groups = self._generate_and_fix_bmi_groups()
        print("\n修正后的无重叠BMI分组区间:")
        for i, grp in enumerate(self.fixed_bmi_groups):
            print(f"  组 {i+1}: [{grp[0]:.2f}, {grp[1]:.2f}]")
        # 将BMI分组结果可视化
        self._visualize_bmi_grouping()
        return clustering_results
    
    def _visualize_clustering_process(self, X_scaled, feature_names, clustering_results, best_method):
        print("  生成聚类过程可视化图表...")
        fig = plt.figure(figsize=(20, 12))
        #1.所有聚类方法进行对比
        ax1 = plt.subplot(2, 4, 1)
        methods = list(clustering_results.keys())
        scores = [clustering_results[method]['score'] for method in methods]
        n_clusters = [clustering_results[method]['n_clusters'] for method in methods]
        colors = ['red', 'blue', 'green']
        bars = ax1.bar(methods, scores, color=colors)
        ax1.set_ylabel('轮廓系数')
        ax1.set_title('聚类方法对比', fontweight='bold')
        ax1.grid(True, alpha=0.3)
        #综合所有聚类方法后，得出最佳方法后，标注出来
        best_idx = methods.index(best_method)
        bars[best_idx].set_edgecolor('gold')
        bars[best_idx].set_linewidth(3)
        #在绘制的图片中，标注聚类数和得分
        for i, (bar, score, n_clus) in enumerate(zip(bars, scores, n_clusters)):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                    f'{n_clus}组\n{score:.3f}',
                    ha='center', va='bottom', fontsize=9, fontweight='bold')
        #2.最佳聚类方法的聚类结果 (前两个主要特征的散点图)
        ax2 = plt.subplot(2, 4, 2)
        if len(feature_names) >= 2:
            # 使用前面两个重要特征进行可视化
            feat1, feat2 = feature_names[0], feature_names[1]
            feat1_idx = feature_names.index(feat1)
            feat2_idx = feature_names.index(feat2)
            best_labels = self.best_clustering['labels']
            scatter = ax2.scatter(X_scaled[:, feat1_idx], X_scaled[:, feat2_idx], 
                                c=best_labels, cmap='viridis', alpha=0.6, s=30)
            ax2.set_xlabel(f'{feat1} (标准化)')
            ax2.set_ylabel(f'{feat2} (标准化)')
            ax2.set_title(f'{best_method} 聚类结果', fontweight='bold')
            plt.colorbar(scatter, ax=ax2)
        #3.层次聚类树状图
        ax3 = plt.subplot(2, 4, 3)
        if 'Hierarchical' in clustering_results:
            #重新计算层次聚类用于绘制树状图
            linkage_matrix = linkage(X_scaled, method='ward')
            dendrogram(linkage_matrix, ax=ax3, truncate_mode='level', p=5)
            ax3.set_title('层次聚类树状图', fontweight='bold')
            ax3.set_xlabel('样本索引')
            ax3.set_ylabel('距离')
        else:
            ax3.text(0.5, 0.5, '仅在层次聚类时显示', ha='center', va='center', transform=ax3.transAxes)
            ax3.set_title('层次聚类树状图')
        #4.绘制聚类数量选择过程图
        ax4 = plt.subplot(2, 4, 4)
        k_range = range(2, 7)
        inertias = []
        silhouettes = []
        for k in k_range:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(X_scaled)
            inertias.append(kmeans.inertia_)
            if len(set(labels)) > 1:
                silhouettes.append(silhouette_score(X_scaled, labels))
            else:
                silhouettes.append(0)
        ax4_twin = ax4.twinx()
        line1 = ax4.plot(k_range, inertias, 'b-o', label='惯性 (左轴)')
        line2 = ax4_twin.plot(k_range, silhouettes, 'r-s', label='轮廓系数 (右轴)')
        ax4.set_xlabel('聚类数 K')
        ax4.set_ylabel('惯性', color='b')
        ax4_twin.set_ylabel('轮廓系数', color='r')
        ax4.set_title('聚类数量选择 (肘部法则)', fontweight='bold')
        ax4.grid(True, alpha=0.3)
        #将生成的图例合并
        lines = line1 + line2
        labels = [l.get_label() for l in lines]
        ax4.legend(lines, labels, loc='center right')
        #5.绘制各组BMI分布对比图
        ax5 = plt.subplot(2, 4, 5)
        best_labels = self.best_clustering['labels']
        bmi_data = self.women_data['孕妇BMI']
        unique_labels = sorted(list(set(best_labels)))
        colors = plt.cm.viridis(np.linspace(0, 1, len(unique_labels)))
        for i, label in enumerate(unique_labels):
            group_bmi = bmi_data[best_labels == label]
            ax5.hist(group_bmi, alpha=0.6, label=f'组{label+1}', color=colors[i], bins=15)
        ax5.set_xlabel('孕妇BMI')
        ax5.set_ylabel('频次')
        ax5.set_title('各组BMI分布', fontweight='bold')
        ax5.legend()
        ax5.grid(True, alpha=0.3)
        #6.各组统计信息表格
        ax6 = plt.subplot(2, 4, 6)
        ax6.axis('tight')
        ax6.axis('off')
        #计算各组的统计信息
        group_stats = []
        for label in unique_labels:
            mask = best_labels == label
            group_data = self.women_data[mask]
            stats = {
                '组别': f'组{label+1}',
                '样本数': len(group_data),
                'BMI均值': group_data['孕妇BMI'].mean(),
                'BMI标准差': group_data['孕妇BMI'].std(),
                '年龄均值': group_data['年龄'].mean() if '年龄' in group_data.columns else 0
            }
            group_stats.append(stats)
        stats_df = pd.DataFrame(group_stats).round(2)
        table = ax6.table(cellText=stats_df.values, colLabels=stats_df.columns,
                         cellLoc='center', loc='center', fontsize=9)
        table.auto_set_font_size(False)
        table.set_fontsize(8)
        table.scale(1, 1.5)
        ax6.set_title('各组统计信息', fontweight='bold', pad=20)
        #7.绘制图形来描述特征重要性在聚类中的体现
        ax7 = plt.subplot(2, 4, 7)
        if hasattr(self, 'feature_importance') and self.feature_importance is not None:
            # 显示聚类特征的重要性排序
            clustering_feature_importance = self.feature_importance[
                self.feature_importance['特征'].isin(feature_names)
            ].head(6)
            bars = ax7.barh(range(len(clustering_feature_importance)), 
                           clustering_feature_importance['重要性'])
            ax7.set_yticks(range(len(clustering_feature_importance)))
            ax7.set_yticklabels(clustering_feature_importance['特征'], fontsize=9)
            ax7.set_xlabel('特征重要性')
            ax7.set_title('聚类特征重要性', fontweight='bold')
            ax7.grid(True, alpha=0.3)
        else:
            ax7.text(0.5, 0.5, '需要先进行\n特征重要性分析', ha='center', va='center', transform=ax7.transAxes)
            ax7.set_title('聚类特征重要性')
        #8.绘制图进行轮廓分析
        ax8 = plt.subplot(2, 4, 8)
        from sklearn.metrics import silhouette_samples
        best_labels = self.best_clustering['labels']
        sample_silhouette_values = silhouette_samples(X_scaled, best_labels)
        y_lower = 10
        for i, label in enumerate(unique_labels):
            cluster_silhouette_values = sample_silhouette_values[best_labels == label]
            cluster_silhouette_values.sort()
            size_cluster_i = cluster_silhouette_values.shape[0]
            y_upper = y_lower + size_cluster_i
            color = colors[i]
            ax8.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_silhouette_values,
                             facecolor=color, edgecolor=color, alpha=0.7)
            ax8.text(-0.05, y_lower + 0.5 * size_cluster_i, str(label+1))
            y_lower = y_upper + 10
        ax8.set_xlabel('轮廓系数值')
        ax8.set_ylabel('聚类标签')
        ax8.set_title('各组轮廓分析', fontweight='bold')
        #对绘制的图形添加平均轮廓系数线
        silhouette_avg = silhouette_score(X_scaled, best_labels)
        ax8.axvline(x=silhouette_avg, color="red", linestyle="--", 
                   label=f'平均值: {silhouette_avg:.3f}')
        ax8.legend()
        plt.tight_layout()
        #保存输出的图片于代码路径中
        filename = '聚类过程综合分析可视化.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  聚类过程分析图表已保存为: {filename}")
        plt.show()

    def _visualize_bmi_grouping(self):
        if not hasattr(self, 'fixed_bmi_groups') or not self.fixed_bmi_groups:
            return
        print("  生成BMI分组可视化图表...")
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
        #1.对BMI分布直方图与分组边界
        ax1.hist(self.women_data['孕妇BMI'], bins=50, alpha=0.7, color='lightblue', 
                edgecolor='black', label='BMI分布')
        #绘制分组边界
        colors = ['red', 'orange', 'green', 'purple', 'brown', 'pink']
        for i, (bmi_min, bmi_max) in enumerate(self.fixed_bmi_groups):
            color = colors[i % len(colors)]
            ax1.axvline(bmi_min, color=color, linestyle='--', linewidth=2, alpha=0.8)
            if i == len(self.fixed_bmi_groups) - 1:  # 最后一个区间显示右边界
                ax1.axvline(bmi_max, color=color, linestyle='--', linewidth=2, alpha=0.8)
            #对绘制的图形，添加组别标签
            mid_point = (bmi_min + bmi_max) / 2
            ax1.text(mid_point, ax1.get_ylim()[1] * 0.8, f'组{i+1}', 
                    ha='center', va='center', fontsize=12, color=color, 
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
        ax1.set_xlabel('孕妇BMI')
        ax1.set_ylabel('频次')
        ax1.set_title('BMI分布与分组边界', fontweight='bold', fontsize=14)
        ax1.grid(True, alpha=0.3)
        ax1.legend()
        #2.获取各组样本数量和BMI范围
        ax2.axis('tight')
        ax2.axis('off')
        #创建新的表格，用于信息分组
        group_info = []
        for i, (bmi_min, bmi_max) in enumerate(self.fixed_bmi_groups):
            #统计该组的所有样本数
            if i == len(self.fixed_bmi_groups) - 1:
                mask = (self.women_data['孕妇BMI'] >= bmi_min) & (self.women_data['孕妇BMI'] <= bmi_max)
            else:
                mask = (self.women_data['孕妇BMI'] >= bmi_min) & (self.women_data['孕妇BMI'] < bmi_max)
            sample_count = mask.sum()
            avg_bmi = self.women_data[mask]['孕妇BMI'].mean() if sample_count > 0 else 0
            group_info.append({
                '组别': f'组{i+1}',
                'BMI范围': f'[{bmi_min:.2f}, {bmi_max:.2f}]',
                '区间宽度': f'{bmi_max - bmi_min:.2f}',
                '样本数': sample_count,
                'BMI均值': f'{avg_bmi:.2f}' if sample_count > 0 else 'N/A'
            })
        info_df = pd.DataFrame(group_info)
        table = ax2.table(cellText=info_df.values, colLabels=info_df.columns,
                         cellLoc='center', loc='center', fontsize=10)
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        table.scale(1.2, 2)
        #对输出的表格进行美化
        for i in range(len(info_df.columns)):
            table[(0, i)].set_facecolor('#4CAF50')
            table[(0, i)].set_text_props(weight='bold', color='white')
        for i in range(1, len(info_df) + 1):
            for j in range(len(info_df.columns)):
                table[(i, j)].set_facecolor('#f0f0f0')
        ax2.set_title('BMI分组详细信息', fontweight='bold', fontsize=14, pad=20)
        plt.tight_layout()
        #将输出的图片保存在代码困境路径中
        filename = 'BMI分组结果可视化.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  BMI分组结果图表已保存为: {filename}")
        plt.show()

    def _kmeans_clustering(self, X_scaled):
        best_score = -1; best_k = 0; best_labels = None
        for k in range(2, 7):
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(X_scaled)
            if len(set(labels)) > 1:
                silhouette = silhouette_score(X_scaled, labels)
                if silhouette > best_score:
                    best_score, best_k, best_labels = silhouette, k, labels
        print(f"    最佳K: {best_k}, 轮廓系数: {best_score:.3f}")
        return {'method': 'KMeans', 'n_clusters': best_k, 'labels': best_labels, 'score': best_score}

    def _hierarchical_clustering(self, X_scaled):
        linkage_matrix = linkage(X_scaled, method='ward')
        best_score = -1; best_n = 0; best_labels = None
        for n in range(2, 7):
            labels = fcluster(linkage_matrix, n, criterion='maxclust') - 1
            if len(set(labels)) > 1:
                silhouette = silhouette_score(X_scaled, labels)
                if silhouette > best_score:
                    best_score, best_n, best_labels = silhouette, n, labels
        print(f"    最佳聚类数: {best_n}, 轮廓系数: {best_score:.3f}")
        return {'method': 'Hierarchical', 'n_clusters': best_n, 'labels': best_labels, 'score': best_score}

    def _gmm_clustering(self, X_scaled):
        best_bic = np.inf; best_n = 0; best_labels = None
        for n in range(2, 7):
            gmm = GaussianMixture(n_components=n, random_state=42)
            labels = gmm.fit_predict(X_scaled)
            bic = gmm.bic(X_scaled)
            if bic < best_bic:
                best_bic, best_n, best_labels = bic, n, labels
        silhouette = silhouette_score(X_scaled, best_labels)
        print(f"    最佳聚类数: {best_n}, BIC: {best_bic:.1f}, 轮廓系数: {silhouette:.3f}")
        return {'method': 'GMM', 'n_clusters': best_n, 'labels': best_labels, 'score': silhouette}

    def _select_best_clustering(self, clustering_results):
        comparison = [{'方法': name, '聚类数': res['n_clusters'], '评估得分(轮廓系数)': res['score']}
                      for name, res in clustering_results.items()]
        #将对比结果保存为类属性，以便后续输出
        self.clustering_comparison_df = pd.DataFrame(comparison).sort_values('评估得分(轮廓系数)', ascending=False)
        print(f"\n  聚类方法对比:")
        print(self.clustering_comparison_df.round(3))
        return self.clustering_comparison_df.iloc[0]['方法']
        
    #新增核心函数，用于生成并修正重叠区间
    def _generate_and_fix_bmi_groups(self):
        if not hasattr(self, 'best_clustering') or 'labels' not in self.best_clustering:
            return []
        labels = self.best_clustering['labels']
        unique_labels = sorted(list(set(labels)))
        #1.生成初始的、可能重叠的BMI分组
        initial_groups = []
        for label in unique_labels:
            group_bmi = self.women_data[self.women_data['cluster'] == label]['孕妇BMI']
            if not group_bmi.empty:
                initial_groups.append([group_bmi.min(), group_bmi.max()])
        if not initial_groups:
            return []
        #2.将生成的区间按下界进行排序
        sorted_groups = sorted(initial_groups, key=lambda x: x[0])
        #3.迭代检查并修正重叠
        fixed_groups = [sorted_groups[0]]
        for i in range(1, len(sorted_groups)):
            prev_lower, prev_upper = fixed_groups[-1]
            curr_lower, curr_upper = sorted_groups[i]
            # 如果检测到重叠
            if curr_lower < prev_upper:
                #计算重叠部分的中点作为新的分界线
                mid_point = (prev_upper + curr_lower) / 2
                fixed_groups[-1][1] = mid_point  #修正前一个区间的上界
                sorted_groups[i][0] = mid_point  #修正当前区间的下界
                fixed_groups.append(sorted_groups[i])
            #如果没有重叠
            else:
                fixed_groups.append(sorted_groups[i])
        return fixed_groups
    #结束新增加的函数

    def optimize_detection_timepoints(self):
        print("\n4. 各分组检测时点优化")
        #使用修正后的无重叠区间来进行优化
        print(f"优化策略说明:")
        print(f"  - 目标函数: 最小化 [时间风险 + 失败风险]")
        print(f"  - 时间风险: 12周内(风险1.0) → 27周内(风险2.0) → 27周后(风险4.0)")
        print(f"  - 失败风险: (1-成功率) × 3.0")
        print(f"  - 搜索范围: 10-30周")
        optimal_timepoints = []
        optimization_details = []  #存储优化过程的详细信息
        for i, (bmi_min, bmi_max) in enumerate(self.fixed_bmi_groups):
            #根据修正后的清晰区间筛选数据
            #对于最后一个区间，使用闭合区间
            if i == len(self.fixed_bmi_groups) - 1:
                cluster_data = self.women_data[
                    (self.women_data['孕妇BMI'] >= bmi_min) & (self.women_data['孕妇BMI'] <= bmi_max)
                ]
            else: #而其他区间，使用左闭右开区间
                cluster_data = self.women_data[
                    (self.women_data['孕妇BMI'] >= bmi_min) & (self.women_data['孕妇BMI'] < bmi_max)
                ]
            if cluster_data.empty:
                print(f"\n  警告：组别 {i + 1} (BMI [{bmi_min:.2f}, {bmi_max:.2f}]) 内没有样本数据，已跳过。")
                continue
            print(f"\n  分析组别 {i + 1}: BMI [{bmi_min:.2f}, {bmi_max:.2f}] (样本数 n={len(cluster_data)})")
            #增强代码的可解释性，显示该组的基本统计信息
            detection_times = cluster_data['最早达标时间_天数']
            print(f"    该组达标时间分布: 均值{detection_times.mean():.1f}天, 中位数{detection_times.median():.1f}天")
            print(f"    达标时间范围: {detection_times.min():.0f}-{detection_times.max():.0f}天")
            #存储目标函数计算过程并用于可视化
            time_points = np.linspace(10*7, 30*7, 100)
            objective_values = []
            success_rates = []
            time_risks = []
            failure_risks = []
    
            def objective(t):
                success_rate = (cluster_data['最早达标时间_天数'] <= t).mean()
                if t <= 12 * 7: time_risk = 1.0
                elif t <= 27 * 7: time_risk = 2.0
                else: time_risk = 4.0
                failure_risk = (1 - success_rate) * 3.0
                return time_risk + failure_risk
            #计算目标函数曲线并用于可视化
            for t in time_points:
                success_rate = (cluster_data['最早达标时间_天数'] <= t).mean()
                if t <= 12 * 7: time_risk = 1.0
                elif t <= 27 * 7: time_risk = 2.0
                else: time_risk = 4.0
                failure_risk = (1 - success_rate) * 3.0
                objective_values.append(time_risk + failure_risk)
                success_rates.append(success_rate)
                time_risks.append(time_risk)
                failure_risks.append(failure_risk)
            result = minimize_scalar(objective, bounds=(10*7, 30*7), method='bounded')
            optimal_time = result.x
            performance = self._evaluate_timepoint(cluster_data, optimal_time)
            #增强代码的可解释性，并解释优化结果
            optimal_success_rate = (cluster_data['最早达标时间_天数'] <= optimal_time).mean()
            print(f"    优化结果: 最佳时点 {optimal_time/7:.1f}周 ({optimal_time:.0f}天)")
            print(f"    在最佳时点的预期成功率: {optimal_success_rate:.1%}")
            print(f"    风险评级: {performance['风险等级']}")
            optimal_timepoints.append({
                '组别': f"组 {i + 1}",
                'BMI区间': f"[{bmi_min:.2f}, {bmi_max:.2f}]",
                '样本数': len(cluster_data),
                '最佳时点_天数': optimal_time,
                '最佳时点_周数': optimal_time / 7,
                **performance
            })
            #存储优化详细信息，用于后续可视化
            optimization_details.append({
                'group_id': i + 1,
                'bmi_range': f"[{bmi_min:.2f}, {bmi_max:.2f}]",
                'time_points': time_points,
                'objective_values': objective_values,
                'success_rates': success_rates,
                'time_risks': time_risks,
                'failure_risks': failure_risks,
                'optimal_time': optimal_time,
                'detection_times': detection_times.values
            })
        self.optimal_timepoints = pd.DataFrame(optimal_timepoints)
        self.optimization_details = optimization_details  # 保存优化详情
        print("\n检测时点优化结果汇总:")
        print(self.optimal_timepoints[['组别', 'BMI区间', '样本数', '最佳时点_周数', '预期成功率', '风险等级']].round(2))
        #对时点优化过程绘制，可视化
        self._visualize_timepoint_optimization()
        return self.optimal_timepoints
    
    def _visualize_timepoint_optimization(self):
        if not hasattr(self, 'optimization_details') or not self.optimization_details:
            return
        print("  生成时点优化可视化图表...")
        n_groups = len(self.optimization_details)
        fig = plt.figure(figsize=(20, 4 * n_groups))
        for i, detail in enumerate(self.optimization_details):
            #对每组创建4个子图
            base_idx = i * 4
            #1.目标函数曲线
            ax1 = plt.subplot(n_groups, 4, base_idx + 1)
            time_weeks = np.array(detail['time_points']) / 7
            ax1.plot(time_weeks, detail['objective_values'], 'b-', linewidth=2, label='目标函数')
            ax1.axvline(detail['optimal_time']/7, color='red', linestyle='--', linewidth=2, 
                       label=f'最优时点: {detail["optimal_time"]/7:.1f}周')
            ax1.set_xlabel('检测时点 (周)')
            ax1.set_ylabel('目标函数值')
            ax1.set_title(f'组{detail["group_id"]} - 目标函数优化曲线', fontweight='bold')
            ax1.grid(True, alpha=0.3)
            ax1.legend()
            #2.成功率曲线
            ax2 = plt.subplot(n_groups, 4, base_idx + 2)
            ax2.plot(time_weeks, detail['success_rates'], 'g-', linewidth=2, label='成功率')
            ax2.axvline(detail['optimal_time']/7, color='red', linestyle='--', linewidth=2, alpha=0.7)
            ax2.set_xlabel('检测时点 (周)')
            ax2.set_ylabel('预期成功率')
            ax2.set_title(f'组{detail["group_id"]} - 成功率曲线', fontweight='bold')
            ax2.grid(True, alpha=0.3)
            ax2.set_ylim([0, 1])
            ax2.legend()
            #3.风险分解
            ax3 = plt.subplot(n_groups, 4, base_idx + 3)
            ax3.plot(time_weeks, detail['time_risks'], 'orange', linewidth=2, label='时间风险')
            ax3.plot(time_weeks, detail['failure_risks'], 'purple', linewidth=2, label='失败风险')
            ax3.axvline(detail['optimal_time']/7, color='red', linestyle='--', linewidth=2, alpha=0.7)
            ax3.set_xlabel('检测时点 (周)')
            ax3.set_ylabel('风险值')
            ax3.set_title(f'组{detail["group_id"]} - 风险分解', fontweight='bold')
            ax3.grid(True, alpha=0.3)
            ax3.legend()
            #4.达标时间分布直方图
            ax4 = plt.subplot(n_groups, 4, base_idx + 4)
            detection_weeks = detail['detection_times'] / 7
            ax4.hist(detection_weeks, bins=15, alpha=0.7, color='lightblue', edgecolor='black')
            ax4.axvline(detail['optimal_time']/7, color='red', linestyle='--', linewidth=3, 
                       label=f'最优时点: {detail["optimal_time"]/7:.1f}周')
            ax4.set_xlabel('达标时间 (周)')
            ax4.set_ylabel('样本数')
            ax4.set_title(f'组{detail["group_id"]} - 达标时间分布', fontweight='bold')
            ax4.grid(True, alpha=0.3)
            ax4.legend()
        plt.tight_layout()
        #输出生成的图片，保存在代码路径中
        filename = '时点优化过程可视化.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  时点优化过程图表已保存为: {filename}")
        plt.show()
        #创建新的图片，用于优化结果综合对比
        self._create_optimization_summary_plot()
    def _create_optimization_summary_plot(self):
        if not hasattr(self, 'optimal_timepoints'):
            return
        print("  生成优化结果综合对比图表...")
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        #1.各组最佳时点对比
        groups = self.optimal_timepoints['组别']
        timepoints_weeks = self.optimal_timepoints['最佳时点_周数']
        success_rates = self.optimal_timepoints['预期成功率']
        bars1 = ax1.bar(groups, timepoints_weeks, alpha=0.7, color='steelblue')
        #在生成的图片里标注成功率
        for i, (bar, rate) in enumerate(zip(bars1, success_rates)):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 0.3, 
                    f'{rate:.1%}', ha='center', va='bottom', fontweight='bold')
        ax1.set_xlabel('BMI组别')
        ax1.set_ylabel('最佳检测时点 (周)')
        ax1.set_title('各组最佳检测时点对比', fontweight='bold', fontsize=14)
        ax1.grid(True, alpha=0.3)
        #2.成功率vs时点散点图
        colors = ['red' if level == '高风险' else 'orange' if level == '中风险' else 'green' 
                 for level in self.optimal_timepoints['风险等级']]
        scatter = ax2.scatter(timepoints_weeks, success_rates, s=100, c=colors, alpha=0.7, edgecolors='black')
        for i, group in enumerate(groups):
            ax2.annotate(group, (timepoints_weeks.iloc[i], success_rates.iloc[i]), 
                        xytext=(5, 5), textcoords='offset points', fontsize=10)
        ax2.set_xlabel('最佳检测时点 (周)')
        ax2.set_ylabel('预期成功率')
        ax2.set_title('时点-成功率关系图', fontweight='bold', fontsize=14)
        ax2.grid(True, alpha=0.3)
        #添加一些图例
        from matplotlib.patches import Patch
        legend_elements = [Patch(facecolor='green', label='低风险'),
                          Patch(facecolor='orange', label='中风险'),
                          Patch(facecolor='red', label='高风险')]
        ax2.legend(handles=legend_elements)
        #3.绘制风险等级分布图
        risk_counts = self.optimal_timepoints['风险等级'].value_counts()
        colors_pie = ['green' if risk == '低风险' else 'orange' if risk == '中风险' else 'red' 
                     for risk in risk_counts.index]
        wedges, texts, autotexts = ax3.pie(risk_counts.values, labels=risk_counts.index, 
                                          autopct='%1.1f%%', colors=colors_pie, startangle=90)
        ax3.set_title('各组风险等级分布', fontweight='bold', fontsize=14)
        #4.绘制详细信息表格
        ax4.axis('tight')
        ax4.axis('off')
        table_data = self.optimal_timepoints[['组别', 'BMI区间', '样本数', '最佳时点_周数', '预期成功率', '风险等级']].copy()
        table_data['预期成功率'] = table_data['预期成功率'].apply(lambda x: f'{x:.1%}')
        table_data['最佳时点_周数'] = table_data['最佳时点_周数'].apply(lambda x: f'{x:.1f}')
        
        table = ax4.table(cellText=table_data.values, colLabels=table_data.columns,
                         cellLoc='center', loc='center', fontsize=10)
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1.2, 1.8)
        #对输出的表格进行美化
        for i in range(len(table_data.columns)):
            table[(0, i)].set_facecolor('#4CAF50')
            table[(0, i)].set_text_props(weight='bold', color='white')
        for i in range(1, len(table_data) + 1):
            for j in range(len(table_data.columns)):
                table[(i, j)].set_facecolor('#f9f9f9')
        ax4.set_title('检测时点优化结果汇总', fontweight='bold', fontsize=14, pad=20)
        plt.tight_layout()
        #输出生成的图片，保存在代码路径中
        filename = '优化结果综合对比.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  优化结果综合对比图表已保存为: {filename}")
        plt.show()
    
    def _evaluate_timepoint(self, group_data, test_time):
        success_rate = (group_data['最早达标时间_天数'] <= test_time).mean()
        risk_level = '低风险' if test_time <= 12*7 else '中风险' if test_time <= 27*7 else '高风险'
        return {'预期成功率': success_rate, '风险等级': risk_level}

    def sensitivity_analysis(self):
        print("\n5. 检测误差敏感性分析")
        #增强代码的可解释性，以解释敏感性分析的意义
        print("敏感性分析说明:")
        print("  - 目的: 评估最佳时点在实际操作中的稳定性")
        print("  - 方法: 测试±7天误差范围内成功率的变化")
        print("  - 意义: 误差范围越小，时点选择越稳定可靠")
        error_scenarios = [-7, -3, 0, 3, 7]
        sensitivity_results = []
        for _, group_info in self.optimal_timepoints.iterrows():
            bmi_range_str = group_info['BMI区间']
            bmi_min, bmi_max = [float(x) for x in bmi_range_str.strip('[]').split(', ')]
            #同样，需要注意最后一个区间的边界
            if group_info['组别'] == f"组 {len(self.fixed_bmi_groups)}":
                 cluster_data = self.women_data[
                    (self.women_data['孕妇BMI'] >= bmi_min) & (self.women_data['孕妇BMI'] <= bmi_max)
                ]
            else:
                cluster_data = self.women_data[
                    (self.women_data['孕妇BMI'] >= bmi_min) & (self.women_data['孕妇BMI'] < bmi_max)
                ]
            if cluster_data.empty: continue
            optimal_time = group_info['最佳时点_天数']
            group_name = group_info['组别']
            print(f"\n  {group_name} 敏感性测试:")
            group_sensitivity = []
            for error in error_scenarios:
                adjusted_time = optimal_time + error
                performance = self._evaluate_timepoint(cluster_data, adjusted_time)
                success_rate = performance['预期成功率']
                sensitivity_results.append({
                    '组别': group_name, '误差天数': error,
                    '调整后时点_周数': adjusted_time / 7, '预期成功率': success_rate
                })
                group_sensitivity.append(success_rate)
                #增强代码可解释性，显示每个误差场景的详细信息
                print(f"    误差{error:+2d}天 -> 时点{adjusted_time/7:.1f}周 -> 成功率{success_rate:.1%}")
            
            #计算，并且，解释该组的敏感性
            max_rate, min_rate = max(group_sensitivity), min(group_sensitivity)
            deviation = max_rate - min_rate
            print(f"    敏感性评估: 成功率波动范围 {deviation:.2%}")
        self.sensitivity_df = pd.DataFrame(sensitivity_results)
        print("\n不同误差下的预期成功率变化:")
        #将透视表结果保存为类属性
        self.sensitivity_pivot_df = self.sensitivity_df.pivot_table(
            index='组别', columns='误差天数', values='预期成功率'
        )
        print(self.sensitivity_pivot_df.round(3))
        print("\n各组敏感性等级评估:")
        for group_name in sorted(self.sensitivity_pivot_df.index):
            success_rates = self.sensitivity_pivot_df.loc[group_name]
            deviation = success_rates.max() - success_rates.min()
            level = "低敏感" if deviation < 0.1 else "中敏感" if deviation < 0.2 else "高敏感"
            print(f"  {group_name}: 成功率波动范围 {deviation:.2%} - {level}")
            #增强代码的可解释性，解释敏感性等级的含义
            if level == "低敏感":
                interpretation = "时点选择非常稳定，实际操作中的小幅偏差影响很小"
            elif level == "中敏感":
                interpretation = "时点选择较为稳定，但需要注意控制操作误差"
            else:
                interpretation = "时点选择敏感度较高，需要精确控制检测时机"
            print(f"           解释: {interpretation}")
        #输出敏感性分析结果，用于可视化
        self._visualize_sensitivity_analysis()
        return self.sensitivity_df
    
    def _visualize_sensitivity_analysis(self):
        if not hasattr(self, 'sensitivity_pivot_df'):
            return
        print("  生成敏感性分析可视化图表...")
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        #1.绘制敏感性热力图
        sns.heatmap(self.sensitivity_pivot_df, annot=True, fmt='.3f', cmap='RdYlGn', 
                   center=self.sensitivity_pivot_df.mean().mean(), ax=ax1)
        ax1.set_title('各组敏感性分析热力图', fontweight='bold', fontsize=14)
        ax1.set_xlabel('误差天数')
        ax1.set_ylabel('BMI组别')
        #2.绘制各组敏感性曲线图
        colors = plt.cm.viridis(np.linspace(0, 1, len(self.sensitivity_pivot_df.index)))
        for i, group in enumerate(self.sensitivity_pivot_df.index):
            ax2.plot(self.sensitivity_pivot_df.columns, self.sensitivity_pivot_df.loc[group], 
                    'o-', linewidth=2, markersize=6, color=colors[i], label=group)
        ax2.set_xlabel('误差天数')
        ax2.set_ylabel('预期成功率')
        ax2.set_title('各组敏感性曲线', fontweight='bold', fontsize=14)
        ax2.grid(True, alpha=0.3)
        ax2.legend()
        ax2.set_ylim([0, 1])
        #3.绘制敏感性等级分布
        deviations = []
        sensitivity_levels = []
        group_names = []
        for group_name in self.sensitivity_pivot_df.index:
            success_rates = self.sensitivity_pivot_df.loc[group_name]
            deviation = success_rates.max() - success_rates.min()
            level = "低敏感" if deviation < 0.1 else "中敏感" if deviation < 0.2 else "高敏感"
            deviations.append(deviation)
            sensitivity_levels.append(level)
            group_names.append(group_name)
        level_counts = pd.Series(sensitivity_levels).value_counts()
        colors_pie = ['green' if level == '低敏感' else 'orange' if level == '中敏感' else 'red' 
                     for level in level_counts.index]
        wedges, texts, autotexts = ax3.pie(level_counts.values, labels=level_counts.index, 
                                          autopct='%1.1f%%', colors=colors_pie, startangle=90)
        ax3.set_title('敏感性等级分布', fontweight='bold', fontsize=14)
        #4.绘制敏感性偏差条形图
        colors_bar = ['green' if level == '低敏感' else 'orange' if level == '中敏感' else 'red' 
                     for level in sensitivity_levels]
        bars = ax4.bar(group_names, deviations, color=colors_bar, alpha=0.7, edgecolor='black')
        ax4.set_xlabel('BMI组别')
        ax4.set_ylabel('成功率波动范围')
        ax4.set_title('各组敏感性偏差对比', fontweight='bold', fontsize=14)
        ax4.grid(True, alpha=0.3)
        #在绘制的图形上添加阈值线
        ax4.axhline(y=0.1, color='orange', linestyle='--', alpha=0.7, label='中敏感阈值(10%)')
        ax4.axhline(y=0.2, color='red', linestyle='--', alpha=0.7, label='高敏感阈值(20%)')
        ax4.legend()
        #在会知道图形上标注数值
        for bar, deviation, level in zip(bars, deviations, sensitivity_levels):
            height = bar.get_height()
            ax4.text(bar.get_x() + bar.get_width()/2., height + 0.005,
                    f'{deviation:.2%}\n{level}',
                    ha='center', va='bottom', fontsize=9, fontweight='bold')
        plt.tight_layout()
        #输出生成的图片，保存在代码路径中
        filename = '敏感性分析可视化.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  敏感性分析图表已保存为: {filename}")
        plt.show()

    #结果输出功能
    def save_results_to_excel(self, filename="综合分析结果.xlsx"):
        print(f"6. 保存分析结果至Excel文件: {filename}")
        try:
            with pd.ExcelWriter(filename, engine='openpyxl') as writer:
                #1.写入特征重要性
                if hasattr(self, 'feature_importance') and self.feature_importance is not None:
                    self.feature_importance.to_excel(writer, sheet_name='特征重要性排序', index=False)
                    print(f"  - 已保存 '特征重要性排序' sheet。")
                #2.写入聚类方法对比
                if hasattr(self, 'clustering_comparison_df'):
                    self.clustering_comparison_df.to_excel(writer, sheet_name='聚类方法对比', index=False)
                    print(f"  - 已保存 '聚类方法对比' sheet。")
                #3.写入最终BMI分组区间
                if hasattr(self, 'fixed_bmi_groups'):
                    bmi_groups_df = pd.DataFrame(self.fixed_bmi_groups, columns=['BMI下限', 'BMI上限'])
                    bmi_groups_df.index = [f"组 {i+1}" for i in bmi_groups_df.index]
                    bmi_groups_df.to_excel(writer, sheet_name='最终BMI分组')
                    print(f"  - 已保存 '最终BMI分组' sheet。")
                #4.写入各组最佳检测时点
                if hasattr(self, 'optimal_timepoints'):
                    self.optimal_timepoints.to_excel(writer, sheet_name='各组最佳检测时点', index=False)
                    print(f"  - 已保存 '各组最佳检测时点' sheet。")
                #5.写入时点敏感性分析
                if hasattr(self, 'sensitivity_pivot_df'):
                    self.sensitivity_pivot_df.to_excel(writer, sheet_name='时点敏感性分析')
                    print(f"  - 已保存 '时点敏感性分析' sheet。")
                #6.写入带标签的完整数据
                if 'cluster' in self.women_data.columns:
                    self.women_data.to_excel(writer, sheet_name='带标签的聚合数据', index=False)
                    print(f"  - 已保存 '带标签的聚合数据' sheet。")
            print(f"\n所有结果已成功保存到 '{filename}'！")
        except Exception as e:
            print(f"\n保存Excel文件时出错: {e}")
            print("请确保您有写入文件的权限，并且没有其他程序正在打开该文件。")
            
    def run_complete_analysis(self):
        try:
            print(f"\n开始运行问题三综合深度分析...")
            print(f"分析阶段概览:")
            print(f"  数据预处理和特征工程")
            print(f"  特征重要性分析 + 可视化")
            print(f"  多因素聚类分组 + 可视化")
            print(f"  检测时点优化 + 可视化")
            print(f"  敏感性分析 + 可视化")
            print(f"  结果保存与综合汇总")
            #运行并分析流程
            self.analyze_feature_importance()
            self.multi_factor_clustering()
            self.optimize_detection_timepoints()
            self.sensitivity_analysis()
            #生成所有的综合分析汇总
            self._create_comprehensive_summary()
            #在所有分析结束后，调用保存结果的方法
            self.save_results_to_excel() # 使用默认文件名 "综合分析结果.xlsx"
            print("问题三深度分析全部流程成功完成！")
            print(f"  生成的可视化文件:")
            print(f"   - 特征重要性分析可视化.png")
            print(f"   - 聚类过程综合分析可视化.png") 
            print(f"   - BMI分组结果可视化.png")
            print(f"   - 时点优化过程可视化.png")
            print(f"   - 优化结果综合对比.png")
            print(f"   - 敏感性分析可视化.png")
            print(f"   - 综合分析汇总Dashboard.png")
            print(f"  分析报告: 综合分析结果.xlsx")
            return True
        except Exception as e:
            print(f"分析过程中出错: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _create_comprehensive_summary(self):
        print("\n  生成综合分析汇总Dashboard...")
        fig = plt.figure(figsize=(20, 16))
        #创建新的主标题
        fig.suptitle('问题三综合深度分析 - 多因素BMI分组与NIPT时点优化', 
                    fontsize=20, fontweight='bold', y=0.98)
        #1.绘制特征重要性Top5
        ax1 = plt.subplot(3, 4, 1)
        if hasattr(self, 'feature_importance') and self.feature_importance is not None:
            top5_features = self.feature_importance.head(5)
            bars = ax1.barh(range(len(top5_features)), top5_features['重要性'], 
                           color='skyblue', alpha=0.8)
            ax1.set_yticks(range(len(top5_features)))
            ax1.set_yticklabels(top5_features['特征'], fontsize=10)
            ax1.set_xlabel('重要性')
            ax1.set_title('Top5 关键特征', fontweight='bold')
            ax1.grid(True, alpha=0.3)
            #在图上标注数值
            for i, (bar, importance) in enumerate(zip(bars, top5_features['重要性'])):
                width = bar.get_width()
                ax1.text(width + 0.005, bar.get_y() + bar.get_height()/2, 
                        f'{importance:.3f}', ha='left', va='center', fontsize=9)
        #2.绘制聚类方法对比
        ax2 = plt.subplot(3, 4, 2)
        if hasattr(self, 'clustering_comparison_df'):
            methods = self.clustering_comparison_df['方法']
            scores = self.clustering_comparison_df['评估得分(轮廓系数)']
            colors = ['gold' if i == 0 else 'lightblue' for i in range(len(methods))]
            bars = ax2.bar(methods, scores, color=colors, alpha=0.8, edgecolor='black')
            ax2.set_ylabel('轮廓系数')
            ax2.set_title('聚类方法对比', fontweight='bold')
            ax2.grid(True, alpha=0.3)
            ax2.tick_params(axis='x', rotation=45)
            #综合所有分析后，并标注最佳方法
            for i, (bar, score) in enumerate(zip(bars, scores)):
                height = bar.get_height()
                label = f'{score:.3f}\n最佳' if i == 0 else f'{score:.3f}'
                ax2.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                        label, ha='center', va='bottom', fontsize=9, fontweight='bold')
        #3.绘制BMI分组区间展示
        ax3 = plt.subplot(3, 4, 3)
        if hasattr(self, 'fixed_bmi_groups'):
            #绘制BMI分布直方图
            ax3.hist(self.women_data['孕妇BMI'], bins=30, alpha=0.6, color='lightblue', edgecolor='black')
            #标记分组边界
            colors = ['red', 'orange', 'green', 'purple', 'brown']
            for i, (bmi_min, bmi_max) in enumerate(self.fixed_bmi_groups):
                color = colors[i % len(colors)]
                ax3.axvline(bmi_min, color=color, linestyle='--', linewidth=2, alpha=0.8)
                if i == len(self.fixed_bmi_groups) - 1:
                    ax3.axvline(bmi_max, color=color, linestyle='--', linewidth=2, alpha=0.8)
                #添加组别标签
                mid_point = (bmi_min + bmi_max) / 2
                ax3.text(mid_point, ax3.get_ylim()[1] * 0.8, f'组{i+1}', 
                        ha='center', va='center', fontsize=10, color=color, fontweight='bold')
            ax3.set_xlabel('孕妇BMI')
            ax3.set_ylabel('频次')
            ax3.set_title('BMI分组结果', fontweight='bold')
        #4.绘制最佳时点对比图
        ax4 = plt.subplot(3, 4, 4)
        if hasattr(self, 'optimal_timepoints'):
            groups = self.optimal_timepoints['组别']
            timepoints = self.optimal_timepoints['最佳时点_周数']
            success_rates = self.optimal_timepoints['预期成功率']
            bars = ax4.bar(groups, timepoints, color='lightgreen', alpha=0.8, edgecolor='black')
            ax4.set_ylabel('最佳时点 (周)')
            ax4.set_title('各组最佳检测时点', fontweight='bold')
            ax4.grid(True, alpha=0.3)
            #在绘制的图形中标注成功率
            for bar, rate in zip(bars, success_rates):
                height = bar.get_height()
                ax4.text(bar.get_x() + bar.get_width()/2., height + 0.3,
                        f'{rate:.1%}', ha='center', va='bottom', fontsize=9, fontweight='bold')
        #5.绘制敏感性分析热力图
        ax5 = plt.subplot(3, 4, 5)
        if hasattr(self, 'sensitivity_pivot_df'):
            sns.heatmap(self.sensitivity_pivot_df, annot=True, fmt='.2f', 
                       cmap='RdYlGn', center=0.9, ax=ax5, cbar_kws={'shrink': 0.8})
            ax5.set_title('敏感性分析热力图', fontweight='bold')
            ax5.set_xlabel('误差天数')
            ax5.set_ylabel('组别')
        #6.绘制风险等级分布图
        ax6 = plt.subplot(3, 4, 6)
        if hasattr(self, 'optimal_timepoints'):
            risk_counts = self.optimal_timepoints['风险等级'].value_counts()
            colors_pie = ['green' if risk == '低风险' else 'orange' if risk == '中风险' else 'red' 
                         for risk in risk_counts.index]
            wedges, texts, autotexts = ax6.pie(risk_counts.values, labels=risk_counts.index, 
                                              autopct='%1.1f%%', colors=colors_pie, startangle=90)
            ax6.set_title('风险等级分布', fontweight='bold')
        #7.绘制数据概览信息表
        ax7 = plt.subplot(3, 4, (7, 8))
        ax7.axis('tight')
        ax7.axis('off')
        #创建新的数据概览表
        overview_data = []
        if hasattr(self, 'women_data'):
            overview_data.append(['总样本数', f'{len(self.women_data)}'])
            overview_data.append(['BMI范围', f'{self.women_data["孕妇BMI"].min():.1f} - {self.women_data["孕妇BMI"].max():.1f}'])
            overview_data.append(['年龄范围', f'{self.women_data["年龄"].min():.0f} - {self.women_data["年龄"].max():.0f}岁'])
        if hasattr(self, 'fixed_bmi_groups'):
            overview_data.append(['分组数量', f'{len(self.fixed_bmi_groups)}组'])
        if hasattr(self, 'optimal_timepoints'):
            avg_timepoint = self.optimal_timepoints['最佳时点_周数'].mean()
            avg_success = self.optimal_timepoints['预期成功率'].mean()
            overview_data.append(['平均最佳时点', f'{avg_timepoint:.1f}周'])
            overview_data.append(['平均成功率', f'{avg_success:.1%}'])
        if hasattr(self, 'feature_importance'):
            top_feature = self.feature_importance.iloc[0]['特征']
            top_importance = self.feature_importance.iloc[0]['重要性']
            overview_data.append(['最重要特征', f'{top_feature}'])
            overview_data.append(['特征重要性', f'{top_importance:.3f}'])
        overview_df = pd.DataFrame(overview_data, columns=['指标', '数值'])
        table = ax7.table(cellText=overview_df.values, colLabels=overview_df.columns,
                         cellLoc='center', loc='center', fontsize=12)
        table.auto_set_font_size(False)
        table.set_fontsize(11)
        table.scale(1.2, 2)
        #对生成的表格进行美化
        for i in range(len(overview_df.columns)):
            table[(0, i)].set_facecolor('#4CAF50')
            table[(0, i)].set_text_props(weight='bold', color='white')
        for i in range(1, len(overview_df) + 1):
            for j in range(len(overview_df.columns)):
                table[(i, j)].set_facecolor('#f0f8ff')
        ax7.set_title('数据概览', fontweight='bold', fontsize=14, pad=20)
        #8.绘制关键结论与建议图
        ax8 = plt.subplot(3, 4, (9, 10))
        ax8.axis('off')
        conclusions = []
        if hasattr(self, 'optimal_timepoints'):
            best_group = self.optimal_timepoints.loc[self.optimal_timepoints['预期成功率'].idxmax()]
            worst_group = self.optimal_timepoints.loc[self.optimal_timepoints['预期成功率'].idxmin()]
            conclusions.extend([
                "  关键发现:",
                f"• 最佳表现: {best_group['组别']} (成功率{best_group['预期成功率']:.1%})",
                f"• 需要关注: {worst_group['组别']} (成功率{worst_group['预期成功率']:.1%})",
                "",
                "  临床建议:",
                "• 实施个性化检测时点策略",
                "• 重点关注高BMI孕妇群体",
                "• 建立时点偏差控制机制",
                "",
                "  注意事项:",
                "• 考虑实际操作中的时间误差",
                "• 定期评估和调整分组策略",
                "• 监控检测质量指标变化"
            ])
        conclusion_text = '\n'.join(conclusions)
        ax8.text(0.05, 0.95, conclusion_text, transform=ax8.transAxes, fontsize=11,
                verticalalignment='top', horizontalalignment='left',
                bbox=dict(boxstyle="round,pad=0.5", facecolor='lightyellow', alpha=0.8))
        ax8.set_title('分析结论与建议', fontweight='bold', fontsize=14)
        #9.绘制分析流程图示
        ax9 = plt.subplot(3, 4, (11, 12))
        ax9.axis('off')
        #绘制流程图
        steps = [
            "1. 数据预处理\n特征工程",
            "2. 特征重要性\n随机森林分析", 
            "3. 多因素聚类\n3种方法对比",
            "4. BMI分组\n区间修正",
            "5. 时点优化\n目标函数最小化",
            "6. 敏感性分析\n稳定性评估"
        ]
        y_positions = np.linspace(0.9, 0.1, len(steps))
        colors_flow = ['lightblue', 'lightgreen', 'lightyellow', 'lightpink', 'lightcoral', 'lightgray']
        for i, (step, y_pos, color) in enumerate(zip(steps, y_positions, colors_flow)):
            #绘制步骤框
            bbox = dict(boxstyle="round,pad=0.3", facecolor=color, alpha=0.8, edgecolor='black')
            ax9.text(0.5, y_pos, step, transform=ax9.transAxes, fontsize=10,
                    ha='center', va='center', bbox=bbox)
            #绘制箭头
            if i < len(steps) - 1:
                ax9.annotate('', xy=(0.5, y_positions[i+1] + 0.05), xytext=(0.5, y_pos - 0.05),
                           xycoords='axes fraction', textcoords='axes fraction',
                           arrowprops=dict(arrowstyle='->', lw=2, color='darkblue'))
        ax9.set_title('分析流程', fontweight='bold', fontsize=14)
        plt.tight_layout()
        filename = '综合分析汇总Dashboard.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  综合分析汇总Dashboard已保存为: {filename}")
        plt.show()
if __name__ == "__main__":
    analyzer = Problem3ComprehensiveAnalysis("问题2_建模数据.csv")
    analyzer.run_complete_analysis()
