import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN, AgglomerativeClustering, SpectralClustering
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from scipy.optimize import differential_evolution, minimize_scalar
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import seaborn as sns
from matplotlib.font_manager import FontProperties
import warnings
warnings.filterwarnings('ignore')
#[13]AI构建基础智能算法流程框架，我们根据实际问题情况修改和完善
#设置字体，便于后续利用
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
class AdvancedBMIGroupingMethodsFixed:
    #定义函数，修正重叠区间
    def __init__(self, data_file):
        self.df = pd.read_csv(data_file, encoding='utf-8-sig')
        self.modeling_df = self.df.dropna(subset=['孕妇BMI', '最早达标时间_天数', '风险指标']).copy()
        self.scaler = StandardScaler()
    def _fix_overlapping_intervals(self, bmi_groups, method_name="聚类"):
        if not bmi_groups:
            return bmi_groups
        #检查是否存在原始重叠
        original_overlaps = self._check_overlaps(bmi_groups, "原始")
        #没有则不修正
        if original_overlaps == 0:
            print("  无重叠，无需修正")
            return bmi_groups
        #按照下界排序
        sorted_groups = sorted(bmi_groups, key=lambda x: x[0])
        #使用中点分割法进行重叠修正
        fixed_groups = [sorted_groups[0]]
        for i in range(1, len(sorted_groups)):
            prev_lower, prev_upper = fixed_groups[-1]
            curr_lower, curr_upper = sorted_groups[i]
            if curr_lower <= prev_upper:
                #如果有重叠，计算新边界
                new_boundary = (prev_upper + curr_lower) / 2
                #更新前一个区间的上界
                fixed_groups[-1] = (prev_lower, new_boundary)
                #并且添加当前区间，下界为新边界
                fixed_groups.append((new_boundary, curr_upper))
            else:
                #如果无重叠，则直接添加为边界
                fixed_groups.append((curr_lower, curr_upper))
        #验证修正后的结果
        fixed_overlaps = self._check_overlaps(fixed_groups, "修正后")
        if fixed_overlaps == 0:
            print("  重叠修正成功")
        else:
            print(f"  仍有 {fixed_overlaps} 个重叠，使用备用方法")
            #另一个方法：用于强制无重叠数据分割
            fixed_groups = self._force_non_overlapping(bmi_groups)
            self._check_overlaps(fixed_groups, "强制修正后")
        return fixed_groups
    
    def _check_overlaps(self, bmi_groups, label=""):
        overlap_count = 0
        for i in range(len(bmi_groups)):
            for j in range(i + 1, len(bmi_groups)):
                lower1, upper1 = bmi_groups[i]
                lower2, upper2 = bmi_groups[j]
                #检查是否重叠
                if (lower1 < upper2 and upper1 > lower2):
                    overlap_count += 1
                    if label == "原始":
                        print(f"    重叠{overlap_count}: [{lower1:.1f}, {upper1:.1f}] 与 [{lower2:.1f}, {upper2:.1f}]")
        if overlap_count == 0 and label:
            print(f"    {label}: 无重叠")
        elif label and overlap_count > 0:
            print(f"    {label}: {overlap_count}个重叠")
        return overlap_count
    
    def _force_non_overlapping(self, bmi_groups):
        #获取所有的边界点
        all_bounds = []
        for lower, upper in bmi_groups:
            all_bounds.extend([lower, upper])
        bmi_min = min(all_bounds)
        bmi_max = max(all_bounds)
        n_groups = len(bmi_groups)
        #将所有数据等间距分割
        boundaries = np.linspace(bmi_min, bmi_max, n_groups + 1)
        fixed_groups = []
        for i in range(n_groups):
            fixed_groups.append((boundaries[i], boundaries[i + 1]))
        return fixed_groups
        
    def method1_gaussian_mixture_clustering(self, n_components_range=(2, 6)):
        print("方法1: 高斯混合模型(GMM)聚类 - 修正版")
        #用BMI+最早达标时间进行聚类
        features = self.modeling_df[['孕妇BMI', '最早达标时间_天数']].values
        features_scaled = self.scaler.fit_transform(features)
        best_score = -np.inf
        best_model = None
        best_n = 0
        results = []
        for n in range(n_components_range[0], n_components_range[1]+1):
            gmm = GaussianMixture(n_components=n, random_state=42, 
                                covariance_type='full')
            gmm.fit(features_scaled)
            #计算必要的评估指标
            labels = gmm.predict(features_scaled)
            aic = gmm.aic(features_scaled)
            #确保聚类数量大于1
            bic = gmm.bic(features_scaled)
            if len(set(labels)) > 1:
                silhouette = silhouette_score(features_scaled, labels)
                calinski = calinski_harabasz_score(features_scaled, labels)
            else:
                silhouette = -1
                calinski = 0
            results.append({
                '聚类数': n,
                'AIC': aic,
                'BIC': bic,
                'Silhouette得分': silhouette,
                'Calinski-Harabasz指数': calinski
            })
            #选择BIC指标最小的模型
            if -bic > best_score:
                best_score = -bic
                best_model = gmm
                best_n = n
        results_df = pd.DataFrame(results)
        print("GMM聚类评估结果:")
        print(results_df.round(3))
        #综合所有模型，并使用最佳模型进行分组
        best_labels = best_model.predict(features_scaled)
        #区间转化，转换为BMI区间
        bmi_groups_original = self._labels_to_bmi_intervals(best_labels)
        #再次修正重叠
        bmi_groups_fixed = self._fix_overlapping_intervals(bmi_groups_original, "GMM")
        print(f"\n最佳聚类数: {best_n}")
        print("GMM聚类结果 (修正后):")
        group_stats = self._evaluate_groups(bmi_groups_fixed, "GMM_修正版")
        print(group_stats.round(3))
        return bmi_groups_fixed, group_stats
    
    def method2_hierarchical_clustering(self):
        print("方法2: 层次聚类 - 修正版")
        #按照孕妇聚合数据
        women_data = self.modeling_df.groupby('孕妇代码').agg({
            '孕妇BMI': 'first',
            '最早达标时间_天数': 'first',
            '风险指标': 'first'
        }).reset_index()
        features = women_data[['孕妇BMI', '最早达标时间_天数']].values
        features_scaled = self.scaler.fit_transform(features)
        #根据所聚合的数据，计算链接矩阵
        linkage_matrix = linkage(features_scaled, method='ward')
        #尝试不同的聚类数，选择效果最好的聚类数
        best_score = -1
        best_n = 0
        results = []
        for n_clusters in range(2, 7):
            labels = fcluster(linkage_matrix, n_clusters, criterion='maxclust') - 1
            if len(set(labels)) > 1:
                silhouette = silhouette_score(features_scaled, labels)
                calinski = calinski_harabasz_score(features_scaled, labels)
                results.append({
                    '聚类数': n_clusters,
                    'Silhouette得分': silhouette,
                    'Calinski-Harabasz指数': calinski
                })
                if silhouette > best_score:
                    best_score = silhouette
                    best_n = n_clusters
        results_df = pd.DataFrame(results)
        print("层次聚类评估结果:")
        print(results_df.round(3))
        #综合所有聚类数效果，使用最佳的一个聚类数
        best_labels = fcluster(linkage_matrix, best_n, criterion='maxclust') - 1
        women_data['cluster'] = best_labels
        #将结果映射回原数据
        cluster_map = dict(zip(women_data['孕妇代码'], women_data['cluster']))
        self.modeling_df['cluster'] = self.modeling_df['孕妇代码'].map(cluster_map)
        bmi_groups_original = self._labels_to_bmi_intervals(self.modeling_df['cluster'].values)
        #对数据进行修正重叠
        bmi_groups_fixed = self._fix_overlapping_intervals(bmi_groups_original, "层次聚类")
        print(f"\n最佳聚类数: {best_n} (Silhouette: {best_score:.3f})")
        print("层次聚类结果 (修正后):")
        group_stats = self._evaluate_groups(bmi_groups_fixed, "层次聚类_修正版")
        print(group_stats.round(3))
        return bmi_groups_fixed, group_stats
    
    def method3_dbscan_clustering(self):
        print("方法3: DBSCAN密度聚类 - 修正版")
        features = self.modeling_df[['孕妇BMI', '最早达标时间_天数']].values
        features_scaled = self.scaler.fit_transform(features)
        #遍历网格以搜索最佳参数
        eps_range = np.arange(0.3, 1.5, 0.1)
        min_samples_range = [5, 10, 15, 20]
        best_score = -1
        best_params = None
        results = []
        for eps in eps_range:
            for min_samples in min_samples_range:
                dbscan = DBSCAN(eps=eps, min_samples=min_samples)
                labels = dbscan.fit_predict(features_scaled)
                n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
                n_noise = list(labels).count(-1)
                #确保至少要有2个聚类
                if n_clusters >= 2:
                    #只对非噪声点计算silhouette
                    mask = labels != -1
                    if np.sum(mask) > 1:
                        silhouette = silhouette_score(features_scaled[mask], labels[mask])
                        results.append({
                            'eps': eps,
                            'min_samples': min_samples,
                            '聚类数': n_clusters,
                            '噪声点数': n_noise,
                            'Silhouette得分': silhouette
                        })
                        if silhouette > best_score:
                            best_score = silhouette
                            best_params = (eps, min_samples)
        if not results:
            print("DBSCAN无法找到合适的聚类参数，使用默认分组")
            return None, None
        results_df = pd.DataFrame(results)
        print("DBSCAN参数搜索结果(前10个):")
        print(results_df.nlargest(10, 'Silhouette得分').round(3))
        #综合所有聚类，使用最佳参数
        best_eps, best_min_samples = best_params
        dbscan = DBSCAN(eps=best_eps, min_samples=best_min_samples)
        labels = dbscan.fit_predict(features_scaled)
        #对噪声点进行处理
        if -1 in labels:
            #将所有噪声点随机分配到离其最近的聚类
            from sklearn.neighbors import NearestNeighbors
            noise_mask = labels == -1
            if np.sum(noise_mask) > 0:
                non_noise_mask = ~noise_mask
                nn = NearestNeighbors(n_neighbors=1)
                nn.fit(features_scaled[non_noise_mask])
                distances, indices = nn.kneighbors(features_scaled[noise_mask])
                noise_labels = labels[non_noise_mask][indices.flatten()]
                labels[noise_mask] = noise_labels
        bmi_groups_original = self._labels_to_bmi_intervals(labels)
        #对重叠数据进行修正
        bmi_groups_fixed = self._fix_overlapping_intervals(bmi_groups_original, "DBSCAN")
        print(f"\n最佳参数: eps={best_eps}, min_samples={best_min_samples}")
        print("DBSCAN聚类结果 (修正后):")
        group_stats = self._evaluate_groups(bmi_groups_fixed, "DBSCAN_修正版")
        print(group_stats.round(3))
        return bmi_groups_fixed, group_stats
    
    def method4_optimal_binning(self):
        print("方法4: 风险最优化分箱 - 修正版")
        women_data = self.modeling_df.groupby('孕妇代码').agg({
            '孕妇BMI': 'first',
            '最早达标时间_天数': 'first',
            '风险指标': 'first'
        }).reset_index().sort_values('孕妇BMI')

        def calculate_total_risk(cut_points):
            if len(cut_points) == 0:
                return np.inf
            #对必要数据添加边界点
            all_cuts = [women_data['孕妇BMI'].min()] + sorted(cut_points) + [women_data['孕妇BMI'].max()]
            total_risk = 0
            for i in range(len(all_cuts) - 1):
                group_mask = (women_data['孕妇BMI'] >= all_cuts[i]) & (women_data['孕妇BMI'] < all_cuts[i+1])
                if i == len(all_cuts) - 2:  # 最后一组包含右边界
                    group_mask = (women_data['孕妇BMI'] >= all_cuts[i]) & (women_data['孕妇BMI'] <= all_cuts[i+1])
                group_data = women_data[group_mask]
                if len(group_data) == 0:
                    continue
                #计算该组数据的的风险指标
                risk_weights = {0: 1, 1: 2, 2: 4}
                group_risk = group_data['风险指标'].map(risk_weights).mean()
                total_risk += group_risk * len(group_data)
            return total_risk / len(women_data)
        
        #为寻找最优分割点，使用差分进化算法
        bmi_range = women_data['孕妇BMI'].max() - women_data['孕妇BMI'].min()
        bmi_min = women_data['孕妇BMI'].min()
        results = []
        for n_groups in range(2, 6):
            n_cuts = n_groups - 1
            #定义数据搜索的边界
            bounds = [(bmi_min + (i+1) * bmi_range / (n_cuts+1) - bmi_range/4, 
                      bmi_min + (i+1) * bmi_range / (n_cuts+1) + bmi_range/4) 
                     for i in range(n_cuts)]
            def objective(x):
                return calculate_total_risk(x)
            try:
                result = differential_evolution(objective, bounds, seed=42, maxiter=100)
                optimal_cuts = sorted(result.x)
                optimal_risk = result.fun
                results.append({
                    '分组数': n_groups,
                    '最优风险': optimal_risk,
                    '分割点': optimal_cuts
                })
            except:
                continue
        if not results:
            print("风险优化失败，使用等频分箱")
            return None, None
        #得出结果后，选择风险最小的分组
        best_result = min(results, key=lambda x: x['最优风险'])
        optimal_cuts = best_result['分割点']
        # 根据结果构建分组区间，由于方法本身是无重叠的，无需再修正重叠区间
        all_cuts = [women_data['孕妇BMI'].min()] + optimal_cuts + [women_data['孕妇BMI'].max()]
        bmi_groups = [(all_cuts[i], all_cuts[i+1]) for i in range(len(all_cuts)-1)]
        #验证其无重叠区间
        overlap_count = self._check_overlaps(bmi_groups, "风险优化")
        print(f"最优分组数: {best_result['分组数']}")
        print(f"最优风险得分: {best_result['最优风险']:.3f}")
        print("风险最优化分组结果:")
        group_stats = self._evaluate_groups(bmi_groups, "风险优化_修正版")
        print(group_stats.round(3))
        return bmi_groups, group_stats
    
    def method5_decision_tree_binning(self):
        print("方法5: 决策树分箱 - 修正版")
        from sklearn.tree import DecisionTreeRegressor
        women_data = self.modeling_df.groupby('孕妇代码').agg({
            '孕妇BMI': 'first',
            '最早达标时间_天数': 'first',
            '风险指标': 'first'
        }).reset_index()
        #使用风险指标来作为目标因变量
        X = women_data[['孕妇BMI']].values
        y = women_data['风险指标'].values
        best_score = np.inf
        best_tree = None
        results = []
        for max_leaf_nodes in range(3, 8):  #表示其有2-7个分组
            tree = DecisionTreeRegressor(max_leaf_nodes=max_leaf_nodes, 
                                       random_state=42, 
                                       min_samples_leaf=20)
            tree.fit(X, y)
            #获取分割点
            tree_splits = []
            def extract_splits(node_id, threshold_path):
                if tree.tree_.children_left[node_id] == tree.tree_.children_right[node_id]:
                    return  #定义叶子节点
                threshold = tree.tree_.threshold[node_id]
                tree_splits.append(threshold)
                extract_splits(tree.tree_.children_left[node_id], threshold_path + [threshold])
                extract_splits(tree.tree_.children_right[node_id], threshold_path + [threshold])
            extract_splits(0, [])
            if len(tree_splits) > 0:
                #计算该树的风险得分
                predictions = tree.predict(X)
                mse = np.mean((y - predictions) ** 2)
                results.append({
                    '叶子节点数': max_leaf_nodes,
                    'MSE': mse,
                    '分割点数': len(set(tree_splits)),
                    '分割点': sorted(set(tree_splits))
                })
                if mse < best_score:
                    best_score = mse
                    best_tree = tree
        if not results:
            print("决策树分箱失败")
            return None, None
        results_df = pd.DataFrame(results)
        print("决策树分箱评估:")
        print(results_df.round(3))
        #综合所有分割点，使用最佳树的分割点
        best_result = min(results, key=lambda x: x['MSE'])
        splits = best_result['分割点']
        # 构建分组区间，由于此方法本身是无重叠的，故不必再修正重叠区间
        all_cuts = [women_data['孕妇BMI'].min()] + splits + [women_data['孕妇BMI'].max()]
        all_cuts = sorted(set(all_cuts))
        bmi_groups = [(all_cuts[i], all_cuts[i+1]) for i in range(len(all_cuts)-1)]
        #验证是否有重叠区间
        overlap_count = self._check_overlaps(bmi_groups, "决策树")
        print(f"\n最佳叶子节点数: {best_result['叶子节点数']}")
        print("决策树分组结果:")
        group_stats = self._evaluate_groups(bmi_groups, "决策树_修正版")
        print(group_stats.round(3))
        return bmi_groups, group_stats
    
    def optimize_detection_timepoints(self, bmi_groups, method_name="未知方法"):
        print(f"\n{method_name} - 检测时点优化")
        if not bmi_groups:
            print("错误：BMI分组为空，无法优化时点")
            return None
        optimal_timepoints = []
        for i, (bmi_min, bmi_max) in enumerate(bmi_groups):
            #根据表格中BMI区间来筛选数据
            if i == len(bmi_groups) - 1:  #对最后一个区间，使用闭区间
                group_data = self.modeling_df[
                    (self.modeling_df['孕妇BMI'] >= bmi_min) & (self.modeling_df['孕妇BMI'] <= bmi_max)
                ]
            else:  #而对于其他区间，均使用左闭右开
                group_data = self.modeling_df[
                    (self.modeling_df['孕妇BMI'] >= bmi_min) & (self.modeling_df['孕妇BMI'] < bmi_max)
                ]
            if group_data.empty:
                print(f"  警告：组别 {i+1} (BMI [{bmi_min:.2f}, {bmi_max:.2f}]) 内没有样本数据")
                continue
            #以孕妇为主要因素，对数据进行聚合
            women_stats = group_data.groupby('孕妇代码').agg({
                '最早达标时间_天数': 'first',
                '风险指标': 'first'
            }).reset_index()
            print(f"\n  组别 {i+1}: BMI [{bmi_min:.2f}, {bmi_max:.2f}] (孕妇数 n={len(women_stats)})")
            
            #定义目标函数：平衡的成功率与时间风险
            def objective(t):
                success_rate = (women_stats['最早达标时间_天数'] <= t).mean()
                #时间风险，即越早检测风险越低，越晚检测风险越高
                if t <= 12 * 7:      #12周内，风险较低
                    time_risk = 1.0
                elif t <= 20 * 7:    #12-20周，风险适中
                    time_risk = 1.5
                elif t <= 27 * 7:    #20-27周，风险较高
                    time_risk = 2.5
                else:                #27周后，风险极高
                    time_risk = 4.0
                #若检测失败，则检测失败的代价为
                failure_risk = (1 - success_rate) * 3.0
                return time_risk + failure_risk
            #使用标量最小化来求解改模型的最优时点
            try:
                result = minimize_scalar(objective, bounds=(10*7, 30*7), method='bounded')
                optimal_time = result.x
                #评估该时点性能
                success_rate = (women_stats['最早达标时间_天数'] <= optimal_time).mean()
                #对风险等级进行评估
                if optimal_time <= 12*7:
                    risk_level = '低风险'
                elif optimal_time <= 20*7:
                    risk_level = '中风险'
                elif optimal_time <= 27*7:
                    risk_level = '较高风险'
                else:
                    risk_level = '高风险'
                #计算平均达标时间，可用于后续参考
                avg_detection_time = women_stats['最早达标时间_天数'].mean()
                optimal_timepoints.append({
                    '组别': f"组{i+1}",
                    'BMI区间': f"[{bmi_min:.2f}, {bmi_max:.2f}]",
                    '孕妇数': len(women_stats),
                    '最佳时点_天数': optimal_time,
                    '最佳时点_周数': optimal_time / 7,
                    '预期成功率': success_rate,
                    '风险等级': risk_level,
                    '平均达标时间_天数': avg_detection_time,
                    '平均达标时间_周数': avg_detection_time / 7
                })
                print(f"    最佳检测时点: {optimal_time/7:.1f}周 ({optimal_time:.0f}天)")
                print(f"    预期成功率: {success_rate:.2%}")
                print(f"    风险等级: {risk_level}")
            except Exception as e:
                print(f"    优化失败: {e}")
                continue
        if optimal_timepoints:
            optimal_df = pd.DataFrame(optimal_timepoints)
            print(f"\n{method_name} - 最优时点汇总:")
            display_cols = ['组别', 'BMI区间', '孕妇数', '最佳时点_周数', '预期成功率', '风险等级']
            print(optimal_df[display_cols].round(2))
            return optimal_df
        else:
            print("所有组别的时点优化均失败")
            return None
    
    def sensitivity_analysis(self, optimal_timepoints, method_name="未知方法"):
        if optimal_timepoints is None or optimal_timepoints.empty:
            print("错误：需要先进行时点优化")
            return None
        print(f"\n{method_name} - 时点敏感性分析")
        error_scenarios = [-7, -3, 0, 3, 7]  #设置±7天误差，增加结果的准确性
        sensitivity_results = []
        for _, group_info in optimal_timepoints.iterrows():
            bmi_range_str = group_info['BMI区间']
            bmi_min, bmi_max = [float(x) for x in bmi_range_str.strip('[]').split(', ')]
            #获取数据
            if group_info['组别'] == f"组{len(optimal_timepoints)}":
                group_data = self.modeling_df[
                    (self.modeling_df['孕妇BMI'] >= bmi_min) & (self.modeling_df['孕妇BMI'] <= bmi_max)
                ]
            else:
                group_data = self.modeling_df[
                    (self.modeling_df['孕妇BMI'] >= bmi_min) & (self.modeling_df['孕妇BMI'] < bmi_max)
                ]
            if group_data.empty:
                continue
            women_stats = group_data.groupby('孕妇代码').agg({
                '最早达标时间_天数': 'first'
            }).reset_index()
            optimal_time = group_info['最佳时点_天数']
            for error in error_scenarios:
                adjusted_time = optimal_time + error
                success_rate = (women_stats['最早达标时间_天数'] <= adjusted_time).mean()
                sensitivity_results.append({
                    '组别': group_info['组别'],
                    '误差天数': error,
                    '调整后时点_周数': adjusted_time / 7,
                    '预期成功率': success_rate
                })
        sensitivity_df = pd.DataFrame(sensitivity_results)
        #构建一个透视表，该透视表用于展示敏感性
        pivot_df = sensitivity_df.pivot_table(
            index='组别', columns='误差天数', values='预期成功率'
        )
        print("不同误差下的预期成功率变化:")
        print(pivot_df.round(3))
        #计算数据的敏感性等级
        print("\n各组敏感性评估:")
        for group_name in pivot_df.index:
            success_rates = pivot_df.loc[group_name]
            deviation = success_rates.max() - success_rates.min()
            if deviation < 0.1:
                level = "低敏感"
            elif deviation < 0.2:
                level = "中敏感"
            else:
                level = "高敏感"
            print(f"  {group_name}: 成功率波动范围 {deviation:.2%} - {level}")
        return sensitivity_df, pivot_df
    
    def visualize_groups_and_timepoints(self, bmi_groups, optimal_timepoints, method_name="未知方法"):
        if not bmi_groups or optimal_timepoints is None:
            print("缺少可视化数据")
            return
        print(f"\n生成{method_name}可视化图表...")
        #创建一个新的图表
        fig = plt.figure(figsize=(16, 12))
        #1.将BMI的分布和分组可视化
        ax1 = plt.subplot(2, 3, 1)
        bmi_values = self.modeling_df['孕妇BMI'].values
        plt.hist(bmi_values, bins=50, alpha=0.7, color='lightblue', edgecolor='black')
        #对直方图进行标记，标记其分组边界
        colors = ['red', 'orange', 'green', 'purple', 'brown', 'pink']
        for i, (bmi_min, bmi_max) in enumerate(bmi_groups):
            color = colors[i % len(colors)]
            plt.axvline(bmi_min, color=color, linestyle='--', alpha=0.8, linewidth=2)
            if i == len(bmi_groups) - 1:  # 最后一个区间显示右边界
                plt.axvline(bmi_max, color=color, linestyle='--', alpha=0.8, linewidth=2)
            #在图上添加组别标签
            mid_point = (bmi_min + bmi_max) / 2
            plt.text(mid_point, plt.ylim()[1] * 0.8, f'组{i+1}', 
                    ha='center', va='center', fontsize=10, color=color, fontweight='bold')
        plt.xlabel('孕妇BMI')
        plt.ylabel('频次')
        plt.title(f'{method_name} - BMI分布与分组')
        plt.grid(True, alpha=0.3)
        #2.输出各组最佳检测时点对比
        ax2 = plt.subplot(2, 3, 2)
        groups = optimal_timepoints['组别']
        timepoints_weeks = optimal_timepoints['最佳时点_周数']
        success_rates = optimal_timepoints['预期成功率']
        bars = plt.bar(groups, timepoints_weeks, alpha=0.7, color='lightgreen')
        #在已生成的柱状图上标注成功率
        for i, (bar, rate) in enumerate(zip(bars, success_rates)):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + 0.5, 
                    f'{rate:.1%}', ha='center', va='bottom', fontweight='bold')
        plt.xlabel('BMI组别')
        plt.ylabel('最佳检测时点 (周)')
        plt.title('各组最佳检测时点')
        plt.grid(True, alpha=0.3)
        #3.绘制成功率-时点散点图
        ax3 = plt.subplot(2, 3, 3)
        plt.scatter(timepoints_weeks, success_rates, s=100, alpha=0.7, c=range(len(groups)), cmap='viridis')
        for i, (x, y, group) in enumerate(zip(timepoints_weeks, success_rates, groups)):
            plt.annotate(group, (x, y), xytext=(5, 5), textcoords='offset points', fontsize=9)
        plt.xlabel('最佳检测时点 (周)')
        plt.ylabel('预期成功率')
        plt.title('时点-成功率关系')
        plt.grid(True, alpha=0.3)
        #4.绘制各组风险分布，以明显的查看
        ax4 = plt.subplot(2, 3, 4)
        risk_levels = optimal_timepoints['风险等级'].value_counts()
        colors_risk = ['green', 'yellow', 'orange', 'red']
        plt.pie(risk_levels.values, labels=risk_levels.index, autopct='%1.1f%%', 
                colors=colors_risk[:len(risk_levels)])
        plt.title('各组风险等级分布')
        #5.绘制BMI-达标时间散点图
        ax5 = plt.subplot(2, 3, 5)
        #对绘制的图形，按组着色
        for i, (bmi_min, bmi_max) in enumerate(bmi_groups):
            if i == len(bmi_groups) - 1:
                mask = (self.modeling_df['孕妇BMI'] >= bmi_min) & (self.modeling_df['孕妇BMI'] <= bmi_max)
            else:
                mask = (self.modeling_df['孕妇BMI'] >= bmi_min) & (self.modeling_df['孕妇BMI'] < bmi_max)
            group_data = self.modeling_df[mask]
            if not group_data.empty:
                color = colors[i % len(colors)]
                plt.scatter(group_data['孕妇BMI'], group_data['最早达标时间_天数']/7, 
                           alpha=0.6, color=color, label=f'组{i+1}', s=30)
        plt.xlabel('孕妇BMI')
        plt.ylabel('最早达标时间 (周)')
        plt.title('BMI vs 达标时间分布')
        plt.legend()
        plt.grid(True, alpha=0.3)
        #6.输出的详细信息表格
        ax6 = plt.subplot(2, 3, 6)
        ax6.axis('tight')
        ax6.axis('off')
        #准备表格数据
        table_data = optimal_timepoints[['组别', 'BMI区间', '孕妇数', '最佳时点_周数', '预期成功率', '风险等级']].round(2)
        table_data['预期成功率'] = table_data['预期成功率'].apply(lambda x: f'{x:.1%}')
        table = ax6.table(cellText=table_data.values, colLabels=table_data.columns,
                         cellLoc='center', loc='center', fontsize=9)
        table.auto_set_font_size(False)
        table.set_fontsize(8)
        table.scale(1, 1.5)
        ax6.set_title('详细结果汇总', pad=20)
        plt.tight_layout()
        #将输出结果保存为图片
        filename = f'{method_name}_BMI分组与时点优化可视化.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"可视化图表已保存为: {filename}")
        plt.show()
        return fig
    
    def _labels_to_bmi_intervals(self, labels):
        unique_labels = sorted(set(labels))
        bmi_groups = []
        for label in unique_labels:
            mask = np.array(labels) == label
            group_bmis = self.modeling_df[mask]['孕妇BMI']
            bmi_groups.append((group_bmis.min(), group_bmis.max()))
        return sorted(bmi_groups, key=lambda x: x[0])
    
    def _evaluate_groups(self, bmi_groups, method_name):
        results = []
        for i, (lower, upper) in enumerate(bmi_groups):
            if i == len(bmi_groups) - 1:
                group_data = self.modeling_df[(self.modeling_df['孕妇BMI'] >= lower) & 
                                            (self.modeling_df['孕妇BMI'] <= upper)]
            else:
                group_data = self.modeling_df[(self.modeling_df['孕妇BMI'] >= lower) & 
                                            (self.modeling_df['孕妇BMI'] < upper)]
            if len(group_data) == 0:
                continue
            women_stats = group_data.groupby('孕妇代码').agg({
                '最早达标时间_天数': 'first',
                '风险指标': 'first'
            }).reset_index()
            risk_distribution = women_stats['风险指标'].value_counts().sort_index()
            total_women = len(women_stats)
            risk_weights = {0: 1, 1: 2, 2: 4}
            weighted_risk = sum(risk_weights.get(risk, 2) * count 
                              for risk, count in risk_distribution.items()) / total_women
            results.append({
                '组别': f"组{i+1}",
                'BMI区间': f"[{lower:.1f}, {upper:.1f}]",
                '孕妇数': total_women,
                '平均达标时间': women_stats['最早达标时间_天数'].mean(),
                '风险得分': weighted_risk,
                '低风险比例': risk_distribution.get(0, 0) / total_women,
                '高风险比例': risk_distribution.get(1, 0) / total_women,
                '极高风险比例': risk_distribution.get(2, 0) / total_women
            })
        return pd.DataFrame(results)
    
    def compare_all_methods(self):
        print("修正版高级建模方法综合对比 - 含时点优化与可视化")
        methods_results = {}
        all_optimal_timepoints = {}
        #依次运行前面所建立是所有方法，并得出结果
        try:
            groups1, stats1 = self.method1_gaussian_mixture_clustering()
            if stats1 is not None:
                methods_results['GMM_修正版'] = (groups1, stats1)
                #为该方法优化时点
                optimal_tp1 = self.optimize_detection_timepoints(groups1, "GMM_修正版")
                if optimal_tp1 is not None:
                    all_optimal_timepoints['GMM_修正版'] = optimal_tp1
                    #进行敏感性分析
                    self.sensitivity_analysis(optimal_tp1, "GMM_修正版")
                    #可视化结果
                    self.visualize_groups_and_timepoints(groups1, optimal_tp1, "GMM_修正版")
        except Exception as e:
            print(f"GMM方法失败: {e}")
        try:
            groups2, stats2 = self.method2_hierarchical_clustering()
            if stats2 is not None:
                methods_results['层次聚类_修正版'] = (groups2, stats2)
                optimal_tp2 = self.optimize_detection_timepoints(groups2, "层次聚类_修正版")
                if optimal_tp2 is not None:
                    all_optimal_timepoints['层次聚类_修正版'] = optimal_tp2
                    self.sensitivity_analysis(optimal_tp2, "层次聚类_修正版")
                    self.visualize_groups_and_timepoints(groups2, optimal_tp2, "层次聚类_修正版")
        except Exception as e:
            print(f"层次聚类失败: {e}")
        try:
            groups3, stats3 = self.method3_dbscan_clustering()
            if stats3 is not None:
                methods_results['DBSCAN_修正版'] = (groups3, stats3)
                optimal_tp3 = self.optimize_detection_timepoints(groups3, "DBSCAN_修正版")
                if optimal_tp3 is not None:
                    all_optimal_timepoints['DBSCAN_修正版'] = optimal_tp3
                    self.sensitivity_analysis(optimal_tp3, "DBSCAN_修正版")
                    self.visualize_groups_and_timepoints(groups3, optimal_tp3, "DBSCAN_修正版")
        except Exception as e:
            print(f"DBSCAN方法失败: {e}")
        try:
            groups4, stats4 = self.method4_optimal_binning()
            if stats4 is not None:
                methods_results['风险优化_修正版'] = (groups4, stats4)
                optimal_tp4 = self.optimize_detection_timepoints(groups4, "风险优化_修正版")
                if optimal_tp4 is not None:
                    all_optimal_timepoints['风险优化_修正版'] = optimal_tp4
                    self.sensitivity_analysis(optimal_tp4, "风险优化_修正版")
                    self.visualize_groups_and_timepoints(groups4, optimal_tp4, "风险优化_修正版")
        except Exception as e:
            print(f"风险优化方法失败: {e}")
        try:
            groups5, stats5 = self.method5_decision_tree_binning()
            if stats5 is not None:
                methods_results['决策树_修正版'] = (groups5, stats5)
                optimal_tp5 = self.optimize_detection_timepoints(groups5, "决策树_修正版")
                if optimal_tp5 is not None:
                    all_optimal_timepoints['决策树_修正版'] = optimal_tp5
                    self.sensitivity_analysis(optimal_tp5, "决策树_修正版")
                    self.visualize_groups_and_timepoints(groups5, optimal_tp5, "决策树_修正版")
        except Exception as e:
            print(f"决策树方法失败: {e}")

        #运行完所有方法后，综合对比，包括时点优化结果
        if methods_results:
            print("各方法综合评估结果")
            comparison = []
            for method_name, (groups, stats) in methods_results.items():
                #基础分组评估
                avg_risk = stats['风险得分'].mean()
                risk_std = stats['风险得分'].std()
                n_groups = len(stats)
                overlap_count = self._check_overlaps(groups, "")
                #时点优化评估
                if method_name in all_optimal_timepoints:
                    optimal_tp = all_optimal_timepoints[method_name]
                    avg_success_rate = optimal_tp['预期成功率'].mean()
                    avg_timepoint = optimal_tp['最佳时点_周数'].mean()
                    low_risk_ratio = (optimal_tp['风险等级'] == '低风险').sum() / len(optimal_tp)
                else:
                    avg_success_rate = 0
                    avg_timepoint = 0
                    low_risk_ratio = 0
                comparison.append({
                    '方法': method_name,
                    '分组数': n_groups,
                    '平均风险得分': avg_risk,
                    '风险得分标准差': risk_std,
                    '平均成功率': avg_success_rate,
                    '平均最佳时点_周': avg_timepoint,
                    '低风险组比例': low_risk_ratio,
                    '重叠检查': '无重叠' if overlap_count == 0 else f'{overlap_count}个重叠'
                })
            comparison_df = pd.DataFrame(comparison)
            #对所有方法进行评估后，按综合评分排序，根据前面定义，风险得分越小越好，成功率越高越好
            comparison_df['综合评分'] = comparison_df['平均风险得分'] * 2 - comparison_df['平均成功率'] * 3 + (1 - comparison_df['低风险组比例']) * 1
            comparison_df = comparison_df.sort_values('综合评分')
            print("方法综合对比结果:")
            display_cols = ['方法', '分组数', '平均风险得分', '平均成功率', '平均最佳时点_周', '低风险组比例', '重叠检查']
            print(comparison_df[display_cols].round(3))
            #综合所有方法，得出的最佳方法
            best_method = comparison_df.iloc[0]['方法']
            print(f"\n综合推荐方法: {best_method}")
            print(f"   平均风险得分: {comparison_df.iloc[0]['平均风险得分']:.3f}")
            print(f"   平均成功率: {comparison_df.iloc[0]['平均成功率']:.3f}")
            print(f"   平均最佳时点: {comparison_df.iloc[0]['平均最佳时点_周']:.1f}周")
            #将所有输出结果到Excel
            self.save_comprehensive_results(methods_results, all_optimal_timepoints, comparison_df)
            return methods_results, all_optimal_timepoints
        else:
            print("所有方法都失败了")
            return None, None
    
    def save_comprehensive_results(self, methods_results, all_optimal_timepoints, comparison_df):
        print(f"\n保存综合分析结果...")
        try:
            filename = "问题2_综合BMI分组与时点优化结果.xlsx"
            with pd.ExcelWriter(filename, engine='openpyxl') as writer:
                #1.方法对比总表
                comparison_df.to_excel(writer, sheet_name='方法综合对比', index=False)
                #2.各方法的分组统计
                for method_name, (groups, stats) in methods_results.items():
                    sheet_name = f"{method_name}_分组统计"[:31]  # Excel sheet名称限制
                    stats.to_excel(writer, sheet_name=sheet_name, index=False)
                #3.各方法的最优时点
                for method_name, optimal_tp in all_optimal_timepoints.items():
                    sheet_name = f"{method_name}_最优时点"[:31]
                    optimal_tp.to_excel(writer, sheet_name=sheet_name, index=False)
                #4.BMI分组区间总结
                groups_summary = []
                for method_name, (groups, _) in methods_results.items():
                    for i, (bmi_min, bmi_max) in enumerate(groups):
                        groups_summary.append({
                            '方法': method_name,
                            '组别': f'组{i+1}',
                            'BMI下界': bmi_min,
                            'BMI上界': bmi_max,
                            '区间范围': bmi_max - bmi_min
                        })
                groups_summary_df = pd.DataFrame(groups_summary)
                groups_summary_df.to_excel(writer, sheet_name='BMI分组区间总结', index=False)
            print(f"综合结果已保存到: {filename}")
        except Exception as e:
            print(f"保存Excel文件失败: {e}")

#已准备好的所有方法，开始代入数据使用
def run_comprehensive_bmi_analysis():
    try:
        print("开始运行综合BMI分组与时点优化分析...")
        analyzer = AdvancedBMIGroupingMethodsFixed("问题2_建模数据.csv")
        methods_results, optimal_timepoints = analyzer.compare_all_methods()
        if methods_results and optimal_timepoints:
            print("综合分析完成！")
            print("\n分析成果总结:")
            print(f"成功测试了 {len(methods_results)} 种BMI分组方法")
            print(f"为 {len(optimal_timepoints)} 种方法完成了时点优化")
            print(f"生成了 {len(optimal_timepoints)} 套可视化图表")
            print(f"完成了敏感性分析")
            print(f"保存了综合分析报告")
            print("\n各方法最佳时点概览:")
            for method_name, optimal_tp in optimal_timepoints.items():
                avg_timepoint = optimal_tp['最佳时点_周数'].mean()
                avg_success = optimal_tp['预期成功率'].mean()
                print(f"  {method_name}: 平均时点 {avg_timepoint:.1f}周, 平均成功率 {avg_success:.1%}")
            return methods_results, optimal_timepoints
        else:
            print("分析失败")
            return None, None
    except Exception as e:
        print(f"综合分析失败: {e}")
        import traceback
        traceback.print_exc()
        return None, None
def run_fixed_advanced_modeling():
    return run_comprehensive_bmi_analysis()
if __name__ == "__main__":
    run_comprehensive_bmi_analysis()