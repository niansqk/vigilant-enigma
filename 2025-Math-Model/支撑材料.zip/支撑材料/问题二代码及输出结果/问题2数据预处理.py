import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')
#设置字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
def problem2_preprocessing(df_file):
    print("问题2数据预处理：风险指标与Y染色体浓度达标时间")
    #读取由第一问预处理得到的数据
    df = pd.read_csv(df_file, encoding='utf-8-sig')
    print("原始数据形状: {}".format(df.shape))
    print("原始数据列名: {}".format(list(df.columns)))
    #创建一个为处理后的数据副本
    processed_df = df.copy()
    print("\n1. 创建风险指标")

    def calculate_risk_level(pregnancy_days):
        if pd.isna(pregnancy_days):
            return np.nan
        if pregnancy_days <= 84:  #12周=84天
            return 0  #定义为低风险
        elif pregnancy_days <= 189:  #27周=189天
            return 1  #定义为高风险
        else:
            return 2  #定义为极高风险
    
    #应用风险等级计算
    processed_df['风险指标'] = processed_df['检测时怀孕天数'].apply(calculate_risk_level)
    #统计风险等级分布
    risk_counts = processed_df['风险指标'].value_counts().sort_index()
    print("风险等级分布:")
    risk_labels = {0: '低风险(≤12周)', 1: '高风险(13-27周)', 2: '极高风险(≥28周)'}
    for level, count in risk_counts.items():
        if not pd.isna(level):
            percentage = count / len(processed_df) * 100
            print("  {}: {} 例 ({:.2f}%)".format(
                risk_labels[int(level)], count, percentage))
    #检查缺失值
    risk_missing = processed_df['风险指标'].isnull().sum()
    if risk_missing > 0:
        print("  缺失值: {} 例 ({:.2f}%)".format(
            risk_missing, risk_missing / len(processed_df) * 100))
    print("\n2. 计算Y染色体浓度达标时间")
    #Y染色体浓度达标的阈值
    TARGET_CONCENTRATION = 0.04
    print("Y染色体浓度达标阈值: {:.2f}% ({:.4f})".format(
        TARGET_CONCENTRATION * 100, TARGET_CONCENTRATION))
    #统计当前数据达标情况
    current_qualified = (processed_df['Y染色体浓度'] >= TARGET_CONCENTRATION).sum()
    current_qualified_rate = current_qualified / len(processed_df) * 100
    print("当前检测中达标样本: {} 例 ({:.2f}%)".format(
        current_qualified, current_qualified_rate))
    #按孕妇分组，计算每个孕妇的最早达标时间
    print("\n按孕妇计算最早达标时间...")
    #创建一个字典，记录达标时间
    earliest_qualified_time = {}
    #根据孕妇代码，分组
    grouped = processed_df.groupby('孕妇代码')
    total_women = len(grouped)
    qualified_women = 0
    print("总共孕妇数量: {}".format(total_women))
    for woman_code, group in grouped:
        #根据检测时怀孕天数排序
        group_sorted = group.sort_values('检测时怀孕天数')
        #找出第一次达标的时间
        qualified_records = group_sorted[
            group_sorted['Y染色体浓度'] >= TARGET_CONCENTRATION
        ]
        if len(qualified_records) > 0:
            #得到最早达标时间
            earliest_time = qualified_records['检测时怀孕天数'].iloc[0]
            earliest_qualified_time[woman_code] = earliest_time
            qualified_women += 1
        else:
            #如果未达标，则设为NaN
            earliest_qualified_time[woman_code] = np.nan
    print("达标孕妇数量: {} ({:.2f}%)".format(
        qualified_women, qualified_women / total_women * 100))
    #将得出的最早达标时间映射回原数据
    processed_df['最早达标时间_天数'] = processed_df['孕妇代码'].map(earliest_qualified_time)
    #统计所有数据的最早达标时间
    qualified_times = processed_df['最早达标时间_天数'].dropna()
    if len(qualified_times) > 0:
        print("\n最早达标时间统计 (天数):")
        print("  均值: {:.1f} 天".format(qualified_times.mean()))
        print("  中位数: {:.1f} 天".format(qualified_times.median()))
        print("  标准差: {:.1f} 天".format(qualified_times.std()))
        print("  范围: {:.1f} - {:.1f} 天".format(
            qualified_times.min(), qualified_times.max()))
        #根据划分的风险等级统计达标时间
        print("\n按风险等级统计最早达标时间:")
        for risk_level in [0, 1, 2]:
            risk_data = processed_df[
                (processed_df['风险指标'] == risk_level) & 
                (processed_df['最早达标时间_天数'].notna())
            ]['最早达标时间_天数']
            if len(risk_data) > 0:
                print("  {}: 均值 {:.1f} 天, n={}".format(
                    risk_labels[risk_level], risk_data.mean(), len(risk_data)))
    print("\n3. 创建达标状态指标")
    #检验当前检测是否达标
    processed_df['当前检测达标'] = (
        processed_df['Y染色体浓度'] >= TARGET_CONCENTRATION
    ).astype(int)
    #得到该孕妇是否曾经达标过
    processed_df['曾经达标'] = processed_df['最早达标时间_天数'].notna().astype(int)
    #综合统计达标情况
    current_qualified_count = processed_df['当前检测达标'].sum()
    ever_qualified_count = processed_df['曾经达标'].sum()
    print("当前检测达标: {} 例 ({:.2f}%)".format(
        current_qualified_count, current_qualified_count / len(processed_df) * 100))
    print("曾经达标: {} 例 ({:.2f}%)".format(
        ever_qualified_count, ever_qualified_count / len(processed_df) * 100))
    print("\n4. 按风险等级分析达标情况")
    #根据按风险等级来划分达标情况
    risk_analysis = processed_df.groupby('风险指标').agg({
        '孕妇代码': 'count',
        '曾经达标': 'mean',
        '最早达标时间_天数': ['mean', 'median', 'std'],
        'Y染色体浓度': 'mean',
        '孕妇BMI': 'mean'
    }).round(3)
    print("风险等级达标分析:")
    for risk_level in [0, 1, 2]:
        if risk_level in risk_analysis.index:
            data = risk_analysis.loc[risk_level]
            print("  {}: 样本数={}, 达标率={:.1%}, 平均达标时间={:.1f}天".format(
                risk_labels[risk_level], 
                int(data[('孕妇代码', 'count')]),
                data[('曾经达标', 'mean')],
                data[('最早达标时间_天数', 'mean')] if not pd.isna(data[('最早达标时间_天数', 'mean')]) else 0
            ))
    print("\n5. 数据质量检查")
    #检查新变量是否存在缺失值
    new_vars = ['风险指标', '最早达标时间_天数', '当前检测达标', '曾经达标']
    print("新变量缺失值统计:")
    for var in new_vars:
        if var in processed_df.columns:
            missing_count = processed_df[var].isnull().sum()
            missing_rate = missing_count / len(processed_df)
            print("  {}: {} ({:.2f}%)".format(var, missing_count, missing_rate * 100))
    #检查数据是否完整
    complete_cases = processed_df[['风险指标', 'Y染色体浓度', '孕妇BMI']].dropna()
    print("\n完整数据样本数: {} ({:.2f}%)".format(
        len(complete_cases), len(complete_cases) / len(processed_df) * 100))
    print("\n6. 保存处理后的数据")
    #保存并输出完整的数据
    output_file = "问题2_预处理数据_完整版.csv"
    processed_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    #创建新的精简数据集
    modeling_vars = [
        #表格内基本信息
        '序号', '孕妇代码', '年龄', '身高', '体重', '孕妇BMI',
        #与时间相关的信息
        '检测时怀孕天数', '末次月经距检测日天数',
        #与检测结果相关
        'Y染色体浓度', 'Y染色体的Z值', 'X染色体的Z值',
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值',
        'GC含量',
        #分类变量
        'IVF妊娠_编码', '怀孕次数_编码', '胎儿健康_编码',
        'T13_异常', 'T18_异常', 'T21_异常',
        #新增的变量
        '风险指标', '最早达标时间_天数', '当前检测达标', '曾经达标'
    ]
    #只保留还存在的列
    available_modeling_vars = [var for var in modeling_vars if var in processed_df.columns]
    modeling_df = processed_df[available_modeling_vars].copy()
    modeling_file = "问题2_建模数据.csv"
    modeling_df.to_csv(modeling_file, index=False, encoding='utf-8-sig')
    print("已保存:")
    print("   {}: 完整预处理数据 ({} 行 × {} 列)".format(
        output_file, processed_df.shape[0], processed_df.shape[1]))
    print("   {}: 建模用数据 ({} 行 × {} 列)".format(
        modeling_file, modeling_df.shape[0], modeling_df.shape[1]))
    print("\n7. 数据摘要报告")
    summary_stats = {
        '总样本数': len(processed_df),
        '总孕妇数': len(processed_df['孕妇代码'].unique()),
        '当前达标检测数': current_qualified_count,
        '当前达标率(%)': round(current_qualified_count / len(processed_df) * 100, 2),
        '曾经达标孕妇数': qualified_women,
        '曾经达标率(%)': round(qualified_women / total_women * 100, 2),
        '低风险检测数': risk_counts.get(0, 0),
        '高风险检测数': risk_counts.get(1, 0),
        '极高风险检测数': risk_counts.get(2, 0),
        '平均最早达标时间(天)': round(qualified_times.mean(), 2) if len(qualified_times) > 0 else np.nan
    }
    summary_df = pd.DataFrame(list(summary_stats.items()), columns=['指标', '数值'])
    summary_df.to_csv("问题2_数据摘要.csv", index=False, encoding='utf-8-sig')
    print("   问题2_数据摘要.csv: 数据摘要统计")
    print("   问题2数据预处理完成！")
    print("新增关键变量:")
    print("  1. 风险指标: 基于检测时间的风险等级 (0=低, 1=高, 2=极高)")
    print("  2. 最早达标时间_天数: Y染色体浓度≥4%的最早时间(天)")
    print("  3. 达标状态: 当前检测达标 & 曾经达标指标")
    return processed_df, summary_stats
if __name__ == "__main__":
    #使用之前第一问预处理后的数据
    input_file = "男胎_预处理数据_精简版.csv"
    #用于进行问题2预处理
    processed_data, summary = problem2_preprocessing(input_file)
    print("\n处理完成！可以进行问题2的建模分析。")
