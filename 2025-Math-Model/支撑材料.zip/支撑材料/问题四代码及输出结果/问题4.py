import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (classification_report, confusion_matrix, roc_auc_score, 
                           f1_score, matthews_corrcoef, accuracy_score)
import warnings
warnings.filterwarnings('ignore')
#[13]利用AI生成基本要求流程代码框架，再根据实际需求进行修改和完善
class RobustModelComparison:
    def __init__(self):
        self.models = {}
        self.results = []
        self.feature_names = None
        self.X_processed = None
        self.y_processed = None
    def load_and_clean_data(self, file_path):
        self.df = pd.read_csv(file_path, encoding='utf-8')
        for col in self.df.columns:
            dtype = self.df[col].dtype
            null_count = self.df[col].isnull().sum()
            print(f"  {col}: {dtype}, 缺失值: {null_count}")
        # 目标变量分析
        target_dist = self.df['胎儿健康_编码'].value_counts().sort_index()
        print(f"\n目标变量分布:")
        print(f"  健康(1): {target_dist.get(1, 0)} 例 ({target_dist.get(1, 0)/len(self.df)*100:.1f}%)")
        print(f"  异常(0): {target_dist.get(0, 0)} 例 ({target_dist.get(0, 0)/len(self.df)*100:.1f}%)")
        return self.df
    def robust_feature_engineering(self):
        # 选择数值型特征
        numeric_features = [
            # Z值特征 (核心)
            '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值', 'X染色体的Z值',
            # 基本信息
            '年龄', '身高', '体重', '孕妇BMI', '生产次数',
            # 妊娠相关
            '检测抽血次数', '检测时怀孕天数', 'IVF妊娠_编码',
            # 测序质量
            '原始读段数', '在参考基因组上比对的比例', '重复读段的比例',
            '唯一比对的读段数', 'GC含量', '被过滤掉读段数的比例',
            # 染色体GC含量
            '13号染色体的GC含量', '18号染色体的GC含量', '21号染色体的GC含量',
            # X染色体浓度
            'X染色体浓度'
        ]
        available_features = []
        for feature in numeric_features:
            if feature in self.df.columns:
                try:
                    self.df[feature] = pd.to_numeric(self.df[feature], errors='coerce')
                    available_features.append(feature)
                except:
                    print(f"  跳过特征 {feature}: 无法转换为数值类型")
        print(f"  可用数值特征: {len(available_features)} 个")
        # 处理分类特征
        categorical_features = []
        if '怀孕次数' in self.df.columns:
            try:
                self.df['怀孕次数_数值'] = self.df['怀孕次数'].astype(str).str.extract('(\d+)').astype(float)
                available_features.append('怀孕次数_数值')
                if '怀孕次数' in available_features:
                    available_features.remove('怀孕次数')
            except:
                print("  怀孕次数特征处理失败")
        # 创建特征矩阵
        X = self.df[available_features].copy()
        y = self.df['胎儿健康_编码'].copy()
        # 确保y是数值类型
        y = pd.to_numeric(y, errors='coerce')
        # 移除y中的缺失值对应的样本
        valid_indices = ~y.isnull()
        X = X[valid_indices]
        y = y[valid_indices]
        print(f"  清理后样本数: {len(X)}")
        # 处理特征缺失值
        missing_info = []
        for col in X.columns:
            missing_count = X[col].isnull().sum()
            if missing_count > 0:
                missing_info.append((col, missing_count, missing_count/len(X)*100))
        if missing_info:
            print(f"    存在缺失值的特征:")
            for col, count, pct in missing_info:
                print(f"      {col}: {count} 个 ({pct:.1f}%)")
        # 填充缺失值
        for col in X.columns:
            if X[col].isnull().sum() > 0:
                if X[col].dtype in ['float64', 'int64']:
                    # 数值特征用中位数填充
                    median_val = X[col].median()
                    X[col].fillna(median_val, inplace=True)
                else:
                    # 其他类型用众数填充
                    mode_val = X[col].mode()[0] if not X[col].mode().empty else 0
                    X[col].fillna(mode_val, inplace=True)
        # 确保所有特征都是数值类型
        for col in X.columns:
            X[col] = pd.to_numeric(X[col], errors='coerce')
            if X[col].isnull().sum() > 0:
                X[col].fillna(X[col].median(), inplace=True)
        # 创建工程特征
        # Z值相关特征
        chromosome_z_cols = ['13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值']
        available_z_cols = [col for col in chromosome_z_cols if col in X.columns]
        if available_z_cols:
            # Z值绝对值
            for col in available_z_cols:
                X[f'{col}_abs'] = np.abs(X[col])
            # Z值统计特征
            z_abs_cols = [f'{col}_abs' for col in available_z_cols]
            X['max_z_abs'] = X[z_abs_cols].max(axis=1)
            X['mean_z_abs'] = X[z_abs_cols].mean(axis=1)
            X['std_z_abs'] = X[z_abs_cols].std(axis=1)
            # 异常Z值计数
            X['z_abnormal_count_2.5'] = (X[z_abs_cols] >= 2.5).sum(axis=1)
            X['z_abnormal_count_3.0'] = (X[z_abs_cols] >= 3.0).sum(axis=1)
        # BMI相关特征
        if '孕妇BMI' in X.columns:
            # BMI分类
            X['BMI_high'] = (X['孕妇BMI'] >= 35).astype(int)
            X['BMI_normalized'] = (X['孕妇BMI'] - X['孕妇BMI'].mean()) / X['孕妇BMI'].std()
            # BMI与Z值交互（如果Z值特征存在）
            if available_z_cols:
                for col in available_z_cols:
                    X[f'BMI_{col}_interaction'] = X['孕妇BMI'] * X[f'{col}_abs']
        # 测序质量特征
        quality_cols = ['在参考基因组上比对的比例', 'GC含量', '重复读段的比例']
        available_quality_cols = [col for col in quality_cols if col in X.columns]
        if len(available_quality_cols) >= 2:
            # 质量综合评分
            if '在参考基因组上比对的比例' in X.columns and 'GC含量' in X.columns:
                X['sequencing_quality_score'] = (
                    X['在参考基因组上比对的比例'] * 
                    (1 - np.abs(X['GC含量'] - 0.5))
                )
            # GC含量偏离度
            if 'GC含量' in X.columns:
                X['GC_deviation'] = np.abs(X['GC含量'] - 0.5)
        print(f"  最终特征数: {X.shape[1]}")
        print(f"  最终样本数: {X.shape[0]}")
        # 检查是否还有非数值数据
        non_numeric = []
        for col in X.columns:
            if not np.issubdtype(X[col].dtype, np.number):
                non_numeric.append(col)
        if non_numeric:
            print(f"  警告: 发现非数值列: {non_numeric}")
            # 强制转换为数值
            for col in non_numeric:
                X[col] = pd.to_numeric(X[col], errors='coerce')
                X[col].fillna(X[col].median(), inplace=True)
        inf_cols = []
        for col in X.columns:
            if np.isinf(X[col]).any() or np.isnan(X[col]).any():
                inf_cols.append(col)
        if inf_cols:
            print(f"  处理无穷大/NaN值: {inf_cols}")
            for col in inf_cols:
                X[col] = X[col].replace([np.inf, -np.inf], np.nan)
                X[col].fillna(X[col].median(), inplace=True)
        self.feature_names = X.columns.tolist()
        self.X_processed = X
        self.y_processed = y
        return X, y
    def setup_robust_models(self):
        models_config = {
            'RandomForest': RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                min_samples_split=10,
                min_samples_leaf=5,
                class_weight='balanced',
                random_state=42,
                n_jobs=1  # 避免并行问题
            ),
            'GradientBoosting': GradientBoostingClassifier(
                n_estimators=100,
                learning_rate=0.1,
                max_depth=6,
                min_samples_split=20,
                min_samples_leaf=10,
                random_state=42
            ),
            'LogisticRegression': LogisticRegression(
                class_weight='balanced',
                random_state=42,
                max_iter=1000,
                solver='liblinear'
            ),
            'SVM_RBF': SVC(
                kernel='rbf',
                class_weight='balanced',
                probability=True,
                random_state=42,
                C=1.0,
                gamma='scale'
            ),
            'DecisionTree': DecisionTreeClassifier(
                max_depth=8,
                min_samples_split=20,
                min_samples_leaf=10,
                class_weight='balanced',
                random_state=42
            ),
            'KNeighbors': KNeighborsClassifier(
                n_neighbors=5,
                weights='uniform'
            ),
            'GaussianNB': GaussianNB(),
            'LinearDA': LinearDiscriminantAnalysis(),
            'MLPClassifier': MLPClassifier(
                hidden_layer_sizes=(50, 25),
                max_iter=300,
                random_state=42,
                early_stopping=True,
                validation_fraction=0.1
            )
        }
        print(f"  配置了 {len(models_config)} 个模型")
        return models_config
    def evaluate_models_robust(self, X, y):
        # 数据标准化方法
        scalers_config = {
            'RobustScaler': RobustScaler(),
            'StandardScaler': StandardScaler(),
            'MinMaxScaler': MinMaxScaler()
        }
        models_config = self.setup_robust_models()
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        print(f"  训练集: {X_train.shape[0]} 样本")
        print(f"  测试集: {X_test.shape[0]} 样本")
        # 交叉验证设置
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        print(f"\n模型性能评估:")
        print(f"{'模型名称':<15} {'标准化':<12} {'CV均值':<8} {'CV标准差':<8} {'测试AUC':<8} {'敏感性':<8} {'特异性':<8} {'F1得分':<8}")
        # 评估每个模型
        for model_name, model in models_config.items():
            best_result = None
            best_auc = 0
            for scaler_name, scaler in scalers_config.items():
                try:
                    # 数据标准化
                    X_train_scaled = scaler.fit_transform(X_train.astype(float))
                    X_test_scaled = scaler.transform(X_test.astype(float))
                    if np.any(np.isnan(X_train_scaled)) or np.any(np.isinf(X_train_scaled)):
                        print(f"    {model_name} + {scaler_name}: 数据标准化后存在NaN/Inf")
                        continue
                    # 交叉验证
                    try:
                        cv_scores = cross_val_score(
                            model, X_train_scaled, y_train, 
                            cv=cv, scoring='roc_auc', n_jobs=1
                        )
                        cv_mean = cv_scores.mean()
                        cv_std = cv_scores.std()
                    except Exception as e:
                        print(f"    {model_name} + {scaler_name}: 交叉验证失败 - {str(e)[:50]}")
                        continue
                    try:
                        model.fit(X_train_scaled, y_train)
                    except Exception as e:
                        print(f"    {model_name} + {scaler_name}: 训练失败 - {str(e)[:50]}")
                        continue
                    try:
                        y_pred = model.predict(X_test_scaled)
                        
                        if hasattr(model, 'predict_proba'):
                            y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
                            test_auc = roc_auc_score(y_test, y_pred_proba)
                        else:
                            test_auc = roc_auc_score(y_test, y_pred)
                    except Exception as e:
                        print(f"    {model_name} + {scaler_name}: 预测失败 - {str(e)[:50]}")
                        continue
                    try:
                        cm = confusion_matrix(y_test, y_pred)
                        if cm.shape == (2, 2):
                            tn, fp, fn, tp = cm.ravel()
                            sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
                            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
                        else:
                            sensitivity = specificity = 0
                        f1 = f1_score(y_test, y_pred, average='weighted')
                    except:
                        sensitivity = specificity = f1 = 0
                    result = {
                        'model_name': model_name,
                        'scaler_name': scaler_name,
                        'cv_mean': cv_mean,
                        'cv_std': cv_std,
                        'test_auc': test_auc,
                        'sensitivity': sensitivity,
                        'specificity': specificity,
                        'f1_score': f1,
                        'model': model,
                        'scaler': scaler
                    }
                    self.results.append(result)
                    if test_auc > best_auc:
                        best_auc = test_auc
                        best_result = result 
                except Exception as e:
                    print(f"    {model_name} + {scaler_name}: 整体失败 - {str(e)[:50]}")
                    continue
            if best_result:
                r = best_result
                print(f"{r['model_name']:<15} {r['scaler_name']:<12} {r['cv_mean']:<8.4f} {r['cv_std']:<8.4f} {r['test_auc']:<8.4f} {r['sensitivity']:<8.4f} {r['specificity']:<8.4f} {r['f1_score']:<8.4f}")
            else:
                print(f"{model_name:<15} {'所有组合':<12} {'失败':<8} {'失败':<8} {'失败':<8} {'失败':<8} {'失败':<8} {'失败':<8}")
        return X_train, X_test, y_train, y_test
    def analyze_results(self):
        if not self.results:
            print("  没有成功的模型结果")
            return None
        # 按AUC排序
        sorted_results = sorted(self.results, key=lambda x: x['test_auc'], reverse=True)
        print(f"\n成功训练的模型排名:")
        print(f"{'排名':<4} {'模型+标准化':<25} {'AUC':<8} {'敏感性':<8} {'特异性':<8} {'F1得分':<8}")
        for i, result in enumerate(sorted_results[:10]):
            model_combo = f"{result['model_name']}+{result['scaler_name']}"
            print(f"{i+1:<4} {model_combo:<25} {result['test_auc']:<8.4f} {result['sensitivity']:<8.4f} {result['specificity']:<8.4f} {result['f1_score']:<8.4f}")
        # 最佳模型分析
        if sorted_results:
            best_model = sorted_results[0]
            print(f"\n最佳模型详情:")
            print(f"  模型: {best_model['model_name']}")
            print(f"  标准化: {best_model['scaler_name']}")
            print(f"  测试AUC: {best_model['test_auc']:.4f}")
            print(f"  交叉验证: {best_model['cv_mean']:.4f} ± {best_model['cv_std']:.4f}")
            print(f"  敏感性: {best_model['sensitivity']:.4f}")
            print(f"  特异性: {best_model['specificity']:.4f}")
            print(f"  F1得分: {best_model['f1_score']:.4f}")
            # 性能评级
            auc = best_model['test_auc']
            if auc >= 0.90:
                grade = "A级 - 优秀"
            elif auc >= 0.85:
                grade = "B级 - 良好"
            elif auc >= 0.80:
                grade = "C级 - 可接受"
            else:
                grade = "D级 - 需改进"
            print(f"  性能等级: {grade}")
        model_success = {}
        for result in self.results:
            model_name = result['model_name']
            if model_name not in model_success:
                model_success[model_name] = 0
            model_success[model_name] += 1
        print(f"\n模型成功率统计:")
        for model_name, success_count in sorted(model_success.items(), key=lambda x: x[1], reverse=True):
            print(f"  {model_name:<15}: {success_count}/3 种标准化方法成功")
        return sorted_results
    def save_results_to_csv(self, sorted_results):
        if not sorted_results:
            print("  没有结果可保存")
            return
        # 准备数据
        results_data = []
        for i, result in enumerate(sorted_results):
            results_data.append({
                '排名': i + 1,
                '模型名称': result['model_name'],
                '标准化方法': result['scaler_name'],
                'CV均值': round(result['cv_mean'], 4),
                'CV标准差': round(result['cv_std'], 4),
                '测试AUC': round(result['test_auc'], 4),
                '敏感性': round(result['sensitivity'], 4),
                '特异性': round(result['specificity'], 4),
                'F1得分': round(result['f1_score'], 4)
            })
        results_df = pd.DataFrame(results_data)
        results_df.to_csv('女胎异常判定_模型对比结果.csv', index=False, encoding='utf-8-sig')
        print(f"  主要结果已保存: 女胎异常判定_模型对比结果.csv")
        top10_df = results_df.head(10)
        top10_df.to_csv('女胎异常判定_Top10模型.csv', index=False, encoding='utf-8-sig')
        print(f"  Top 10结果已保存: 女胎异常判定_Top10模型.csv")
        if sorted_results:
            best_model = sorted_results[0]
            # 性能分析数据
            analysis_data = {
                '分析项目': [
                    '最佳模型', '最佳标准化', '最佳AUC', '最佳敏感性', '最佳特异性',
                    '最佳F1得分', '交叉验证均值', '交叉验证标准差', '成功模型数', '总测试配置'
                ],
                '结果': [
                    best_model['model_name'],
                    best_model['scaler_name'],
                    round(best_model['test_auc'], 4),
                    round(best_model['sensitivity'], 4),
                    round(best_model['specificity'], 4),
                    round(best_model['f1_score'], 4),
                    round(best_model['cv_mean'], 4),
                    round(best_model['cv_std'], 4),
                    len(sorted_results),
                    len(sorted_results)
                ]
            }
            analysis_df = pd.DataFrame(analysis_data)
            analysis_df.to_csv('女胎异常判定_分析摘要.csv', index=False, encoding='utf-8-sig')
            print(f"  分析摘要已保存: 女胎异常判定_分析摘要.csv")
        model_success = {}
        for result in sorted_results:
            model_name = result['model_name']
            if model_name not in model_success:
                model_success[model_name] = []
            model_success[model_name].append(result['test_auc'])
        success_data = []
        for model_name, aucs in model_success.items():
            success_data.append({
                '模型名称': model_name,
                '成功配置数': len(aucs),
                '平均AUC': round(np.mean(aucs), 4),
                '最佳AUC': round(max(aucs), 4),
                '最差AUC': round(min(aucs), 4),
                'AUC标准差': round(np.std(aucs), 4)
            })
        success_df = pd.DataFrame(success_data)
        success_df = success_df.sort_values('最佳AUC', ascending=False)
        success_df.to_csv('女胎异常判定_模型成功率统计.csv', index=False, encoding='utf-8-sig')
        print(f"  模型统计已保存: 女胎异常判定_模型成功率统计.csv")
        return results_df
    def generate_recommendations(self, sorted_results):
        if not sorted_results:
            print("  无可用模型，建议:")
            print("  1. 检查数据质量")
            print("  2. 简化特征工程")
            print("  3. 增加样本数量")
            return
        best_model = sorted_results[0]
        print(f"基于最佳模型的建议:")
        print(f"  推荐模型: {best_model['model_name']}")
        print(f"  推荐标准化: {best_model['scaler_name']}")
        auc = best_model['test_auc']
        sensitivity = best_model['sensitivity']
        specificity = best_model['specificity']
        print(f"\n临床应用指导:")
        if auc >= 0.85 and sensitivity >= 0.80 and specificity >= 0.80:
            print(f"  模型性能良好，可用于临床辅助诊断")
            print(f"  建议在医生指导下使用")
        elif auc >= 0.80:
            print(f"  模型性能可接受，建议谨慎使用")
            print(f"  需要结合其他临床指标")
        else:
            print(f"  模型性能不足，不建议直接临床使用")
            print(f"  需要进一步优化或收集更多数据")
        print(f"\n模型改进建议:")
        if len(sorted_results) < 5:
            print(f"  • 数据质量问题较多，建议清理原始数据")
        if sensitivity < 0.80:
            print(f"  • 敏感性偏低，建议调整分类阈值")
        if specificity < 0.80:
            print(f"  • 特异性偏低，建议增加特征或样本")
        recommendations = []
        if auc >= 0.90:
            grade = "A级 - 优秀"
            clinical_use = "可用于临床辅助诊断"
        elif auc >= 0.85:
            grade = "B级 - 良好"
            clinical_use = "可用于临床筛查，建议结合其他指标"
        elif auc >= 0.80:
            grade = "C级 - 可接受"
            clinical_use = "需要进一步优化后谨慎使用"
        else:
            grade = "D级 - 需改进"
            clinical_use = "不建议直接用于临床应用"
        recommendations.append({
            '建议类型': '性能等级',
            '内容': grade,
            '详细说明': f"基于AUC={auc:.4f}的评级"
        })
        recommendations.append({
            '建议类型': '临床应用',
            '内容': clinical_use,
            '详细说明': f"考虑敏感性={sensitivity:.4f}, 特异性={specificity:.4f}"
        })
        recommendations.append({
            '建议类型': '推荐配置',
            '内容': f"{best_model['model_name']} + {best_model['scaler_name']}",
            '详细说明': f"该配置获得最佳AUC={best_model['test_auc']:.4f}"
        })
        if sensitivity < 0.80:
            recommendations.append({
                '建议类型': '模型改进',
                '内容': '提高敏感性',
                '详细说明': '当前敏感性偏低，建议调整分类阈值或增加训练样本'
            })
        if specificity < 0.80:
            recommendations.append({
                '建议类型': '模型改进',
                '内容': '提高特异性',
                '详细说明': '当前特异性偏低，建议优化特征工程或模型参数'
            })
        rec_df = pd.DataFrame(recommendations)
        rec_df.to_csv('女胎异常判定_临床建议.csv', index=False, encoding='utf-8-sig')
        print(f"  临床建议已保存: 女胎异常判定_临床建议.csv")
def run_robust_analysis():
        analyzer = RobustModelComparison()
        # 加载和清理数据
        df = analyzer.load_and_clean_data("女胎数据_预处理后.csv")
        # 特征工程
        X, y = analyzer.robust_feature_engineering()
        # 模型评估
        X_train, X_test, y_train, y_test = analyzer.evaluate_models_robust(X, y)
        sorted_results = analyzer.analyze_results()
        analyzer.generate_recommendations(sorted_results)
        if sorted_results:
            results_df = analyzer.save_results_to_csv(sorted_results)
        if sorted_results:
            print(f"成功训练 {len(analyzer.results)} 个模型配置")
            print(f"最佳模型AUC: {sorted_results[0]['test_auc']:.4f}")
            print(f"\n生成的CSV文件:")
            print(f"  1. 女胎异常判定_模型对比结果.csv - 完整对比结果")
            print(f"  2. 女胎异常判定_Top10模型.csv - 前10名模型")
            print(f"  3. 女胎异常判定_分析摘要.csv - 分析摘要")
            print(f"  4. 女胎异常判定_模型成功率统计.csv - 模型统计")
            print(f"  5. 女胎异常判定_临床建议.csv - 临床应用建议")
        else:
            print(f"所有模型训练都失败了，请检查数据质量")
        print(f"="*80)
        return analyzer, sorted_results
def save_feature_importance(analyzer, sorted_results, output_file='女胎异常判定_特征重要性.csv'):
    if not sorted_results or not analyzer.results:
        print("没有可用的结果来提取特征重要性")
        return
    best_model_result = sorted_results[0]
    best_model = best_model_result['model']
    # 检查是否有特征重要性
    if hasattr(best_model, 'feature_importances_'):
        importance_data = []
        feature_names = analyzer.feature_names
        importances = best_model.feature_importances_
        for i, (feature, importance) in enumerate(zip(feature_names, importances)):
            importance_data.append({
                '排名': i + 1,
                '特征名称': feature,
                '重要性得分': round(importance, 6),
                '重要性百分比': round(importance * 100, 2)
            })
        # 按重要性排序
        importance_df = pd.DataFrame(importance_data)
        importance_df = importance_df.sort_values('重要性得分', ascending=False)
        importance_df['排名'] = range(1, len(importance_df) + 1)
        importance_df.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"特征重要性已保存: {output_file}")
        print(f"\nTop 10 重要特征:")
        for _, row in importance_df.head(10).iterrows():
            print(f"  {row['排名']:2d}. {row['特征名称']:<30}: {row['重要性得分']:.6f} ({row['重要性百分比']:.2f}%)")
        return importance_df
    else:
        print(f"最佳模型 ({best_model_result['model_name']}) 不支持特征重要性分析")
        return None
def generate_summary_report(analyzer, sorted_results, output_file='女胎异常判定_完整报告.csv'):
    summary_data = []
    best_model = sorted_results[0]
    total_configs = len(analyzer.results)
    summary_data.extend([
        {'类别': '基本信息', '项目': '数据文件', '值': '女胎数据_预处理后.csv'},
        {'类别': '基本信息', '项目': '样本总数', '值': len(analyzer.X_processed)},
        {'类别': '基本信息', '项目': '特征总数', '值': len(analyzer.feature_names)},
        {'类别': '基本信息', '项目': '测试配置数', '值': total_configs},
        {'类别': '基本信息', '项目': '成功配置数', '值': len(sorted_results)},
        {'类别': '最佳模型', '项目': '模型名称', '值': best_model['model_name']},
        {'类别': '最佳模型', '项目': '标准化方法', '值': best_model['scaler_name']},
        {'类别': '最佳模型', '项目': '测试AUC', '值': round(best_model['test_auc'], 4)},
        {'类别': '最佳模型', '项目': '交叉验证均值', '值': round(best_model['cv_mean'], 4)},
        {'类别': '最佳模型', '项目': '交叉验证标准差', '值': round(best_model['cv_std'], 4)},
        {'类别': '最佳模型', '项目': '敏感性', '值': round(best_model['sensitivity'], 4)},
        {'类别': '最佳模型', '项目': '特异性', '值': round(best_model['specificity'], 4)},
        {'类别': '最佳模型', '项目': 'F1得分', '值': round(best_model['f1_score'], 4)},
    ])
    auc = best_model['test_auc']
    if auc >= 0.90:
        grade = "A级-优秀"
    elif auc >= 0.85:
        grade = "B级-良好"
    elif auc >= 0.80:
        grade = "C级-可接受"
    else:
        grade = "D级-需改进"
    summary_data.append({'类别': '性能评级', '项目': '等级', '值': grade})
    model_stats = {}
    for result in sorted_results:
        model_name = result['model_name']
        if model_name not in model_stats:
            model_stats[model_name] = []
        model_stats[model_name].append(result['test_auc'])
    for model_name, aucs in model_stats.items():
        summary_data.extend([
            {'类别': f'模型统计_{model_name}', '项目': '成功配置数', '值': len(aucs)},
            {'类别': f'模型统计_{model_name}', '项目': '平均AUC', '值': round(np.mean(aucs), 4)},
            {'类别': f'模型统计_{model_name}', '项目': '最佳AUC', '值': round(max(aucs), 4)},
        ])
    summary_df = pd.DataFrame(summary_data)
    summary_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"完整报告已保存: {output_file}")
    return summary_df
if __name__ == "__main__":
    analyzer, results = run_robust_analysis()
    if results and analyzer:
        save_feature_importance(analyzer, results)
        generate_summary_report(analyzer, results)
        print(f"\n所有结果已保存完毕！")