import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'STSong']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10
#女胎数据处理
def preprocess_female_data_simple(excel_file_path, enable_visualization=True):
    df = pd.read_excel(excel_file_path, sheet_name='女胎检测数据')
    processed_df = df.copy()
    #末次月经日期+检测日期转化为新变量末次月经距离检测日的天数
    def calc_days_diff(row):
        try:
            check_date_str = str(int(row['检测日期']))
            check_date = datetime.strptime(check_date_str, '%Y%m%d')
            if isinstance(row['末次月经'], (int, float)):
                last_period = pd.Timestamp('1899-12-30') + pd.Timedelta(days=row['末次月经'])
            else:
                last_period = pd.to_datetime(row['末次月经'])
            # 计算天数差
            return (check_date - last_period).days
        except:
            return np.nan
    processed_df['末次月经距离检测日天数'] = processed_df.apply(calc_days_diff, axis=1)
    valid_days = processed_df['末次月经距离检测日天数'].dropna()
    print(f"   计算完成，有效样本: {len(valid_days)}，范围: {valid_days.min():.0f}-{valid_days.max():.0f}天")
    #编码IVF妊娠状态
    ivf_mapping = {'自然受孕': 0, 'IVF（试管婴儿）': 1}
    processed_df['IVF妊娠_编码'] = processed_df['IVF妊娠'].map(ivf_mapping)
    # 转换孕周为天数 
    def weeks_to_days(week_str):
        try:
            if pd.isna(week_str):
                return np.nan
            week_str = str(week_str)
            if 'w' in week_str:
                parts = week_str.replace('w', '').split('+')
                weeks = int(parts[0])
                days = int(parts[1]) if len(parts) > 1 and parts[1] else 0
                return weeks * 7 + days
            else:
                return float(week_str) * 7
        except:
            return np.nan
    processed_df['检测时怀孕天数'] = processed_df['检测孕周'].apply(weeks_to_days)
    valid_preg_days = processed_df['检测时怀孕天数'].dropna()
    print(f"   转换完成，范围: {valid_preg_days.min():.0f}-{valid_preg_days.max():.0f}天")
    # 解析染色体异常
    def parse_chromosome(abnormality):
        if pd.isna(abnormality):
            return {'T13': 0, 'T18': 0, 'T21': 0}
        abnormality_str = str(abnormality)
        return {
            'T13': 1 if 'T13' in abnormality_str else 0,
            'T18': 1 if 'T18' in abnormality_str else 0,
            'T21': 1 if 'T21' in abnormality_str else 0
        }
    # 应用解析函数
    chromosome_results = processed_df['染色体的非整倍体'].apply(parse_chromosome)
    processed_df['T13_异常'] = [result['T13'] for result in chromosome_results]
    processed_df['T18_异常'] = [result['T18'] for result in chromosome_results]
    processed_df['T21_异常'] = [result['T21'] for result in chromosome_results]
    # 统计染色体异常
    t13_count = processed_df['T13_异常'].sum()
    t18_count = processed_df['T18_异常'].sum()
    t21_count = processed_df['T21_异常'].sum()
    total_abnormal = (processed_df['T13_异常'] | processed_df['T18_异常'] | processed_df['T21_异常']).sum()
    print(f"   T13异常: {t13_count} 例")
    print(f"   T18异常: {t18_count} 例")
    print(f"   T21异常: {t21_count} 例")
    print(f"   总计异常: {total_abnormal} 例，正常: {len(processed_df) - total_abnormal} 例")
    #根据染色体异常编码胎儿健康状态
    processed_df['胎儿健康_编码'] = np.where(
        (processed_df['T13_异常'] == 0) & 
        (processed_df['T18_异常'] == 0) & 
        (processed_df['T21_异常'] == 0),
        1,  # 健康
        0   # 不健康
    )
    health_counts = processed_df['胎儿健康_编码'].value_counts().sort_index()
    print(f"   基于染色体异常的健康状态分布:")
    for code, count in health_counts.items():
        status = "健康" if code == 1 else "不健康"
        print(f"     {status} (编码={code}): {count} 例")
    # 验证逻辑的正确性
    healthy_samples = processed_df[processed_df['胎儿健康_编码'] == 1]
    unhealthy_samples = processed_df[processed_df['胎儿健康_编码'] == 0]
    print(f"   验证:")
    print(f"     健康样本中染色体异常数: T13={healthy_samples['T13_异常'].sum()}, T18={healthy_samples['T18_异常'].sum()}, T21={healthy_samples['T21_异常'].sum()}")
    print(f"     不健康样本中染色体异常数: T13={unhealthy_samples['T13_异常'].sum()}, T18={unhealthy_samples['T18_异常'].sum()}, T21={unhealthy_samples['T21_异常'].sum()}")
    #[8]利用AI进行数据预处理可视化分析
    if enable_visualization:
        # 1. 数据概览可视化
        create_female_data_overview_plots(processed_df)
        # 2. 分类变量分布可视化
        create_female_categorical_distribution_plots(processed_df)
        # 3. 连续变量分布可视化
        create_female_continuous_distribution_plots(processed_df)
        # 4. 数据质量分析可视化
        create_female_data_quality_plots(processed_df)
        # 5. 相关性初步分析可视化
        create_female_preliminary_correlation_plots(processed_df)
        print("女胎数据预处理可视化分析完成！")
    #选择最终特征
    final_features = [
        # 基本信息
        '序号', '孕妇代码', '年龄', '身高', '体重', '孕妇BMI',
        '怀孕次数', '生产次数', '检测抽血次数',
        # 预处理后的新特征
        '末次月经距离检测日天数',    
        'IVF妊娠_编码',            
        '检测时怀孕天数',           
        'T13_异常', 'T18_异常', 'T21_异常',      
        '胎儿健康_编码',           
        # 生化检测特征
        '原始读段数', '在参考基因组上比对的比例', '重复读段的比例',
        '唯一比对的读段数', 'GC含量', '被过滤掉读段数的比例',
        # 染色体Z值特征
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值', 'X染色体的Z值',
        # 染色体GC含量特征
        '13号染色体的GC含量', '18号染色体的GC含量', '21号染色体的GC含量',
        'X染色体浓度'
    ]
    available_features = [feat for feat in final_features if feat in processed_df.columns]
    missing_features = [feat for feat in final_features if feat not in processed_df.columns]
    if missing_features:
        print(f"   缺失特征: {missing_features}")
    # 创建最终数据集
    final_df = processed_df[available_features].copy()
    return final_df
def create_female_data_overview_plots(df):
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('女胎数据预处理概览', fontsize=16, fontweight='bold')
    # 1. 样本量统计
    sample_info = {
        '总样本数': len(df),
        '完整样本': len(df.dropna()),
        '有效染色体数据': len(df.dropna(subset=['T13_异常', 'T18_异常', 'T21_异常']))
    }
    bars1 = axes[0, 0].bar(sample_info.keys(), sample_info.values(), 
                          color=['skyblue', 'lightgreen', 'orange'], alpha=0.8)
    axes[0, 0].set_title('女胎样本量统计')
    axes[0, 0].set_ylabel('样本数')
    for bar, value in zip(bars1, sample_info.values()):
        axes[0, 0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 20, 
                       f'{value}', ha='center', va='bottom', fontweight='bold')
    # 2. 年龄分布
    if '年龄' in df.columns:
        age_data = df['年龄'].dropna()
        axes[0, 1].hist(age_data, bins=20, color='lightcoral', alpha=0.7, edgecolor='black')
        axes[0, 1].axvline(age_data.mean(), color='red', linestyle='--', linewidth=2, 
                          label=f'均值: {age_data.mean():.1f}岁')
        axes[0, 1].set_title('女胎孕妇年龄分布')
        axes[0, 1].set_xlabel('年龄（岁）')
        axes[0, 1].set_ylabel('频数')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
    # 3. BMI分布
    if '孕妇BMI' in df.columns:
        bmi_data = df['孕妇BMI'].dropna()
        axes[1, 0].hist(bmi_data, bins=20, color='lightblue', alpha=0.7, edgecolor='black')
        axes[1, 0].axvline(18.5, color='blue', linestyle=':', label='偏瘦')
        axes[1, 0].axvline(24, color='green', linestyle=':', label='正常')
        axes[1, 0].axvline(28, color='orange', linestyle=':', label='超重')
        axes[1, 0].axvline(bmi_data.mean(), color='red', linestyle='--', linewidth=2,
                          label=f'均值: {bmi_data.mean():.1f}')
        axes[1, 0].set_title('女胎孕妇BMI分布')
        axes[1, 0].set_xlabel('BMI')
        axes[1, 0].set_ylabel('频数')
        axes[1, 0].legend()
        axes[1, 0].grid(True, alpha=0.3)
    # 4. 胎儿健康状态分布
    if '胎儿健康_编码' in df.columns:
        health_counts = df['胎儿健康_编码'].value_counts()
        labels = ['不健康' if x == 0 else '健康' for x in health_counts.index]
        colors = ['lightcoral', 'lightgreen']
        wedges, texts, autotexts = axes[1, 1].pie(health_counts.values, labels=labels, 
                                                 autopct='%1.1f%%', colors=colors, startangle=90)
        axes[1, 1].set_title('女胎健康状态分布')
        # 添加数量标注
        for i, (label, count) in enumerate(zip(labels, health_counts.values)):
            axes[1, 1].text(0.8, 0.8-i*0.1, f'{label}: {count}例', 
                           transform=axes[1, 1].transAxes, fontsize=9,
                           bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
    plt.tight_layout()
    plt.savefig('女胎数据预处理_概览分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
def create_female_categorical_distribution_plots(df):
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('女胎分类变量分布分析', fontsize=16, fontweight='bold')
    axes = axes.flatten()
    plot_idx = 0
    # 1. IVF妊娠分布
    if 'IVF妊娠_编码' in df.columns:
        ivf_counts = df['IVF妊娠_编码'].value_counts(dropna=False)
        ivf_labels = {0: '自然受孕', 1: 'IVF试管'}
        colors = plt.cm.Set3(np.linspace(0, 1, len(ivf_counts)))
        labels = [ivf_labels.get(k, f'编码{k}') for k in ivf_counts.index]
        wedges, texts, autotexts = axes[plot_idx].pie(ivf_counts.values, labels=labels,
                                                    autopct='%1.1f%%', colors=colors, startangle=90)
        axes[plot_idx].set_title('IVF妊娠方式分布')
        plot_idx += 1
    # 2. 染色体异常汇总
    chromosome_vars = ['T13_异常', 'T18_异常', 'T21_异常']
    available_chromosomes = [var for var in chromosome_vars if var in df.columns]
    if available_chromosomes:
        chromosomes = ['T13', 'T18', 'T21']
        abnormal_counts = []
        normal_counts = []
        for i, var in enumerate(available_chromosomes):
            abnormal_count = df[var].sum() if var in df.columns else 0
            normal_count = len(df) - abnormal_count
            abnormal_counts.append(abnormal_count)
            normal_counts.append(normal_count)
        x = np.arange(len(chromosomes[:len(available_chromosomes)]))
        width = 0.35
        bars1 = axes[plot_idx].bar(x, abnormal_counts, width, label='异常', color='red', alpha=0.7)
        bars2 = axes[plot_idx].bar(x, normal_counts, width, bottom=abnormal_counts, 
                                  label='正常', color='green', alpha=0.7)
        axes[plot_idx].set_title('女胎染色体异常分布')
        axes[plot_idx].set_xlabel('染色体类型')
        axes[plot_idx].set_ylabel('样本数')
        axes[plot_idx].set_xticks(x)
        axes[plot_idx].set_xticklabels(chromosomes[:len(available_chromosomes)])
        axes[plot_idx].legend()
        # 添加数值标签
        for i, (bar1, bar2) in enumerate(zip(bars1, bars2)):
            if abnormal_counts[i] > 0:
                axes[plot_idx].text(bar1.get_x() + bar1.get_width()/2, 
                                   bar1.get_height()/2, f'{abnormal_counts[i]}',
                                   ha='center', va='center', fontweight='bold', color='white')
            axes[plot_idx].text(bar2.get_x() + bar2.get_width()/2,
                               abnormal_counts[i] + bar2.get_height()/2, f'{normal_counts[i]}',
                               ha='center', va='center', fontweight='bold', color='white')
        plot_idx += 1
    # 3. 怀孕次数分布
    if '怀孕次数' in df.columns:
        preg_counts = df['怀孕次数'].value_counts(dropna=False)
        colors = plt.cm.Set3(np.linspace(0, 1, len(preg_counts)))
        wedges, texts, autotexts = axes[plot_idx].pie(preg_counts.values, 
                                                     labels=[f'{k}次' if not pd.isna(k) else '缺失' for k in preg_counts.index],
                                                     autopct='%1.1f%%', colors=colors, startangle=90)
        axes[plot_idx].set_title('女胎怀孕次数分布')
        plot_idx += 1
    # 4. 健康编码vs原始健康状态对比
    if '胎儿健康_编码' in df.columns and '胎儿是否健康' in df.columns:
        comparison_data = df[['胎儿是否健康', '胎儿健康_编码']].dropna()
        if len(comparison_data) > 0:
            # 统计不一致的情况
            encoded_healthy = (comparison_data['胎儿健康_编码'] == 1).sum()
            encoded_unhealthy = (comparison_data['胎儿健康_编码'] == 0).sum()
            bars = axes[plot_idx].bar(['基于染色体的健康', '基于染色体的不健康'], 
                                    [encoded_healthy, encoded_unhealthy],
                                    color=['lightgreen', 'lightcoral'], alpha=0.8)
            axes[plot_idx].set_title('基于染色体异常的健康状态编码')
            axes[plot_idx].set_ylabel('样本数')
            # 添加数量标签
            for bar, count in zip(bars, [encoded_healthy, encoded_unhealthy]):
                axes[plot_idx].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                                   f'{count}', ha='center', va='bottom', fontweight='bold')
            plot_idx += 1
    # 隐藏多余的子图
    for i in range(plot_idx, 4):
        axes[i].set_visible(False)
    plt.tight_layout()
    plt.savefig('女胎数据预处理_分类变量分布.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
def create_female_continuous_distribution_plots(df):
    # 定义女胎相关的连续变量
    continuous_vars = [
        '年龄', '身高', '体重', '孕妇BMI', 
        '末次月经距离检测日天数', '检测时怀孕天数',
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值', 
        'X染色体的Z值', '13号染色体的GC含量', '18号染色体的GC含量', '21号染色体的GC含量',
        'X染色体浓度', 'GC含量'
    ]
    available_vars = [var for var in continuous_vars if var in df.columns]
    n_vars = len(available_vars)
    n_cols = 3
    n_rows = (n_vars + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5*n_rows))
    fig.suptitle('女胎连续变量分布分析', fontsize=16, fontweight='bold')
    if n_rows == 1:
        axes = axes.reshape(1, -1) if n_vars > 1 else [axes]
    axes = axes.flatten() if n_vars > 1 else [axes]
    for i, var in enumerate(available_vars):
        if i >= len(axes):
            break    
        data = df[var].dropna()
        if len(data) == 0:
            axes[i].text(0.5, 0.5, f'{var}\n无数据', ha='center', va='center',
                        transform=axes[i].transAxes, fontsize=12)
            axes[i].set_title(var)
            continue
        # 直方图 + 核密度估计
        axes[i].hist(data, bins=30, density=True, alpha=0.7, color='skyblue', edgecolor='black')
        # 核密度估计
        try:
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(data)
            x_range = np.linspace(data.min(), data.max(), 100)
            axes[i].plot(x_range, kde(x_range), 'r-', linewidth=2, label='KDE')
        except:
            pass
        # 添加统计信息
        mean_val = data.mean()
        median_val = data.median()
        axes[i].axvline(mean_val, color='red', linestyle='--', linewidth=2, label=f'均值: {mean_val:.3f}')
        axes[i].axvline(median_val, color='orange', linestyle='--', linewidth=2, label=f'中位数: {median_val:.3f}')
        axes[i].set_title(var)
        axes[i].set_ylabel('密度')
        axes[i].legend()
        axes[i].grid(True, alpha=0.3)
    # 隐藏多余的子图
    for j in range(len(available_vars), len(axes)):
        axes[j].set_visible(False)
    plt.tight_layout()
    plt.savefig('女胎数据预处理_连续变量分布.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
def create_female_data_quality_plots(df):
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('女胎数据质量分析', fontsize=16, fontweight='bold')
    # 1. 缺失值分析
    key_columns = ['年龄', '孕妇BMI', '末次月经距离检测日天数', 'IVF妊娠_编码', 
                   '检测时怀孕天数', 'T13_异常', 'T18_异常', 'T21_异常', '胎儿健康_编码']
    available_key_cols = [col for col in key_columns if col in df.columns]
    if available_key_cols:
        missing_counts = []
        col_names = []
        for col in available_key_cols:
            missing_count = df[col].isnull().sum()
            if missing_count > 0:  # 只显示有缺失值的列
                missing_counts.append(missing_count)
                col_names.append(col)
        if missing_counts:
            bars = axes[0, 0].barh(range(len(col_names)), missing_counts, color='red', alpha=0.7)
            axes[0, 0].set_yticks(range(len(col_names)))
            axes[0, 0].set_yticklabels(col_names)
            axes[0, 0].set_xlabel('缺失值数量')
            axes[0, 0].set_title('关键字段缺失值统计')
            axes[0, 0].grid(True, alpha=0.3, axis='x')
            # 添加数值标签
            for i, (bar, value) in enumerate(zip(bars, missing_counts)):
                axes[0, 0].text(bar.get_width() + 5, i, f'{value}', 
                               va='center', fontweight='bold')
        else:
            axes[0, 0].text(0.5, 0.5, '🎉 关键字段都没有缺失值！', 
                           ha='center', va='center', transform=axes[0, 0].transAxes,
                           fontsize=14, fontweight='bold', color='green')
            axes[0, 0].set_title('关键字段缺失值统计')
    # 2. 染色体异常检测率分析
    chromosome_vars = ['T13_异常', 'T18_异常', 'T21_异常']
    available_chroms = [var for var in chromosome_vars if var in df.columns]
    if available_chroms:
        chrom_names = [var.replace('_异常', '') for var in available_chroms]
        abnormal_rates = [(df[var].sum() / len(df) * 100) for var in available_chroms]
        bars = axes[0, 1].bar(chrom_names, abnormal_rates, color=['red', 'orange', 'gold'], alpha=0.8)
        axes[0, 1].set_title('女胎染色体异常检出率')
        axes[0, 1].set_ylabel('异常检出率 (%)')
        axes[0, 1].grid(True, alpha=0.3, axis='y')
        # 添加百分比标签
        for bar, rate in zip(bars, abnormal_rates):
            axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
                           f'{rate:.2f}%', ha='center', va='bottom', fontweight='bold')
    # 3. 样本完整性分析
    complete_data = df.dropna()
    total_samples = len(df)
    complete_samples = len(complete_data)
    incomplete_samples = total_samples - complete_samples
    sizes = [complete_samples, incomplete_samples]
    labels = [f'完整样本\n{complete_samples}例', f'不完整样本\n{incomplete_samples}例']
    colors = ['lightgreen', 'lightcoral']
    wedges, texts, autotexts = axes[1, 0].pie(sizes, labels=labels, autopct='%1.1f%%', 
                                             colors=colors, startangle=90)
    axes[1, 0].set_title('女胎样本完整性分析')
    # 4. 数值变量异常值分析（以BMI为例）
    if '孕妇BMI' in df.columns:
        bmi_data = df['孕妇BMI'].dropna()
        if len(bmi_data) > 0:
            # 箱线图检测异常值
            bp = axes[1, 1].boxplot(bmi_data, patch_artist=True)
            bp['boxes'][0].set_facecolor('lightblue')
            bp['boxes'][0].set_alpha(0.7)
            # 计算异常值
            Q1 = bmi_data.quantile(0.25)
            Q3 = bmi_data.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            outliers = bmi_data[(bmi_data < lower_bound) | (bmi_data > upper_bound)]
            axes[1, 1].set_title(f'女胎BMI异常值检测\n异常值: {len(outliers)} 个 ({len(outliers)/len(bmi_data)*100:.1f}%)')
            axes[1, 1].set_ylabel('孕妇BMI')
            axes[1, 1].grid(True, alpha=0.3)
    else:
        axes[1, 1].text(0.5, 0.5, 'BMI数据\n不可用', 
                       ha='center', va='center', transform=axes[1, 1].transAxes, fontsize=14)
        axes[1, 1].set_title('异常值检测')
    plt.tight_layout()
    plt.savefig('女胎数据预处理_数据质量分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()

def create_female_preliminary_correlation_plots(df):
    # 选择数值变量进行相关性分析
    numeric_vars = [
        '年龄', '身高', '体重', '孕妇BMI', 
        '末次月经距离检测日天数', '检测时怀孕天数',
        '13号染色体的Z值', '18号染色体的Z值', '21号染色体的Z值', 
        'X染色体的Z值', '13号染色体的GC含量', '18号染色体的GC含量', '21号染色体的GC含量',
        'X染色体浓度', 'GC含量',
        'IVF妊娠_编码', '胎儿健康_编码'
    ]
    available_vars = [var for var in numeric_vars if var in df.columns]
    # 创建相关性数据
    corr_data = df[available_vars].select_dtypes(include=[np.number]).dropna()
    correlation_matrix = corr_data.corr()
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle('女胎数据初步相关性分析', fontsize=16, fontweight='bold')
    # 1. 相关性热图
    mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
    sns.heatmap(correlation_matrix, mask=mask, annot=False, cmap='RdBu_r', center=0,
                square=True, fmt='.3f', cbar_kws={"shrink": .8}, ax=axes[0])
    axes[0].set_title('变量间相关性热图')
    # 2. 与胎儿健康编码的相关性
    if '胎儿健康_编码' in correlation_matrix.columns:
        health_correlations = correlation_matrix['胎儿健康_编码'].drop('胎儿健康_编码')
        health_correlations = health_correlations.sort_values(key=abs, ascending=False)
        colors = ['red' if x < 0 else 'blue' for x in health_correlations.values]
        bars = axes[1].barh(range(len(health_correlations)), health_correlations.values, 
                           color=colors, alpha=0.7)
        axes[1].set_yticks(range(len(health_correlations)))
        axes[1].set_yticklabels(health_correlations.index)
        axes[1].set_xlabel('相关系数')
        axes[1].set_title('与胎儿健康编码的相关性')
        axes[1].axvline(x=0, color='black', linestyle='-', linewidth=1)
        axes[1].grid(True, alpha=0.3, axis='x')
        # 添加相关系数标签
        for i, (bar, value) in enumerate(zip(bars, health_correlations.values)):
            x_pos = value + (0.01 if value > 0 else -0.01)
            ha_pos = 'left' if value > 0 else 'right'
            axes[1].text(x_pos, i, f'{value:.3f}', va='center', ha=ha_pos, 
                        fontweight='bold', fontsize=9)
    else:
        # 显示整体相关性强度排序
        var_correlations = {}
        for var in correlation_matrix.columns:
            other_correlations = correlation_matrix[var].drop(var)
            avg_correlation = other_correlations.abs().mean()
            var_correlations[var] = avg_correlation
        sorted_vars = sorted(var_correlations.items(), key=lambda x: x[1], reverse=True)
        variables = [item[0] for item in sorted_vars]
        correlations = [item[1] for item in sorted_vars]
        bars = axes[1].barh(range(len(variables)), correlations, 
                           color='steelblue', alpha=0.7)
        axes[1].set_yticks(range(len(variables)))
        axes[1].set_yticklabels(variables)
        axes[1].set_xlabel('平均相关性强度')
        axes[1].set_title('变量相关性强度排序')
        axes[1].grid(True, alpha=0.3, axis='x')
        # 添加数值标签
        for i, (bar, value) in enumerate(zip(bars, correlations)):
            axes[1].text(bar.get_width() + 0.005, i, f'{value:.3f}', 
                        va='center', fontweight='bold', fontsize=9)
    plt.tight_layout()
    plt.savefig('女胎数据预处理_初步相关性分析.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()

def save_processed_data(processed_df, output_prefix="女胎数据_预处理后"):
    csv_file = f"{output_prefix}.csv"
    processed_df.to_csv(csv_file, index=False, encoding='utf-8-sig')
    print(f"   CSV文件: {csv_file}")
    excel_file = f"{output_prefix}.xlsx"
    processed_df.to_excel(excel_file, index=False, engine='openpyxl')
    print(f"   Excel文件: {excel_file}")
    return csv_file, excel_file
def main():
    excel_file = "附件.xlsx"
    try:
        processed_data = preprocess_female_data_simple(excel_file, enable_visualization=True)
        csv_file, excel_file_out = save_processed_data(processed_data)
        print(f"\n数值特征统计:")
        numeric_cols = processed_data.select_dtypes(include=[np.number]).columns
        print(processed_data[numeric_cols].describe().round(2))
        print(f"\n预处理总结:")
        print(f"   输入文件: 附件.xlsx (女胎检测数据)")
        print(f"   处理样本: {len(processed_data)} 个")
        print(f"   生成特征: {processed_data.shape[1]} 个")
        print(f"   输出文件: {csv_file}, {excel_file_out}")
        print(f"\n生成的可视化图表:")
        print(f"   • 女胎数据预处理_概览分析.png - 数据基本概况")
        print(f"   • 女胎数据预处理_分类变量分布.png - 分类变量分布分析") 
        print(f"   • 女胎数据预处理_连续变量分布.png - 连续变量分布分析")
        print(f"   • 女胎数据预处理_数据质量分析.png - 数据质量评估")
        print(f"   • 女胎数据预处理_初步相关性分析.png - 变量相关性探索")
        return processed_data
    except FileNotFoundError:
        print(f"错误: 找不到文件 '{excel_file}'")
        print("   请确保Excel文件在当前目录下")
    except Exception as e:
        print(f"处理失败: {str(e)}")
        import traceback
        traceback.print_exc()
if __name__ == "__main__":
    result = main()